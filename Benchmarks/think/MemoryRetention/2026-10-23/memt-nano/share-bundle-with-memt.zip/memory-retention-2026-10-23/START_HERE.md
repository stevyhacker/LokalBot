# Memory retention: five-configuration evidence bundle

Start with [the completed MemT extension report](memt-nano/REPORT.md),
[five-configuration English chart](memt-nano/memory-retention-with-memt.png),
and [unposted Reddit draft](memt-nano/REDDIT_DRAFT.md).

The added MemT run uses all 120 frozen cases. Its primary comparison is the 96-case English slice; 24 Serbian cases are exploratory. The original four-model experiment remains intact at the archive root. [Original report](REPORT.md).

MemT uses an experimental NF4 expert-offload runtime on Windows, while the earlier arms use GGUFs and llama.cpp on Ubuntu. Each case starts fresh, so this evaluates stateless extraction and does not exercise MemT's persistent latent-memory feature. Thinking is disabled. Read the report for all scoring and methodology limits.

[Run history](memt-nano/RUN_HISTORY.md), [validated scores](memt-nano/scores.json), [semantic decisions](memt-nano/review.json), [raw responses](memt-nano/results/memt-nano-nf4-offload.jsonl), and [validation](memt-nano/validation.txt) support auditing. Run the provided scorers and validators to check saved evidence without model weights or inference. The combined-evidence-manifest.json records every bundled payload hash.

This archive is provided with the benchmark pull request. The Reddit draft remains unposted. No model weights or application-source snapshot are included.
