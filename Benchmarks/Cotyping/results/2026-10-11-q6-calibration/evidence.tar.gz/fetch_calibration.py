"""Fetch public FLORES-200 dev data; keep calibration separate from synthetic evals."""
from pathlib import Path
import hashlib
import json
import tarfile
import urllib.request

ROOT=Path(__file__).resolve().parent
DEST=ROOT/'calibration'; DEST.mkdir(exist_ok=True)
URL='https://dl.fbaipublicfiles.com/nllb/flores200_dataset.tar.gz'
archive=DEST/'flores200_dataset.tar.gz'
if not archive.exists():
    urllib.request.urlretrieve(URL,archive)
with tarfile.open(archive) as tar:
    names=tar.getnames()
    for language in ['eng_Latn','srp_Cyrl']:
        for split in ['dev','devtest']:
            name=next(n for n in names if n.endswith(f'/{split}/{language}.{split}'))
            (DEST/f'{language}.{split}').write_bytes(tar.extractfile(name).read())

# Serbian alphabet transliteration. Uppercase digraph letters retain all-caps words.
alphabet=dict(zip('абвгдђежзијклљмнњопрстћуфхцчџш',
                  ['a','b','v','g','d','đ','e','ž','z','i','j','k','l','lj','m','n','nj','o','p','r','s','t','ć','u','f','h','c','č','dž','š']))
def latin(text):
    import re
    def word(match):
        source=match.group(); capitals=source.isupper()
        result=[]
        for char in source:
            value=alphabet.get(char.lower(),char)
            result.append((value.upper() if capitals else value.title()) if char.isupper() else value)
        return ''.join(result)
    return re.sub(r'[А-Яа-яЂђЈјЉљЊњЋћЏџ]+',word,text)

for language,target in [('eng_Latn','english'),('srp_Cyrl','serbian-latin')]:
    text='\n\n'.join((DEST/f'{language}.{split}').read_text().strip() for split in ['dev','devtest'])+'\n'
    if target=='serbian-latin': text=latin(text)
    assert not any('\u0400'<=char<='\u04ff' for char in text)
    (DEST/f'{target}.txt').write_text(text)
(DEST/'provenance.json').write_text(json.dumps(dict(source=URL,archiveSHA256=hashlib.sha256(archive.read_bytes()).hexdigest(),
    dataset='FLORES-200 dev plus devtest; calibration only, never this experiment\'s evaluation set',
    license='CC-BY-SA-4.0',upstream='https://github.com/facebookresearch/flores',
    authors='NLLB Team (2022), No Language Left Behind: Scaling Human-Centered Machine Translation',
    transformation='Concatenate dev/devtest. Deterministic Serbian Cyrillic-to-Latin alphabet transliteration; preserve capitalization. No translation or model-generated rewrites.',
    textSHA256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in DEST.glob('*.txt')}),indent=2)+'\n')
print((DEST/'provenance.json').read_text())
