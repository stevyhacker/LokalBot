---
license: apache-2.0
pipeline_tag: any-to-any
tags:
- gguf
- quantized
base_model:
- google/gemma-4-E2B-it
---

# gemma-4-E2B-it

Run with https://llama.app

```bash
llama serve -hf ggml-org/gemma-4-E2B-it-GGUF
```

### Source models
- https://huggingface.co/google/gemma-4-E2B-it
- https://huggingface.co/google/gemma-4-E2B-it-assistant
- https://huggingface.co/google/gemma-4-E2B-it-qat-q4_0-unquantized-assistant
- https://huggingface.co/google/gemma-4-E2B-it-qat-q4_0-unquantized

### TODOs

- add info
- add dflash

> [!IMPORTANT]
> This model is automatically converted using https://github.com/ggml-org/convert
