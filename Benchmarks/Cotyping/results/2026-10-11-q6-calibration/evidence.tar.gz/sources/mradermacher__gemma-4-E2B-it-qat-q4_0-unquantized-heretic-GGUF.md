---
base_model: coder3101/gemma-4-E2B-it-qat-q4_0-unquantized-heretic
language:
- en
library_name: transformers
license: apache-2.0
license_link: https://ai.google.dev/gemma/docs/gemma_4_license
mradermacher:
  readme_rev: 1
quantized_by: mradermacher
tags:
- heretic
- uncensored
- decensored
- abliterated
- ara
---
## About

<!-- ### quantize_version: 2 -->
<!-- ### output_tensor_quantised: 1 -->
<!-- ### convert_type: hf -->
<!-- ### vocab_type:  -->
<!-- ### tags:  -->
<!-- ### quants:  Q4_K_S Q2_K Q3_K_M Q3_K_S Q3_K_L Q4_K_M IQ4_XS -->
<!-- ### quants_skip:  -->
<!-- ### skip_mmproj: 1 -->
static quants of https://huggingface.co/coder3101/gemma-4-E2B-it-qat-q4_0-unquantized-heretic

<!-- provided-files -->

***For a convenient overview and download list, visit our [model page for this model](https://hf.tst.eu/model#gemma-4-E2B-it-qat-q4_0-unquantized-heretic-GGUF).***

weighted/imatrix quants are available at https://huggingface.co/mradermacher/gemma-4-E2B-it-qat-q4_0-unquantized-heretic-i1-GGUF
## Usage

If you are unsure how to use GGUF files, refer to one of [TheBloke's
READMEs](https://huggingface.co/TheBloke/KafkaLM-70B-German-V0.1-GGUF) for
more details, including on how to concatenate multi-part files.

## Provided Quants

(sorted by size, not necessarily quality. IQ-quants are often preferable over similar sized non-IQ quants)

| Link | Type | Size/GB | Notes |
|:-----|:-----|--------:|:------|
| [GGUF](https://huggingface.co/mradermacher/gemma-4-E2B-it-qat-q4_0-unquantized-heretic-GGUF/resolve/main/gemma-4-E2B-it-qat-q4_0-unquantized-heretic.Q2_K.gguf) | Q2_K | 3.1 |  |
| [GGUF](https://huggingface.co/mradermacher/gemma-4-E2B-it-qat-q4_0-unquantized-heretic-GGUF/resolve/main/gemma-4-E2B-it-qat-q4_0-unquantized-heretic.Q3_K_S.gguf) | Q3_K_S | 3.2 |  |
| [GGUF](https://huggingface.co/mradermacher/gemma-4-E2B-it-qat-q4_0-unquantized-heretic-GGUF/resolve/main/gemma-4-E2B-it-qat-q4_0-unquantized-heretic.Q3_K_M.gguf) | Q3_K_M | 3.3 | lower quality |
| [GGUF](https://huggingface.co/mradermacher/gemma-4-E2B-it-qat-q4_0-unquantized-heretic-GGUF/resolve/main/gemma-4-E2B-it-qat-q4_0-unquantized-heretic.Q3_K_L.gguf) | Q3_K_L | 3.4 |  |
| [GGUF](https://huggingface.co/mradermacher/gemma-4-E2B-it-qat-q4_0-unquantized-heretic-GGUF/resolve/main/gemma-4-E2B-it-qat-q4_0-unquantized-heretic.IQ4_XS.gguf) | IQ4_XS | 3.4 |  |
| [GGUF](https://huggingface.co/mradermacher/gemma-4-E2B-it-qat-q4_0-unquantized-heretic-GGUF/resolve/main/gemma-4-E2B-it-qat-q4_0-unquantized-heretic.Q4_K_S.gguf) | Q4_K_S | 3.5 | fast, recommended |
| [GGUF](https://huggingface.co/mradermacher/gemma-4-E2B-it-qat-q4_0-unquantized-heretic-GGUF/resolve/main/gemma-4-E2B-it-qat-q4_0-unquantized-heretic.Q4_K_M.gguf) | Q4_K_M | 3.5 | fast, recommended |

Here is a handy graph by ikawrakow comparing some lower-quality quant
types (lower is better):

![image.png](https://www.nethype.de/huggingface_embed/quantpplgraph.png)

And here are Artefact2's thoughts on the matter:
https://gist.github.com/Artefact2/b5f810600771265fc1e39442288e8ec9

## FAQ / Model Request

See https://huggingface.co/mradermacher/model_requests for some answers to
questions you might have and/or if you want some other model quantized.

## Thanks

I thank my company, [nethype GmbH](https://www.nethype.de/), for letting
me use its servers and providing upgrades to my workstation to enable
this work in my free time.

<!-- end -->
