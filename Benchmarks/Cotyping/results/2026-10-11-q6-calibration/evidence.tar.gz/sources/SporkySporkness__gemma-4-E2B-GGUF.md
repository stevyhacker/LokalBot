---
license: apache-2.0
---

A few GGUF quants of the base model, as I could not find any. Made using llama.cpp at commit d0a6dfe, binaries at release b8683
Re-quantized with bf16 and re-uploaded.
Original model: https://huggingface.co/google/gemma-4-E2B