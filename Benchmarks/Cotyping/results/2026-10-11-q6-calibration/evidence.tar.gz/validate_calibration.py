"""Validate the actual native matrix budgets and component-merge arithmetic."""
from array import array
from pathlib import Path
import json
import math
import struct
import inspect_gguf as gg

ROOT=Path(__file__).resolve().parent

def load(name):
    path=ROOT/'calibration'/f'{name}.gguf';data=gg.parse(path);tensors={}
    with path.open('rb') as file:
        for tensor in data['tensors']:
            assert tensor['type']==0
            file.seek(data['tensorDataOffset']+tensor['offset'])
            values=array('f');values.frombytes(file.read(tensor['parameters']*4))
            # Derived diagnostic statistics deliberately use NaN for undefined
            # correlations. Quantization inputs are sums/counts, not .stats.
            if not tensor['name'].endswith('.stats'):
                assert all(math.isfinite(x) for x in values),tensor['name']
            tensors[tensor['name']]=values
    return data,tensors

def main():
    names=['english-a','english-b','serbian-a','english','bilingual']
    matrices={name:load(name) for name in names};report={}
    for name,(data,tensors) in matrices.items():
        chunks=64 if name in ['english','bilingual'] else 32
        assert data['metadata']['imatrix.chunk_count']==chunks and data['metadata']['imatrix.chunk_size']==512
        counts={value for key,values in tensors.items() if key.endswith('.counts') for value in values}
        assert counts=={float(chunks*512)}
        report[name]=dict(metadata=data['metadata'],countTensors=sum(k.endswith('.counts') for k in tensors),
                          countValues=sorted(counts),quantizationAccumulatorsFinite=True,
                          undefinedDiagnosticStats=sum(not math.isfinite(x) for key,values in tensors.items() if key.endswith('.stats') for x in values))
    for arm,second in [('english','english-b'),('bilingual','serbian-a')]:
        a=matrices['english-a'][1];b=matrices[second][1];combined=matrices[arm][1]
        assert a.keys()==b.keys()==combined.keys()
        checked=0
        for key in a:
            if not key.endswith(('.counts','.in_sum2','.in_sum')): continue
            assert len(a[key])==len(b[key])==len(combined[key])
            for x,y,actual in zip(a[key],b[key],combined[key]):
                expected=struct.unpack('<f',struct.pack('<f',x+y))[0]
                assert math.isclose(actual,expected,rel_tol=2e-6,abs_tol=1e-7),(arm,key,actual,expected)
                checked+=1
        report[arm]['verifiedMergedAccumulatorValues']=checked
    (ROOT/'calibration-validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print({key:value.get('verifiedMergedAccumulatorValues',value['countValues']) for key,value in report.items()})

if __name__=='__main__':main()
