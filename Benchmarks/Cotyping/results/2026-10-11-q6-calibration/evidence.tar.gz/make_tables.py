"""Render tables directly from validated quantitative and blind-judge results."""
from pathlib import Path
import json

ROOT=Path(__file__).resolve().parent
NAMES={'q6':'Current mradermacher i1 Q6','static':'mradermacher static Q6','local_static':'Local static Q6',
       'english':'Local English-calibrated Q6','bilingual':'Local EN/SR Latin Q6','animateus':'Animateus Q6','sporky':'Sporky Q6'}

def ci(pair):return f"{pair['delta']:+.3f} [{pair['delta95CI'][0]:+.3f}, {pair['delta95CI'][1]:+.3f}]"

def main():
    data=json.loads((ROOT/'summary.json').read_text());quality=data['quality']['policies']['matched'];timing=data['timing']
    lines=['## Warm native generation and equal-frequency quality','',
           '| Q6 variant | Warm mean / p95, ms | Matched mean / p95, ms | EN utility | SR Latin utility | Helpful / poor | Overall utility delta [95% interval] |',
           '|---|---:|---:|---:|---:|---:|---:|']
    for arm,name in NAMES.items():
        t=timing['normal']['steady']['fresh'][arm]['all']['paired']['candidate'];m=timing['normal']['matched']['fresh'][arm]['all']['paired']['candidate'];q=quality[arm]
        lines.append(f"| {name} | {t['mean']:.1f} / {t['p95']:.1f} | {m['mean']:.1f} / {m['p95']:.1f} | {q['en']['meanUtility']:.3f} | {q['sr_latn']['meanUtility']:.3f} | {q['all']['helpful']} / {q['all']['poor']} | {ci(q['all']['delta'])} |")
    lines += ['', '## Per-language quality at equal frequency','',
              '| Variant | EN helpful / poor | EN delta [95% interval] | SR Latin helpful / poor | SR Latin delta [95% interval] |',
              '|---|---:|---:|---:|---:|']
    for arm,name in NAMES.items():
        q=quality[arm];a=q['en'];b=q['sr_latn']
        lines.append(f"| {name} | {a['helpful']} / {a['poor']} | {ci(a['delta'])} | {b['helpful']} / {b['poor']} | {ci(b['delta'])} |")
    lines += ['', '## Controlled calibration comparisons','',
              '| Candidate minus control, matched frequency | Overall delta [95% interval] | EN delta [95% interval] | SR Latin delta [95% interval] |',
              '|---|---:|---:|---:|']
    for key,values in data['calibrationQualityPairs'].items():
        lines.append(f"| {key} | {ci(values['all'])} | {ci(values['en'])} | {ci(values['sr_latn'])} |")
    lines += ['', '## Longer fields, typing and cancellation','',
              '| Variant | Long-field mean / p95, ms | Typing mean / p95, ms | Cancellation through replacement, paired mean Q6 → variant, ms | Peak RSS GB |',
              '|---|---:|---:|---:|---:|']
    for arm,name in NAMES.items():
        a=timing['normal']['production']['long'][arm]['all']['paired']['candidate'];b=timing['normal']['production']['dynamic'][arm]['all']['paired']['candidate'];c=timing['cancellation'][arm]['throughReplacement']
        rss=timing['resources'][arm]['maximumResidentBytes']['median']/1e9
        lines.append(f"| {name} | {a['mean']:.1f} / {a['p95']:.1f} | {b['mean']:.1f} / {b['p95']:.1f} | {c['default']['mean']:.1f} → {c['candidate']['mean']:.1f} | {rss:.2f} |")
    lines += ['', '## Matched confidence gates','', '| Variant | English primary / fallback | Serbian Latin primary / fallback |','|---|---:|---:|']
    for arm,name in NAMES.items():
        c=data['matching']['cutoffs'][arm];a=c['en'];b=c['sr_latn']
        lines.append(f"| {name} | {a['primary']:.5f} / {a['fallback']:.5f} | {b['primary']:.5f} / {b['fallback']:.5f} |")
    (ROOT/'TABLES.md').write_text('\n'.join(lines)+'\n')

if __name__=='__main__':main()
