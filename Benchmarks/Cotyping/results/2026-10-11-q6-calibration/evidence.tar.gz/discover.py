"""Save public publisher metadata and model cards for a fixed-checkpoint study."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
import json
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parent
DEST = ROOT / 'sources'
DEST.mkdir(exist_ok=True)

def get(url):
    with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'LokalBot-Q6-study'}), timeout=90) as response:
        return response.read()

authors = ['unsloth', 'bartowski', 'lmstudio-community', 'ggml-org', 'mradermacher']
repos = {'google/gemma-4-E2B', 'ggml-org/gemma-4-E2B-GGUF',
         'mradermacher/gemma-4-E2B-i1-GGUF', 'mradermacher/gemma-4-E2B-GGUF',
         'Animateus/gemma-4-E2B-GGUF', 'SporkySporkness/gemma-4-E2B-GGUF'}

def search(author):
    raw = get('https://huggingface.co/api/models?' + urllib.parse.urlencode(dict(author=author, search='gemma-4-E2B', full='true', limit=100)))
    (DEST / (author + '-search.json')).write_bytes(raw)
    return json.loads(raw)

for author, results in zip(authors, ThreadPoolExecutor(max_workers=4).map(search, authors)):
    for row in results:
        if 'GGUF' in row['id']:
            repos.add(row['id'])
    print(json.dumps({'author': author, 'models': [r['id'] for r in results]}), flush=True)

def inspect(repo):
    name = repo.replace('/', '__')
    raw = get('https://huggingface.co/api/models/' + repo + '?blobs=true')
    (DEST / (name + '.json')).write_bytes(raw)
    data = json.loads(raw)
    try:
        (DEST / (name + '.md')).write_bytes(get(f'https://huggingface.co/{repo}/raw/{data["sha"]}/README.md'))
    except Exception as error:
        print(json.dumps({'cardError': repo, 'error': str(error)}), flush=True)
    return dict(repository=repo, revision=data['sha'], downloads=data.get('downloads'), likes=data.get('likes'),
                baseModel=(data.get('cardData') or {}).get('base_model'),
                candidates=[{'file': f['rfilename'], 'bytes': f.get('size'), 'lfs': f.get('lfs')} for f in data.get('siblings', [])
                            if any(t in f['rfilename'].upper() for t in ['Q6_K', 'BF16', 'F16', 'IMATRIX']) or f['rfilename'].endswith('.safetensors')])

records = list(ThreadPoolExecutor(max_workers=4).map(inspect, sorted(repos)))
(ROOT / 'publisher-survey.json').write_text(json.dumps(dict(checkedAtUTC=datetime.now(timezone.utc).isoformat(), publishers=records), indent=2) + '\n')
for record in records:
    print(json.dumps(record), flush=True)
