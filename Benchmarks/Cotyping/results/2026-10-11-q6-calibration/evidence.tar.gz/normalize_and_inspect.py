"""Align only the GGUF add-BOS metadata flag in temporary evaluation clones."""
from pathlib import Path
import hashlib
import json
import struct
import subprocess
import inspect_gguf as gg

ROOT=Path(__file__).resolve().parent

def sha(path):
    with path.open('rb') as file:return hashlib.file_digest(file,'sha256').hexdigest()

def find_bos(path):
    with path.open('rb') as file:
        def scalar(code):
            fmt='<'+gg.SCALAR[code];return struct.unpack(fmt,file.read(struct.calcsize(fmt)))[0]
        def string():return file.read(scalar(10)).decode('utf-8')
        def value(kind):
            if kind==8:return string()
            if kind==9:
                subtype=scalar(4);count=scalar(10)
                for _ in range(count):value(subtype)
                return None
            return scalar(kind)
        assert file.read(4)==b'GGUF' and scalar(4)==3
        scalar(10);count=scalar(10)
        for _ in range(count):
            name=string();kind=scalar(4);offset=file.tell();result=value(kind)
            if name=='tokenizer.ggml.add_bos_token':
                assert kind==7
                return offset,result
    raise ValueError('Missing explicit add_bos_token flag')

def normalize(model):
    original=Path(model['path']); assert sha(original)==model['sha256']
    offset,value=find_bos(original)
    receipt=dict(arm=model['id'],source=str(original),sourceSHA256=model['sha256'],offset=offset,oldValue=value,newValue=False)
    if value:
        destination=original.with_name(original.stem+'.eval.gguf')
        assert not destination.exists()
        subprocess.run(['/bin/cp','-c',str(original),str(destination)],check=True)
        with destination.open('r+b') as file:
            file.seek(offset);assert file.read(1)==b'\x01';file.seek(offset);file.write(b'\x00')
        receipt.update(evaluation=str(destination),evaluationSHA256=sha(destination),changedBytes=1)
        # Verify every other byte, including every tensor, remains identical.
        with original.open('rb') as a,destination.open('rb') as b:
            position=0;differences=[]
            while chunk:=a.read(8*1024*1024):
                other=b.read(len(chunk))
                if chunk!=other:
                    differences.extend(position+i for i,(x,y) in enumerate(zip(chunk,other)) if x!=y)
                position+=len(chunk)
            assert b.read(1)==b'' and differences==[offset]
        model=dict(model,publisherOrBuildSHA256=model['sha256'],path=str(destination),sha256=receipt['evaluationSHA256'],
                   normalization='Only tokenizer.ggml.add_bos_token true -> false to match current native input tokens; weights unchanged.')
    else:receipt.update(evaluation=str(original),evaluationSHA256=model['sha256'],changedBytes=0)
    return model,receipt

def main():
    models=json.loads((ROOT/'models.json').read_text());normalized=[];receipts=[]
    for model in models:
        result,receipt=normalize(model);normalized.append(result);receipts.append(receipt)
        (ROOT/f'model-{model["id"]}.json').write_text(json.dumps(result,indent=2)+'\n')
    (ROOT/'models-publisher-and-build.json').write_text(json.dumps(models,indent=2)+'\n')
    (ROOT/'models.json').write_text(json.dumps(normalized,indent=2)+'\n')
    (ROOT/'bos-alignment.json').write_text(json.dumps(receipts,indent=2)+'\n')
    gg.main()
    print('Every evaluated tokenizer and architecture matches the current Q6. One-byte changes verified.')

if __name__=='__main__':main()
