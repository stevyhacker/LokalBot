"""Build three Q6 controls from one BF16 file; never requantize Q6 weights."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import time

ROOT=Path(__file__).resolve().parent
MODELS=ROOT/'models'
CAL=ROOT/'calibration'
LOGS=ROOT/'conversion';LOGS.mkdir(exist_ok=True)

def sha(path):
    with Path(path).open('rb') as file:return hashlib.file_digest(file,'sha256').hexdigest()

def run(name, command, output):
    receipt=LOGS/(name+'.json')
    if receipt.exists():
        old=json.loads(receipt.read_text())
        assert old['complete'] and sha(output)==old['outputSHA256']
        return
    started=time.monotonic()
    print(json.dumps({'starting':name,'at':datetime.now(timezone.utc).isoformat()}),flush=True)
    with (LOGS/(name+'.log')).open('w') as log:
        p=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
    receipt.write_text(json.dumps(dict(command=command,exitCode=p.returncode,complete=True,
        output=str(output),outputSHA256=sha(output),outputBytes=output.stat().st_size,
        wallSeconds=time.monotonic()-started,finishedAtUTC=datetime.now(timezone.utc).isoformat()),indent=2)+'\n')
    print(json.dumps({'completed':name,'seconds':round(time.monotonic()-started,1)}),flush=True)

def main():
    source=json.loads((ROOT/'model-source.json').read_text());path=Path(source['path'])
    assert path.stat().st_size==source['bytes'] and sha(path)==source['sha256']
    quant='/opt/homebrew/bin/llama-quantize'; imatrix='/opt/homebrew/bin/llama-imatrix'
    toolpins={tool:sha(tool) for tool in [quant,imatrix]}
    (LOGS/'tools.json').write_text(json.dumps(toolpins,indent=2)+'\n')
    run('local_static',[quant,str(path),str(MODELS/'local_static.gguf'),'Q6_K','6'],MODELS/'local_static.gguf')
    for part, language, offset in [('english-a','english',0),('english-b','english',32),('serbian-a','serbian-latin',0)]:
        matrix=CAL/(part+'.gguf')
        run(part,[imatrix,'-m',str(path),'-f',str(CAL/(language+'.txt')),'-o',str(matrix),
            '-c','512','-b','512','-ub','512','-t','4','-tb','4','-ngl','99','--chunks','32','--chunk',str(offset),
            '--no-ppl','--process-output','--output-frequency','32'],matrix)
    for arm, second in [('english','english-b'),('bilingual','serbian-a')]:
        matrix=CAL/(arm+'.gguf')
        run(arm+'-matrix',[imatrix,'--in-file',str(CAL/'english-a.gguf')+','+str(CAL/(second+'.gguf')),
            '-o',str(matrix)],matrix)
        run(arm,[quant,'--imatrix',str(matrix),str(path),str(MODELS/(arm+'.gguf')),'Q6_K','6'],MODELS/(arm+'.gguf'))
    for arm in ['local_static','english','bilingual']:
        path=MODELS/(arm+'.gguf')
        model=dict(id=arm,path=str(path),file=path.name,bytes=path.stat().st_size,sha256=sha(path),
            repository='local-from:'+source['repository'],revision=source['revision'],sourceSHA256=source['sha256'],
            quantizerSHA256=toolpins[quant],imatrixSHA256=sha(CAL/(arm+'.gguf')) if arm!='local_static' else None,
            verifiedAtUTC=datetime.now(timezone.utc).isoformat())
        (ROOT/f'model-{arm}.json').write_text(json.dumps(model,indent=2)+'\n')
    ids=['q6','static','local_static','english','bilingual','animateus','sporky']
    (ROOT/'models.json').write_text(json.dumps([json.loads((ROOT/f'model-{arm}.json').read_text()) for arm in ids],indent=2)+'\n')

if __name__=='__main__':main()
