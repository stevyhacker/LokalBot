"""Focused checks for calibration isolation and matched-frequency analysis."""
from pathlib import Path
import json
import struct
import tempfile
import unittest
import q6_publisher_experiment as experiment
import normalize_and_inspect as normalize

ROOT=Path(__file__).resolve().parent

class StudyChecks(unittest.TestCase):
    def fixture(self,directory,enabled):
        key=b'tokenizer.ggml.add_bos_token'
        data=b'GGUF'+struct.pack('<IQQ',3,0,1)+struct.pack('<Q',len(key))+key+struct.pack('<I?',7,enabled)+bytes(range(256))*4
        path=Path(directory)/'model.gguf';path.write_bytes(data)
        return dict(id='fixture',path=str(path),bytes=len(data),sha256=normalize.sha(path)),data

    def test_bos_alignment_preserves_source_and_every_other_byte(self):
        with tempfile.TemporaryDirectory() as temp:
            model,before=self.fixture(temp,True);updated,receipt=normalize.normalize(model)
            self.assertEqual(Path(model['path']).read_bytes(),before)
            after=Path(updated['path']).read_bytes()
            self.assertEqual([i for i,(a,b) in enumerate(zip(before,after)) if a!=b],[receipt['offset']])
            self.assertFalse(normalize.find_bos(Path(updated['path']))[1])
            self.assertEqual(updated['sha256'],normalize.sha(Path(updated['path'])))

    def test_matching_bos_setting_keeps_original_file(self):
        with tempfile.TemporaryDirectory() as temp:
            model,before=self.fixture(temp,False);updated,receipt=normalize.normalize(model)
            self.assertEqual(updated,model);self.assertEqual(receipt['changedBytes'],0)
            self.assertEqual(len(list(Path(temp).iterdir())),1)

    def test_missing_bos_setting_fails_closed(self):
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/'model.gguf';path.write_bytes(b'GGUF'+struct.pack('<IQQ',3,0,0))
            with self.assertRaisesRegex(ValueError,'Missing explicit'):normalize.find_bos(path)

    def test_fresh_fictional_evaluation_is_disjoint(self):
        pairs=json.loads((ROOT/'corpus.json').read_text())['pairs']
        text='\n'.join((ROOT/'calibration'/f'{lang}.txt').read_text().casefold() for lang in ['english','serbian-latin'])
        self.assertEqual(len(pairs),48)
        for pair in pairs:
            for sentence in pair:
                self.assertNotIn(sentence.casefold(),text)
                self.assertFalse(any('\u0400'<=char<='\u04ff' for char in sentence))

    def test_frequency_gate_preserves_ungated_midword(self):
        row=dict(text='čekujemo',cache=dict(confidenceGateEligible=False,firstWordProbability=0.01),oneWordText='')
        self.assertEqual(experiment.study.candidate(row,.9,.99),'čekujemo')

    def test_cutoff_changes_frequency_without_rewriting_text(self):
        rows=[dict(text=f' word{i}',oneWordText=f' word{i}',cache=dict(confidenceGateEligible=True,
              firstWordProbability=p,hybridFallbackProbability=p)) for i,p in enumerate([.8,.6,.4,.2])]
        cut=experiment.study.cutoff(rows,2)
        actual=[experiment.study.candidate(row,**cut) for row in rows]
        self.assertEqual(actual,[' word0',' word1','',''])

if __name__=='__main__':unittest.main()
