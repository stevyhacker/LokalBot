"""Package only public calibration inputs and synthetic experiment evidence."""
import gzip
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT.parent / 'lokalbot-q6-publication'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def included(path):
    relative = path.relative_to(ROOT)
    if path.is_symlink() or not path.is_file() or '__pycache__' in relative.parts:
        return False
    if len(relative.parts) == 1:
        return (path.suffix in {'.py', '.json', '.md', '.log', '.txt'}
                and not path.name.startswith(('pr-', 'publication-', 'archive-'))
                and path.name != 'pre-run-processes.txt')
    if relative.parts[0] not in {'calibration', 'conversion', 'inputs', 'judge', 'runs', 'sources'}:
        return False
    return path.suffix in {'.py', '.json', '.jsonl', '.md', '.log', '.txt', '.dev', '.devtest', '.gguf'}


def main():
    OUTPUT.mkdir(exist_ok=True)
    paths = sorted(p for p in ROOT.rglob('*') if included(p))
    assert not any('models' in p.relative_to(ROOT).parts for p in paths)
    assert all(p.stat().st_size < 40_000_000 for p in paths)
    members = [{ 'path': str(p.relative_to(ROOT)), 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in paths]
    archive = OUTPUT / 'evidence.tar.gz'
    with archive.open('wb') as file:
        with gzip.GzipFile(filename='', mode='wb', fileobj=file, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as tar:
                for path in paths:
                    info = tar.gettarinfo(str(path), arcname=str(path.relative_to(ROOT)))
                    info.uid = info.gid = 0
                    info.uname = info.gname = ''
                    info.mtime = 0
                    info.mode = 0o644
                    with path.open('rb') as data:
                        tar.addfile(info, data)
    manifest = dict(archive=archive.name, bytes=archive.stat().st_size, sha256=sha(archive),
                    excluded='Model weights, app binaries, full FLORES tarball, raw process inventory, PR state, profiling data and Python caches.',
                    members=members)
    (OUTPUT / 'evidence-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print({k: v for k, v in manifest.items() if k != 'members'} | {'memberCount': len(members)})


if __name__ == '__main__':
    main()
