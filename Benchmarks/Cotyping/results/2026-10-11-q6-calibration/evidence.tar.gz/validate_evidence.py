"""Recheck derived frequency controls and publisher parity from saved evidence."""
from pathlib import Path
import q6_publisher_experiment as experiment

study = experiment.study
ROOT = Path(__file__).resolve().parent


def main():
    summary = study.read(ROOT / 'summary.json')
    meta = study.read(ROOT / 'case-meta.json')
    config = study.read(ROOT / 'matched.json')
    trace_checks = matched_checks = midword_checks = recovery_checks = 0
    for arm in experiment.IDS:
        trace = study.observed(ROOT, 'trace', 'fresh', arm)
        production = study.observed(ROOT, 'production', 'fresh', arm)
        for identifier, row in trace.items():
            assert study.candidate(row, .1, .31) == production[identifier]['text']
            trace_checks += 1
        for round_number in [1, 2]:
            matched = study.observed(ROOT, 'matched', 'fresh', arm, round_number)
            for identifier, row in matched.items():
                language = meta[identifier]['language']
                assert row['text'] == study.candidate(trace[identifier], **config['cutoffs'][arm][language])
                matched_checks += 1
                if meta[identifier]['kind'] == 'midword':
                    assert row['text'] == production[identifier]['text']
                    midword_checks += 1
            for language, frequency in config['frequencies'].items():
                assert sum(bool(row['text']) for i, row in matched.items() if meta[i]['language'] == language) == frequency['matched']
            cancelled = study.observed(ROOT, 'production', 'cancellation', arm, round_number)
            for identifier, row in cancelled.items():
                if not identifier.endswith('-replacement'):
                    continue
                cold = cancelled[identifier.removesuffix('-replacement') + '-cold']
                assert all(row.get(k) == cold.get(k) for k in ['prompt', 'text', 'suppression', 'error', 'cancelled'])
                recovery_checks += 1
    assert summary['validation']['baselineMatchingChangedOutputs'] == 0
    inspection = study.read(ROOT / 'gguf-inspection.json')
    hashes = inspection['commonTensorSHA256']
    assert hashes['static'] == hashes['sporky'] and len(hashes['static']) == 601
    parity = 0
    for mode, datasets, rounds in [('production', ['fresh', 'long', 'dynamic'], [1, 2]), ('matched', ['fresh'], [1, 2])]:
        for dataset in datasets:
            for number in rounds:
                a = study.observed(ROOT, mode, dataset, 'static', number)
                b = study.observed(ROOT, mode, dataset, 'sporky', number)
                assert a.keys() == b.keys()
                for identifier in a:
                    assert all(a[identifier].get(k) == b[identifier].get(k) for k in ['prompt', 'text', 'suppression'])
                    parity += 1
    quality = summary['quality']
    assert quality['models'] == ['claude-opus-5-5']
    assert quality['repeat']['cases'] == 24
    for arm in experiment.IDS:
        for language, frequency in config['frequencies'].items():
            q = quality['policies']['matched'][arm][language]
            assert q['shown'] == frequency['matched'] and q['n'] == frequency['total']
    protocol = study.read(ROOT / 'judge/protocol.json')
    result = dict(summary['validation'], traceProductionChecks=trace_checks,
                  nativeMatchedTraceChecks=matched_checks, preservedMidwordChecks=midword_checks,
                  replacementColdChecks=recovery_checks, staticSporkyTensorMatches=601,
                  staticSporkyOutputMatches=parity, judgeBatches=len(protocol['batches']),
                  judgePrimaryCases=protocol['primaryCases'], judgeRepeatCases=protocol['repeatCases'],
                  allSilentCases=288-protocol['primaryCases'], exactFrequencyAndJudgeCoverage=True)
    study.write(ROOT / 'validation.json', result)
    print(result)


if __name__ == '__main__':
    main()
