# Calibration text attribution

The files `eng_Latn.dev`, `eng_Latn.devtest`, `srp_Cyrl.dev`, and
`srp_Cyrl.devtest` are extracts from FLORES-200, published by the NLLB Team / Meta.

Source: <https://dl.fbaipublicfiles.com/nllb/flores200_dataset.tar.gz>

Project and dataset description: <https://github.com/facebookresearch/flores>

License: **Creative Commons Attribution-ShareAlike 4.0 International**,
<https://creativecommons.org/licenses/by-sa/4.0/>.

Citation: NLLB Team (2022), *No Language Left Behind: Scaling Human-Centered
Machine Translation*.

Modifications for this experiment: concatenate dev and devtest into
`english.txt`; concatenate and deterministically transliterate Serbian Cyrillic
to Serbian Latin into `serbian-latin.txt`. The derived text files are also
provided under CC-BY-SA-4.0. The original archive and extracted file hashes are
recorded for reproduction. The script documents every alphabet mapping.

These files are quantization-calibration inputs only. They are not used as this
study's quality-evaluation cases and are not sent to the external judge.
