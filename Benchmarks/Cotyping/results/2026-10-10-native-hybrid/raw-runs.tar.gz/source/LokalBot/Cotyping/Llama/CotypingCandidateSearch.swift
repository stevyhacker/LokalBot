import Foundation

/// Opt-in experiment, deliberately absent from saved settings and the normal
/// engine selector. The control retains the existing sampler/decode path.
enum CotypingDecoderMode: Int, Codable, CaseIterable, Sendable {
    case sampled = 1
    case candidates2 = 2
    case candidates4 = 4

    var width: Int { rawValue }
    /// Prompt sequence, active branches, and temporary copies. Copy all parents
    /// before recycling an active slot, including when siblings share a parent.
    var sequenceCapacity: Int { self == .sampled ? 1 : 2 * width + 1 }
}

enum CotypingCandidateRanking: String, Codable, Sendable {
    case mean
    case sum
    case firstWord

    func ordered(_ candidates: [CotypingSearchCandidate]) -> [CotypingSearchCandidate] {
        candidates.sorted { lhs, rhs in
            func value(_ candidate: CotypingSearchCandidate) -> Double {
                switch self {
                case .mean: return candidate.score
                case .sum: return candidate.logProbability
                case .firstWord: return Double(candidate.confidence.probability)
                }
            }
            if value(lhs) != value(rhs) { return value(lhs) > value(rhs) }
            if lhs.score != rhs.score { return lhs.score > rhs.score }
            return lhs.tokens.lexicographicallyPrecedes(rhs.tokens)
        }
    }
}

struct CotypingSearchDiagnostics: Codable, Sendable {
    var width: Int
    var ranking = CotypingCandidateRanking.mean
    var expandedCandidates = 0
    var peakActiveCandidates = 0
    var decodedTokens = 0
    var prefillTokens = 0
    var completedCandidates = 0
    var candidateTexts: [String] = []
    var candidateScores: [Double] = []
    var candidateTokenCounts: [Int] = []
    var candidateHealingTokenCounts: [Int] = []
    var candidateLogProbabilities: [Double] = []
    var candidateFirstWordProbabilities: [Float] = []
}

struct CotypingSearchResult: Sendable {
    var candidates: [CotypingSearchCandidate]
    var rejectedLowConfidence: Bool
    var diagnostics: CotypingSearchDiagnostics
}

/// All text, UTF-8, healing and confidence state belongs to a branch. Native KV
/// state is represented by `sequenceID`; `logitsIndex` identifies its current
/// row in the most recent batch. Neither is used to rank suggestions.
struct CotypingSearchCandidate: Sendable {
    enum Step { case active, complete, invalid, lowConfidence }

    var sequenceID: Int32 = 0
    var logitsIndex: Int32 = -1
    var tokens: [Int32] = []
    var remainingPrefix: [UInt8]
    var raw = ""
    var emittedPieces = 0
    var freeTokens = 0
    var logProbability: Double = 0
    var confidence: CotypingFirstWordConfidence
    private var textDecoder = CotypingUTF8TokenDecoder()

    init(requiredPrefix: [UInt8], minimumProbability: Float) {
        remainingPrefix = requiredPrefix
        confidence = CotypingFirstWordConfidence(minimum: minimumProbability)
    }

    /// Mean full-vocabulary, temperature-one log probability, including healing.
    /// Length normalization avoids automatically preferring shorter completed
    /// branches. This is an experimental ranking rule, not a calibrated quality score.
    var score: Double { logProbability / Double(max(1, tokens.count)) }

    mutating func append(
        token: Int32, bytes: [UInt8], logProbability tokenLogProbability: Double,
        probability: Float, maxTokens: Int, isEOG: Bool = false
    ) -> Step {
        guard tokenLogProbability.isFinite else { return .invalid }
        let healing = !remainingPrefix.isEmpty
        if isEOG { return healing ? .invalid : .complete }
        tokens.append(token)
        logProbability += tokenLogProbability
        let visibleBytes: [UInt8]
        if healing {
            switch CotypingRequiredPrefixMatcher.match(pieceBytes: bytes, remaining: remainingPrefix[...]) {
            case .consumes(let count):
                remainingPrefix.removeFirst(count)
                return .active
            case .overshoots(let extra):
                remainingPrefix.removeAll()
                visibleBytes = extra
            case .mismatch:
                return .invalid
            }
        } else {
            freeTokens += 1
            visibleBytes = bytes
        }
        guard let text = textDecoder.append(visibleBytes) else { return .invalid }
        guard confidence.accept(piece: text, probability: probability) else { return .lowConfidence }
        raw += text
        if !text.isEmpty { emittedPieces += 1 }
        if (!text.isEmpty && CotypingDecodeStopPolicy.verdict(accumulated: raw, tokensGenerated: emittedPieces) != nil)
            || freeTokens >= maxTokens { return .complete }
        return .active
    }

    static func ranked(_ candidates: [Self], limit: Int, completed: Bool) -> [Self] {
        Array(candidates.sorted { lhs, rhs in
            let left = completed ? lhs.score : lhs.logProbability
            let right = completed ? rhs.score : rhs.logProbability
            if left != right { return left > right }
            return lhs.tokens.lexicographicallyPrecedes(rhs.tokens)
        }.prefix(max(0, limit)))
    }
}
