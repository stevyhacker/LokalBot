import Foundation

/// Experimental, memory-only memoization of the model's raw next-token logits.
/// An exact token key is required: similar text is never a cache hit. The runtime
/// owns one model and one explicit scope; neither token IDs nor logits are saved.
struct CotypingLogitCache {
    private struct Entry {
        var tokens: [Int32]
        var logits: [Float]
        var created: TimeInterval
        var bytes: Int { tokens.count * MemoryLayout<Int32>.stride + logits.count * MemoryLayout<Float>.stride }
    }

    let capacity: Int
    let byteLimit: Int
    let lifetime: TimeInterval
    private var entries: [Entry] = [] // oldest access first
    private(set) var scope: String?
    var count: Int { entries.count }
    var bytes: Int { entries.reduce(0) { $0 + $1.bytes } }

    init(capacity: Int = 16, byteLimit: Int = 32 * 1024 * 1024, lifetime: TimeInterval = 30) {
        self.capacity = max(0, capacity)
        self.byteLimit = max(0, byteLimit)
        self.lifetime = max(0, lifetime)
    }

    /// Returns true when the caller must invalidate its native KV state too.
    mutating func setScope(_ value: String?) -> Bool {
        let value = value.flatMap { $0.isEmpty ? nil : $0 }
        guard value != scope || value == nil else { return false }
        removeAll()
        scope = value
        return true
    }

    mutating func removeAll() { entries.removeAll(); scope = nil }

    mutating func value(for tokens: [Int32], now: TimeInterval) -> [Float]? {
        expire(now: now)
        guard scope != nil, let index = entries.firstIndex(where: { $0.tokens == tokens }) else { return nil }
        let entry = entries.remove(at: index)
        entries.append(entry)
        return entry.logits
    }

    mutating func insert(tokens: [Int32], logits: [Float], now: TimeInterval) {
        expire(now: now)
        guard scope != nil, capacity > 0, !tokens.isEmpty, !logits.isEmpty else { return }
        let entry = Entry(tokens: tokens, logits: logits, created: now)
        guard entry.bytes <= byteLimit else { return }
        entries.removeAll { $0.tokens == tokens }
        entries.append(entry)
        while entries.count > capacity || bytes > byteLimit { entries.removeFirst() }
    }

    private mutating func expire(now: TimeInterval) {
        entries.removeAll { now < $0.created || now - $0.created >= lifetime }
    }
}

struct CotypingLogitCacheDiagnostics: Codable, Sendable {
    var enabled = false
    var hits = 0
    var misses = 0
    /// Tokens submitted to native decode, including a decode that was aborted.
    var decodedTokens = 0
    var entries = 0
    var bytes = 0
    /// This is the existing raw first-word gate, not a calibrated acceptance probability.
    var firstWordProbability: Float?
    var firstWordGateSettled: Bool?
    var hybridFallbackProbability: Float?
    var hybridPrimaryPassed: Bool?
    var hybridUsedFallback: Bool?
}
