import XCTest
@testable import LokalBot

final class CotypingCandidateSearchTests: XCTestCase {
    func testReplayControlsRejectUnsupportedCombinationsAndRemoteUse() throws {
        let local = CotypingQualityReplay.Engine.local(model: URL(fileURLWithPath: "/synthetic.gguf"))
        let remote = CotypingQualityReplay.Engine.remote(
            baseURL: try XCTUnwrap(URL(string: "https://example.invalid")), model: "synthetic", extraBodyJSON: nil)
        for fields in [#""firstWordThreshold":-1"#, #""firstWordThreshold":1.01"#,
                       #""firstWordThreshold":0.2,"confidenceGate":false"#,
                       #""candidateRanking":"sum""#,
                       #""decoderCandidates":4,"confidenceBoundaryMode":"boundaryMass""#,
                       #""decoderCandidates":4,"stopAtDisplayLimit":true"#] {
            let input = try JSONDecoder().decode(CotypingQualityReplay.Input.self,
                                                from: Data("{\"cases\":[],\(fields)}".utf8))
            XCTAssertThrowsError(try CotypingQualityReplay.validateDecoderExperiments(input, engine: local))
        }
        for fields in [#""firstWordThreshold":0.2"#, #""confidenceBoundaryMode":"boundaryMass""#,
                       #""decoderCandidates":4,"candidateRanking":"sum""#, #""stopAtDisplayLimit":true"#] {
            let input = try JSONDecoder().decode(CotypingQualityReplay.Input.self,
                                                from: Data("{\"cases\":[],\(fields)}".utf8))
            XCTAssertNoThrow(try CotypingQualityReplay.validateDecoderExperiments(input, engine: local))
            XCTAssertThrowsError(try CotypingQualityReplay.validateDecoderExperiments(input, engine: remote))
        }
    }

    func testRerankingChangesSelectionWithoutChangingCandidateSet() {
        var short = CotypingSearchCandidate(requiredPrefix: [], minimumProbability: 0.1)
        var long = short
        _ = short.append(token: 1, bytes: Array(" cat".utf8), logProbability: -0.8, probability: 0.45, maxTokens: 4)
        _ = long.append(token: 2, bytes: Array(" dog".utf8), logProbability: -0.5, probability: 0.6, maxTokens: 4)
        _ = long.append(token: 3, bytes: Array(" next".utf8), logProbability: -0.5, probability: 0.6, maxTokens: 4)
        XCTAssertEqual(CotypingCandidateRanking.mean.ordered([short, long]).first?.tokens, [2, 3])
        XCTAssertEqual(CotypingCandidateRanking.sum.ordered([short, long]).first?.tokens, [1])
        XCTAssertEqual(CotypingCandidateRanking.firstWord.ordered([short, long]).first?.tokens, [1])
        XCTAssertEqual(CotypingCandidateRanking.sum.ordered([short, long]).count, 2)
    }

    func testExperimentRequiresExplicitSupportedWidth() throws {
        func mode(_ json: String) throws -> CotypingDecoderMode {
            try CotypingQualityReplay.decoderMode(for: JSONDecoder().decode(
                CotypingQualityReplay.Input.self, from: Data(json.utf8)))
        }
        XCTAssertEqual(try mode(#"{"cases":[]}"#), .sampled)
        XCTAssertEqual(try mode(#"{"cases":[],"decoderCandidates":2}"#), .candidates2)
        XCTAssertEqual(try mode(#"{"cases":[],"decoderCandidates":4}"#), .candidates4)
        XCTAssertThrowsError(try mode(#"{"cases":[],"decoderCandidates":3}"#))
        XCTAssertThrowsError(try mode(#"{"cases":[],"decoderCandidates":0}"#))
    }

    func testSiblingHealingAndConfidenceAreIndependent() {
        let parent = CotypingSearchCandidate(requiredPrefix: Array(" fol".utf8), minimumProbability: 0.1)
        var follow = parent
        var fold = parent
        XCTAssertEqual(follow.append(token: 1, bytes: Array(" follow".utf8), logProbability: log(0.4),
                                     probability: 0.4, maxTokens: 6), .active)
        XCTAssertEqual(fold.append(token: 2, bytes: Array(" fold".utf8), logProbability: log(0.05),
                                   probability: 0.05, maxTokens: 6), .lowConfidence)
        XCTAssertEqual(follow.raw, "low")
        XCTAssertEqual(follow.confidence.probability, 0.4)
        XCTAssertEqual(parent.remainingPrefix, Array(" fol".utf8))
        XCTAssertEqual(parent.confidence.probability, 1)
    }

    func testNativeCandidateModesAreRejectedForRemoteReplay() throws {
        let remote = CotypingQualityReplay.Engine.remote(
            baseURL: try XCTUnwrap(URL(string: "https://example.invalid/v1")),
            model: "synthetic", extraBodyJSON: nil)
        for width in [1, 2, 4] {
            let input = try JSONDecoder().decode(CotypingQualityReplay.Input.self,
                                                from: Data("{\"cases\":[],\"decoderCandidates\":\(width)}".utf8))
            if width == 1 {
                XCTAssertEqual(try CotypingQualityReplay.decoderMode(for: input, engine: remote), .sampled)
            } else {
                XCTAssertThrowsError(try CotypingQualityReplay.decoderMode(for: input, engine: remote))
            }
        }
    }

    func testHealingDoesNotConsumeFreeTokenBudgetOrShowTypedBytes() {
        var branch = CotypingSearchCandidate(requiredPrefix: Array(" tomorro".utf8), minimumProbability: 0)
        XCTAssertEqual(branch.append(token: 1, bytes: Array(" tomorro".utf8), logProbability: -1,
                                     probability: 0.3, maxTokens: 1), .active)
        XCTAssertEqual(branch.raw, "")
        XCTAssertEqual(branch.freeTokens, 0)
        XCTAssertEqual(branch.append(token: 2, bytes: Array("w".utf8), logProbability: -0.5,
                                     probability: 0.6, maxTokens: 1), .complete)
        XCTAssertEqual(branch.raw, "w")
    }

    func testIncompleteUTF8StateIsNotSharedBySiblings() {
        var parent = CotypingSearchCandidate(requiredPrefix: [], minimumProbability: 0)
        XCTAssertEqual(parent.append(token: 1, bytes: [0xC3], logProbability: -1,
                                     probability: 0.4, maxTokens: 2), .active)
        var acute = parent
        var diaeresis = parent
        XCTAssertEqual(acute.append(token: 2, bytes: [0xA9], logProbability: -1,
                                    probability: 0.4, maxTokens: 2), .complete)
        XCTAssertEqual(diaeresis.append(token: 3, bytes: [0xAB], logProbability: -1,
                                       probability: 0.4, maxTokens: 2), .complete)
        XCTAssertEqual(acute.raw, "é")
        XCTAssertEqual(diaeresis.raw, "ë")
        XCTAssertEqual(parent.raw, "")
    }

    func testMismatchedHealingAndNonfiniteScoresAreRejected() {
        var branch = CotypingSearchCandidate(requiredPrefix: Array(" cat".utf8), minimumProbability: 0)
        XCTAssertEqual(branch.append(token: 1, bytes: Array(" dog".utf8), logProbability: -1,
                                     probability: 0.4, maxTokens: 6), .invalid)
        XCTAssertEqual(branch.raw, "")
        XCTAssertEqual(branch.append(token: 1, bytes: [], logProbability: .nan,
                                     probability: .nan, maxTokens: 6), .invalid)
    }

    func testRankingUsesWholeContinuationAndDeterministicTies() {
        func candidate(_ tokens: [Int32], _ logProbability: Double) -> CotypingSearchCandidate {
            var result = CotypingSearchCandidate(requiredPrefix: [], minimumProbability: 0)
            result.tokens = tokens
            result.logProbability = logProbability
            return result
        }
        let weak = candidate([1, 2], -4)
        let strong = candidate([3, 4], -1)
        let tied = candidate([5, 6], -1)
        let ranked = CotypingSearchCandidate.ranked([weak, tied, strong], limit: 2, completed: true)
        XCTAssertEqual(ranked.map(\.tokens), [[3, 4], [5, 6]])
        let short = candidate([0], -0.8)
        XCTAssertEqual(CotypingSearchCandidate.ranked([short, strong], limit: 1, completed: true).first?.tokens, [3, 4])
    }

    func testBatchedCandidatesMatchIndependentColdTokenScoresAndRecoverAfterCancellation() async throws {
        guard let model = ProcessInfo.processInfo.environment["LOKALBOT_CANDIDATE_TEST_MODEL"] else {
            throw XCTSkip("Set LOKALBOT_CANDIDATE_TEST_MODEL to an attention GGUF for native branch validation.")
        }
        for mode in [CotypingDecoderMode.candidates2, .candidates4] {
            let runtime = LlamaCotypingRuntime(decoderMode: mode)
            try await runtime.loadIfNeeded(modelPath: model)
            for text in ["The meeting is scheduled for", "Molim te pošalji izveštaj", String(repeating: "The project notes mention testing. ", count: 100) + "The next step is"] {
                let prompt = await runtime.tokenize(text, addBOS: true)
                let result = try await runtime.generateCandidates(
                    promptTokens: prompt, maxTokens: 6, samplerSpecs: LlamaSamplerSpec.specs(from: .standard),
                    requiredPrefixUTF8: [32], preferWordExtendingOvershoot: false, minimumFirstWordProbability: 0)
                XCTAssertFalse(result.candidates.isEmpty)
                XCTAssertGreaterThan(result.diagnostics.peakActiveCandidates, 1)
                XCTAssertLessThanOrEqual(result.diagnostics.peakActiveCandidates, mode.width)
                let reused = try await runtime.generateCandidates(
                    promptTokens: prompt, maxTokens: 6, samplerSpecs: LlamaSamplerSpec.specs(from: .standard),
                    requiredPrefixUTF8: [32], preferWordExtendingOvershoot: false, minimumFirstWordProbability: 0)
                XCTAssertEqual(reused.diagnostics.prefillTokens, 1)
                XCTAssertFalse(reused.candidates.isEmpty)
                for candidate in reused.candidates {
                    let cold = try await runtime.coldScore(promptTokens: prompt, continuationTokens: candidate.tokens)
                    XCTAssertEqual(candidate.logProbability, cold, accuracy: 0.015,
                                   "Copied/batched state must match a cold replay of the exact token path")
                }
            }
            let prompt = await runtime.tokenize("Thanks for your help with", addBOS: true)
            let gate = CandidateTestGate()
            let cancelled = Task {
                await gate.wait()
                return try await runtime.generateCandidates(
                    promptTokens: prompt, maxTokens: 6, samplerSpecs: LlamaSamplerSpec.specs(from: .standard),
                    requiredPrefixUTF8: [32], preferWordExtendingOvershoot: false, minimumFirstWordProbability: 0)
            }
            cancelled.cancel()
            await gate.open()
            do { _ = try await cancelled.value; XCTFail("Cancelled search must not publish candidates") } catch is CancellationError { }
            let recovered = try await runtime.generateCandidates(
                promptTokens: prompt, maxTokens: 6, samplerSpecs: LlamaSamplerSpec.specs(from: .standard),
                requiredPrefixUTF8: [32], preferWordExtendingOvershoot: false, minimumFirstWordProbability: 0)
            XCTAssertFalse(recovered.candidates.isEmpty)
            await runtime.unload()
        }
    }
}

private actor CandidateTestGate {
    private var isOpen = false
    private var waiters: [CheckedContinuation<Void, Never>] = []
    func wait() async {
        if isOpen { return }
        await withCheckedContinuation { waiters.append($0) }
    }
    func open() {
        isOpen = true
        waiters.forEach { $0.resume() }
        waiters.removeAll()
    }
}
