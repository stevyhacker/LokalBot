import XCTest
@testable import LokalBot

final class CotypingLogitCacheTests: XCTestCase {
    func testExactTokensLRUAndBoundedBytes() {
        var cache = CotypingLogitCache(capacity: 2, byteLimit: 24)
        XCTAssertTrue(cache.setScope("doc"))
        cache.insert(tokens: [1], logits: [2, 3], now: 0)
        cache.insert(tokens: [2], logits: [4, 5], now: 0)
        XCTAssertEqual(cache.value(for: [1], now: 1), [2, 3])
        cache.insert(tokens: [3], logits: [6, 7], now: 1)
        XCTAssertNil(cache.value(for: [2], now: 1))
        XCTAssertNil(cache.value(for: [1, 2], now: 1))
        XCTAssertEqual(cache.count, 2)
        XCTAssertEqual(cache.bytes, 24)
        cache.insert(tokens: [4], logits: [Float](repeating: 0, count: 10), now: 1)
        XCTAssertEqual(cache.count, 2)
        XCTAssertLessThanOrEqual(cache.bytes, cache.byteLimit)
    }

    func testTTLIsNotExtendedByHitsAndBackwardClockExpires() {
        var cache = CotypingLogitCache(lifetime: 30)
        _ = cache.setScope("doc")
        cache.insert(tokens: [1], logits: [1], now: 10)
        XCTAssertNotNil(cache.value(for: [1], now: 39))
        XCTAssertNil(cache.value(for: [1], now: 40))
        cache.insert(tokens: [1], logits: [1], now: 50)
        XCTAssertNil(cache.value(for: [1], now: 49))
    }

    func testScopeUnknownScopeAndDeletionForgetEveryEntry() {
        var cache = CotypingLogitCache()
        cache.insert(tokens: [1], logits: [2], now: 0)
        XCTAssertEqual(cache.count, 0)
        _ = cache.setScope("one")
        cache.insert(tokens: [1], logits: [2], now: 0)
        XCTAssertFalse(cache.setScope("one"))
        XCTAssertNotNil(cache.value(for: [1], now: 1))
        XCTAssertTrue(cache.setScope("two"))
        XCTAssertNil(cache.value(for: [1], now: 1))
        cache.insert(tokens: [1], logits: [2], now: 1)
        cache.removeAll()
        XCTAssertEqual(cache.bytes, 0)
        XCTAssertNil(cache.scope)
        _ = cache.setScope("")
        cache.insert(tokens: [1], logits: [2], now: 2)
        XCTAssertEqual(cache.count, 0)
    }

    func testReplayCacheIsOptInAndRejectsRemoteAndBeamCombinations() throws {
        func fixture(_ extra: String) throws -> CotypingQualityReplay.Input {
            try JSONDecoder().decode(CotypingQualityReplay.Input.self, from: Data("{\"cases\":[],\(extra)}".utf8))
        }
        let local = CotypingQualityReplay.Engine.local(model: URL(fileURLWithPath: "/synthetic.gguf"))
        let remote = CotypingQualityReplay.Engine.remote(baseURL: try XCTUnwrap(URL(string: "https://example.invalid")),
                                                        model: "synthetic", extraBodyJSON: nil)
        XCTAssertFalse(try CotypingQualityReplay.logitCacheMode(for: fixture("\"maxWords\":4"), engine: local))
        XCTAssertTrue(try CotypingQualityReplay.logitCacheMode(for: fixture("\"logitCache\":true"), engine: local))
        XCTAssertThrowsError(try CotypingQualityReplay.logitCacheMode(for: fixture("\"logitCache\":true"), engine: remote))
        XCTAssertThrowsError(try CotypingQualityReplay.logitCacheMode(for: fixture("\"logitCache\":true,\"decoderCandidates\":2"), engine: local))
        let dynamic = try JSONDecoder().decode(CotypingQualityReplay.Input.self,
                                              from: Data(#"{"cases":[{"id":"a","prefix":"Hi ","cancelAfterMs":-1}]}"#.utf8))
        XCTAssertThrowsError(try CotypingQualityReplay.logitCacheMode(for: dynamic, engine: local))
    }

    func testNativeCacheMatchesControlAcrossHealingBackspaceScopeAndCancellation() async throws {
        guard let model = ProcessInfo.processInfo.environment["LOKALBOT_CANDIDATE_TEST_MODEL"] else {
            throw XCTSkip("Set LOKALBOT_CANDIDATE_TEST_MODEL for native cache equivalence.")
        }
        let long = String(repeating: "The notes describe the project and its tests. ", count: 90)
        let cases: [(String, String, String?)] = [
            ("The meeting is scheduled for", " ", "one"),
            ("The meeting is scheduled for", " tom", "one"),
            ("The meeting is scheduled for", " tomor", "one"),
            ("The meeting is scheduled for", " ", "one"),
            ("The meeting is scheduled for next", " ", "one"),
            ("Molim te pošalji", " iz", "one"),
            ("The meeting is scheduled for", " ", "one"),
            (long + "Next we should", " ", "long"),
            (long + "Next we should", " te", "long"),
            (long + "Next we should", " ", "long"),
            ("The meeting is scheduled for", " ", "two"),
            ("The meeting is scheduled for", " ", nil)
        ]
        var expected: [String] = []
        for enabled in [false, true] {
            let runtime = LlamaCotypingRuntime(logitCacheEnabled: enabled)
            try await runtime.loadIfNeeded(modelPath: model)
            var hits = 0
            for (index, item) in cases.enumerated() {
                let tokens = await runtime.tokenize(item.0, addBOS: true)
                let specs = index == 3
                    ? LlamaSamplerSpec.specs(temperature: 0.7, topK: 20, topP: 0.7, minP: 0.08,
                                             repeatPenalty: 1.05, repeatLastN: 64, seed: 42)
                    : LlamaSamplerSpec.specs(from: .standard)
                let result = try await runtime.generate(
                    promptTokens: tokens, maxTokens: 6, samplerSpecs: specs,
                    requiredPrefixUTF8: Array(item.1.utf8), minimumFirstWordProbability: 0,
                    cacheScope: item.2, onToken: { _ in true })
                let diagnostics = await runtime.lastCacheDiagnostics
                hits += diagnostics.hits
                if enabled { XCTAssertEqual(result, expected[index], "Case \(index)") } else { expected.append(result) }
                if enabled, index == 0 || index == 7 || index >= 10 { XCTAssertEqual(diagnostics.hits, 0) }
            }
            if enabled {
                XCTAssertGreaterThan(hits, 0)
                await runtime.clearLogitCache()
                let tokens = await runtime.tokenize(long + "The following action is", addBOS: true)
                let pending = Task {
                    try await withTaskCancellationHandler {
                        try await runtime.generate(promptTokens: tokens, maxTokens: 100,
                                                   samplerSpecs: LlamaSamplerSpec.specs(from: .standard),
                                                   cacheScope: "cancel", onToken: { _ in true })
                    } onCancel: { runtime.abortInFlightDecode() }
                }
                try await Task.sleep(for: .milliseconds(2))
                pending.cancel()
                do { _ = try await pending.value; XCTFail("Cold long prefill must honor cancellation") } catch is CancellationError { }
                let prompt = await runtime.tokenize(cases[0].0, addBOS: true)
                let recovered = try await runtime.generate(
                    promptTokens: prompt, maxTokens: 6, samplerSpecs: LlamaSamplerSpec.specs(from: .standard),
                    requiredPrefixUTF8: [32], cacheScope: "one", onToken: { _ in true })
                XCTAssertEqual(recovered, expected[0])
                let diagnostics = await runtime.lastCacheDiagnostics
                XCTAssertEqual(diagnostics.hits, 0)
                await runtime.handleMemoryPressure(isCritical: false)
                let cleared = try await runtime.generate(
                    promptTokens: prompt, maxTokens: 6, samplerSpecs: LlamaSamplerSpec.specs(from: .standard),
                    requiredPrefixUTF8: [32], cacheScope: "one", onToken: { _ in true })
                XCTAssertEqual(cleared, expected[0])
                let afterPressure = await runtime.lastCacheDiagnostics
                XCTAssertEqual(afterPressure.hits, 0)
            }
            await runtime.unload()
        }
    }

    @MainActor
    func testRepeatedColdCancellationPreservesNextSuggestion() async throws {
        guard let model = ProcessInfo.processInfo.environment["LOKALBOT_CANDIDATE_TEST_MODEL"] else {
            throw XCTSkip("Set LOKALBOT_CANDIDATE_TEST_MODEL for native cancellation recovery.")
        }
        func request(_ prefix: String) throws -> CotypingRequest {
            let field = CotypingField(
                appName: "Notes", bundleID: "com.apple.Notes", processID: 0, role: "AXTextArea",
                precedingText: prefix, trailingText: "", selectionLength: 0, caretRect: .zero,
                isSecure: false, caretIsExact: true)
            return try XCTUnwrap(CotypingRequestBuilder.build(
                field: field, config: .standard, personalization: .none, generation: 1,
                wordPrefixIsValidWord: true))
        }
        let requests = try ["Molim te pošalji", "Možeš li potvrditi", "Please review today's"].map(request)
        let cancelledRequest = try request(String(repeating:
            "Synthetic cancellation prefill with a separate token history. ", count: 90))
        let runtime = LlamaCotypingRuntime(logitCacheEnabled: true)
        let engine = LocalLlamaCotypingEngine(runtime: runtime, modelPath: model)
        engine.replayCacheScope = "recovery-test"
        try await engine.prewarm()
        var expected: [CotypingNormalizationResult] = []
        for item in requests {
            await engine.clearReplayCache()
            expected.append(try await engine.generate(item))
        }
        // A single recovery passed even with the backend-clear race present.
        // Vary cancellation timing and repeatedly check against cold output.
        for iteration in 0..<96 {
            await engine.clearReplayCache()
            let pending = Task { try await engine.generate(cancelledRequest) }
            try await Task.sleep(for: .milliseconds(1 + iteration % 3))
            pending.cancel()
            do { _ = try await pending.value; XCTFail("Cold prefill must cancel") } catch is CancellationError { }
            let index = iteration % requests.count
            let result = try await engine.generate(requests[index])
            XCTAssertEqual(result.text, expected[index].text, "Recovery \(iteration)")
            XCTAssertEqual(result.suppression, expected[index].suppression, "Recovery \(iteration)")
            XCTAssertEqual(engine.lastCacheDiagnostics?.hits, 0)
        }
        await engine.unload()
    }
}
