# Autocomplete quality replay

The [2026-10-02 quality report](results/2026-10-02-quality/REPORT.md) contains
held-out before/after results, a direct Cotabby comparison, tradeoffs and raw data.

`quality_replay.py` scores the production request builder, native llama engine,
token healing and normalizer. It runs before app startup and uses synthetic input
plus an explicit local model; it does not drive the UI, enable autocomplete,
read learned writing, or change installed settings. No prompt is uploaded.

Build Release with `CODE_SIGNING_ALLOWED=NO`, then run:

```sh
uv run --no-project python -S Benchmarks/Cotyping/quality_replay.py \
  --app .build/XcodeDerivedData/Build/Products/Release/LokalBot.app/Contents/MacOS/LokalBot \
  --model /absolute/path/to/model.gguf \
  --corpus /absolute/path/to/cotabby/CotabbyTests/Fixtures/phrase-prediction-1337.json \
  --split screen --output /absolute/path/to/new-results
```

Use the [Cotabby v2 synthetic corpus](https://github.com/FuJacob/cotabby/blob/8cdbea2d2619b0f89a73d46eb0bb856504d07343/CotabbyTests/Fixtures/phrase-prediction-1337.json)
from pinned revision `8cdbea2d2619b0f89a73d46eb0bb856504d07343` (AGPL-3.0).
It is supplied externally, with its SHA-256 recorded; the runner never downloads
or changes a corpus automatically. The independent `quality-cases.json` contains
32 original synthetic scenarios for email, formatting, longer documents and
multiple languages. Run it with `--split all`.

The screen split takes the first 20 IDs per category sorted by SHA-256 of
`1337:<phrase-id>`; heldout takes the other 171. Freeze a candidate before running
`--split heldout`. `--per-category` selects a deterministic smaller sample from
that partition. `--mode midword` tests every internal character position of words
after the first, separately from next-word checkpoints.

Only previously typed text and app/title/field metadata enter inference. Screen
text, category and future words do not. The reference always advances regardless
of the prediction. Correctness requires an exact first word after joining the
typed fragment and suggestion, ignoring case and straight/curly apostrophe
differences. Suppressed results and errors remain in the denominator. Two- and
three-word rates require consecutive matches and enough reference words remaining.
These lexical scores penalize valid alternate wording; they do not measure user
acceptance or semantic equivalence. The public corpus is English and synthetic.

Each run records app/model/corpus/script hashes, explicit overrides, exact input
requests, visible output, suppression, errors and latency. The process prewarms
the model first; reported latency excludes cold loading, keyboard handling,
debounce, AX validation and overlay presentation. Runs should be serial to avoid
GPU contention. A nonzero exit or missing observations is not a completed run.

The confidence gate (`CotypingFirstWordConfidence`) is on in replays as in the
product; an input with `"confidenceGate": false` turns it off to compare.
Suggestions it hides are recorded with the suppression `lowConfidence`.

`--prompt` and sampling/length flags are experimental controls. A release
qualification must use `--prompt production` and no overrides, so the actual
product renderer and defaults are measured. No experiment changes saved settings.

```sh
uv run --no-project python -S -m unittest discover -s Benchmarks/Cotyping -p 'test_quality_replay.py'
```

`compare_quality.py` checks matching corpora/checkpoints and computes paired,
whole-phrase, category-stratified bootstrap intervals. `compare_cotabby.py`
restricts completed runs to the same deterministic held-out sample, verifies
identical prefixes and surface metadata, and checks that the common lexical
scorer agrees with Cotabby's own scorer. Each product retains its production
prompt and output-length policy; compare first-word accuracy, not generation
latency at unequal completion lengths.

`verify_context_replay.py <result-directory>` checks exact retention of typed
text in the independent challenge's rendered prompts. It intentionally fails
on the original engine, providing a regression control for paragraph and caret
whitespace preservation. Python tools use only the standard library; `-S`
avoids loading unrelated site startup hooks.

## Two- and four-candidate decoder experiment

The [updated-master results](results/2026-10-10-candidates-master/REPORT.md)
include PRs #228 and #229 and compare both widths with the current decoder on
the same Gemma model and production prompts. The
[pre-merge run](results/2026-10-10-candidates/REPORT.md) is retained separately.

`candidate_benchmark.py` compares the current single sampled continuation with
an opt-in native beam of at most two or four active token paths. The normal app
selector and saved settings still use the current decoder. The experiment is
available through the headless replay's `decoderCandidates` input (`1`, `2`, or
`4`), or `quality_replay.py --decoder-candidates 2`.
Widths 2 and 4 require a local model; both the CLI and native replay reject
them for hosted endpoints before starting inference.

The experiment shares prompt KV state, copies all parent sequence references
before recycling slots, and batches one token from each surviving branch.
Healing bytes, UTF-8 decoding, confidence and stop state are independent per
branch. Expansion uses the existing healing constraints and sampler filters;
it replaces the distribution draw with ranked alternatives. Active paths are
pruned by cumulative raw log probability. Completed paths are ranked by mean
raw log probability per generated token, including healing tokens. EOG is a
stop marker and is not scored. The production normalizer chooses the first
nonempty finalist. Only the selected final suggestion is published; speculative
partials are withheld. This ranking is a hypothesis, not a learned quality model.

The model, production prompt, per-branch token budget, confidence gate and
normalizer stay fixed. A logical branch retains the 2,048-token context limit;
the experimental unified KV allocation grows with beam width. Attention models
are supported. Hybrid/recurrent models fail explicitly until native state-copy
equivalence has been established for them.

```sh
uv run --no-project python -S Benchmarks/Cotyping/candidate_benchmark.py \
  --app /absolute/path/to/Release/LokalBot.app/Contents/MacOS/LokalBot \
  --model /absolute/path/to/gemma-4-E2B.i1-Q6_K.gguf \
  --corpus /absolute/path/to/cotabby/CotabbyTests/Fixtures/phrase-prediction-1337.json \
  --output /absolute/path/to/new-results
```

Defaults select eight public held-out phrases per category, the 32 original
challenge phrases, and two fixed internal checkpoints per selected public
phrase: 600 checkpoints in the pinned corpus. Three serial rounds rotate the
order `1/2/4`, `2/4/1`, `4/1/2`. No model or prompt tuning occurs between runs.
The runner requires exact rendered-prompt equality, ordered complete results,
the requested native search width and zero errors. It hashes the app, model,
source, corpus and scripts and records peak process RSS. Latency covers a warm
complete engine request, not first-partial display or end-to-end typing latency.

First-word reference agreement, coverage, incorrect suggestions shown and
two-/three-word agreement describe the selected suggestion. The separate
`oracleFirstWordMatches` metric asks whether *any* finalist matches; it is a
diagnostic ceiling, not achieved suggestion quality. Repeated outputs are not
treated as new independent examples: paired bootstrap intervals resample whole
phrases, with public word and midword checkpoints kept in the same cluster.
All timing rounds and repeat variation are retained.

`CotypingCandidateSearchTests` checks independent branch state and ranking.
Set `TEST_RUNNER_LOKALBOT_CANDIDATE_TEST_MODEL` to an attention GGUF when running
that non-UI XCTest suite through `xcodebuild`. Its native test compares batched
branch scores after warm prompt reuse against independent cold token replays,
including long and Serbian prompts, and checks cancellation/recovery.

```sh
uv run --no-project python -S -m unittest discover \
  -s Benchmarks/Cotyping -p 'test_candidate_benchmark.py'
```

## Hosted model comparison

`remote_comparison.py` asks whether a hosted model would beat the local one by
enough to justify its latency. It runs the quality replay above once per
engine over identical checkpoints: the local model, then each candidate in
`remote-candidates.json`. Hosted engines get the same production prompt,
normalizer and scorer through the app's HTTP completion engine and raw
`/v1/completions`; only the generation backend differs. These runs send the
corpus's synthetic prompts to the providers. Nothing from a real library is read.

The candidates were picked from OpenRouter's per-provider latency stats but are
called through each provider's own API: Qwen3.8 27B on Cerebras, Gemma 4 31B on
Modular and Nemotron 3.5 Lightning on CoreWeave. Copy
`remote-autocomplete.env.example` outside the repository, fill in the keys and
`chmod 600` it. Each key reaches only its own provider's replay, as
`LOKALBOT_REPLAY_API_KEY`, and is never put on a command line.

```sh
uv run --no-project python -S Benchmarks/Cotyping/remote_comparison.py \
  --app /absolute/path/to/Release/LokalBot.app/Contents/MacOS/LokalBot \
  --local-model "$HOME/Library/Application Support/me.dotenv.LokalBot/models/gemma-4-E2B.i1-Q6_K.gguf" \
  --corpus /absolute/path/to/phrase-prediction-1337.json \
  --env-file ~/.config/lokalbot/remote-autocomplete.env \
  --output /absolute/path/to/new-results
```

With only an OpenRouter key, add `--via-openrouter`: each candidate then goes
through OpenRouter's raw completions with the same model, pinned to the same
provider with fallbacks off and prompt-retaining providers excluded. This adds
OpenRouter's own hop to every request, so its latency reads somewhat high
next to a direct call. Two routes differ (checked 2026-10-05): OpenRouter adds a
`reasoning_effort` field for Qwen3.8 27B that Cerebras's raw completions reject,
so that model runs on CoreWeave instead, which measures its quality but not
Cerebras's speed; and Gemma 4 31B has no usable route, because ModelRun has no
raw completions and the other hosts continue raw text as gibberish.
`openRouterProvider`, `openRouterLabel` and `openRouterNote` in
`remote-candidates.json` record this.

The default sample is 30 held-out phrases per category (about 1,200
checkpoints) plus the 32-scenario `quality-cases.json`. `--per-category 0`
runs the whole held-out split (6,667 checkpoints), and `--midword-per-category
10` adds mid-word completion on a separate sample, where hosted output must
re-type the healed word fragment. Add `--per-category 1 --skip-challenge` for a
smoke run, and `--only <id>` to run some candidates.
The hosted replays run side by side after the local one. A hosted replay
first sends one untimed request, so a wrong key, model ID or rejected field
stops it before any case. A rate limit or server error is retried up to five
times and only the answering attempt is timed; `retries` counts the extra
attempts. Hosted requests carry only the OpenAI sampling fields (temperature,
`top_p`, seed, stop); `extraBody` adds a provider's own fields such as `top_k`.

Hosted replays use the local engine's token healing. Every word checkpoint ends
in a space, and a model forced to continue after a bare space tokenizes badly:
Gemma 4 E2B served by a loopback llama-server scored 14.3% instead of 37.0% on
the same weights. The hosted prompt is therefore sent cut back to the word
boundary, and only output that re-types the cut text counts; anything else is
suppressed, because a hosted API cannot be constrained to that prefix. With
healing, the loopback server matched the in-process engine (37.0% vs 37.0% on
119 corpus checkpoints, 46.1% vs 46.6% on the 32 scenarios).

`REPORT.md` lists next-word, two- and three-word accuracy, the paired change
against the local model with its bootstrap interval, errors, retries, latency
percentiles and a rough input cost per 1,000 suggestions. Local latency is warm
in-process generation; hosted latency is the full HTTPS request from this Mac.
Neither includes debounce, Accessibility reads or drawing, which add the same
to both.

The replay can also be run directly with `quality_replay.py --completions-url
<base> --completions-model <id> --api-key-env <NAME>` in place of `--model`.

## Saved-memory replay

`memory-cases.json` contains only synthetic saved facts and draft checkpoints.
It measures whether autocomplete recalls an explicitly supplied owner, place,
date or technical detail, while ignoring unrelated facts. This is distinct
from predicting unseen facts or measuring actual user acceptance. Six cases
are for development; twelve factual cases and ten unrelated-writing controls
are held out. Freeze the app and source hashes before running held-out cases.

```sh
uv run --no-project python -S Benchmarks/Cotyping/memory_replay.py \
  --app /absolute/path/to/LokalBot.app/Contents/MacOS/LokalBot \
  --model /absolute/path/to/model.gguf \
  --split development --output /absolute/path/to/new-results
```

Use `--split heldout` after the freeze. Each paired run uses the same executable,
model, production defaults and saved facts with source permission off/on. Only
draft text, surface metadata and synthetic facts reach inference. Scoring also
checks selected source IDs, and byte-identical prompts/output for unrelated
controls. File, settings and revocation behavior are covered by the provider
and coordinator unit tests; this replay never opens a real library.

### Relevance supplement

`memory-relevance-cases.json` tests the other half of retrieval: leaving writing
alone when no saved fact is relevant. Its saved facts are realistic meeting-note
lines, mostly commitments from generically titled meetings ("Marko will get back
to you on Friday about the invoice."). Distractor drafts share everyday wording
with one of them but name no topic ("I'll get back to "), so the right behavior
is to retrieve nothing and give the same suggestion as with memory off. Relevant
drafts name a topic, including harder forms than the original fixture: a
lowercase name, a fact filed under a generic meeting title, a title matched by
two of its three words, a name with diacritics, and a draft that already
mentions the answer while an outdated version of the fact is also saved.

```sh
uv run --no-project python -S Benchmarks/Cotyping/memory_replay.py \
  --app /absolute/path/to/LokalBot.app/Contents/MacOS/LokalBot \
  --model /absolute/path/to/model.gguf \
  --corpus Benchmarks/Cotyping/memory-relevance-cases.json \
  --split heldout --output /absolute/path/to/new-results
```

The scorer reports recall and abstention together. A control (`irrelevant` or
`distractor`) passes only when no fact was selected and its prompt and output
match the memory-off run; `falseRetrievals` counts controls that selected
anything. `balancedRelevance` is the mean of the recall and abstention rates, so
a change that recalls more by retrieving indiscriminately does not score higher.
See the [relevance results](results/2026-10-03-relevance/REPORT.md).

Retrieval is also scored without a model: `CotypingMemoryRelevanceTests` runs
every case of all four fixtures through the production selection on each unit
test run, so a threshold change that loses a relevant fact or borrows an
unrelated one fails before any replay.


## Exact-prefix logit-cache experiment

The [2026-10-10 results](results/2026-10-10-cache/REPORT.md) include the ranking
audit, four corrected comparison rounds and the cancellation-recovery fix.
The cache preserved output but regressed held-out p95; it remains disabled.

`cache_benchmark.py` compares the current sampled decoder, a bounded raw-logit
cache, and the existing two/four-candidate modes with identical model weights,
production prompts, sampling, token healing, confidence and normalization.
All modes remain headless experiments; the app selector still chooses the
original decoder. Cache plus beam search is rejected, as is a cache experiment
on a hosted or recurrent/hybrid engine.

The cache memoizes the model's full raw next-token logits for **exact token
prefixes**. It reruns the sampler and healing/stop/confidence logic on every
request; it does not replay a saved suggestion. A hit can skip model decoding.
On a miss, native KV is reconciled against the last **physically decoded** token
sequence, which can differ from the logical sequence after cache hits. Partial
reuse still requires a successful native `seq_rm`; otherwise the prefix is
decoded again. This experiment adds logit reuse, not multiple retained native
KV snapshots.

Storage is memory-only: at most 16 entries and 32 MiB of token/logit payload,
with a 30-second reuse lifetime measured from insertion. Access changes LRU
order but does not extend eligibility. Expired entries are removed on the next
cache access; there is no background erasure timer. The runtime owns one loaded model and one explicit
synthetic scope; changing or omitting scope invalidates reuse. Cancellation,
explicit clear, unload/model change and memory pressure also invalidate it.
The byte cap excludes model/KV memory, sampler scratch and the active logit
array; the benchmark separately records process peak RSS. Enabling this in the
normal app would additionally require wiring real field/permission/forget
invalidation and remote UI validation.

The headless input accepts `logitCache: true` and optional per-case `cacheScope`,
`resetCache`, `delayBeforeMs`, and `cancelAfterMs`. Expected cancellation emits
`cancelled: true` and latency from issuing cancellation to request completion,
never partial output. This is task quiescence, not an independent measurement of
GPU completion: experimental cache cleanup explicitly joins backend work before
zeroing KV buffers, while the current decoder retains its original cleanup.
These controls are excluded from the model prompt. Observations report cache
hits, misses, native decode work, retained bytes, and the existing first-word
gate's raw probability when it actually weighed a token. That value is not a
calibrated user-acceptance probability. Candidate runs also record token/healing
counts and raw sequence scores for ranking analysis.

First extract the previous candidate evidence archive; its `raw-runs` directory
contains the frozen 600-checkpoint quality input and references. Then run:

```sh
uv run --no-project python Benchmarks/Cotyping/cache_benchmark.py \
  --app /absolute/path/to/LokalBot.app/Contents/MacOS/LokalBot \
  --model /absolute/path/to/gemma-4-E2B.i1-Q6_K.gguf \
  --prior /absolute/path/to/extracted/raw-runs \
  --output /absolute/path/to/new-results
```

Four rounds rotate all four quality arms through each position. Dynamic runs
alternate control/cache order using `cache-typing-cases.json`: four development
and twelve held-out synthetic traces covering forward typing, backspace,
divergence, repeats, scope changes, explicit clear, unknown scope and actual
in-flight cancellation. They serialize requests with short pauses and explicit
abort deadlines. They do not simulate the whole coordinator, UI debounce,
completed-suggestion cache, overlay publication or human acceptance. Report
exact-repeat steps separately because the existing suggestion cache may already
serve them in the real app. It also restores valid tails for some backspace and
typing-through paths, so other headless edit gains can overlap existing behavior.

The cache gate requires identical noncancelled text and suppression, successful
invalidation checks, bounded storage and improved held-out p95 engine latency.
Repeated quality runs are not new independent examples. No ranking or confidence
threshold is tuned on this previously observed quality set. `ranking_audit.py`
describes finalist diversity, reference-oracle headroom, uniform-random finalist
expectation and fixed score/probability bins. Suppressed/pruned branches cannot
be reconstructed, and exact-reference disagreement includes valid alternatives.

```sh
uv run --no-project python Benchmarks/Cotyping/ranking_audit.py \
  --observations /absolute/path/to/observations.jsonl \
  --references /absolute/path/to/references.json \
  --output /absolute/path/to/ranking-audit.json
uv run --no-project python -m unittest discover -s Benchmarks/Cotyping -p 'test_*.py'
```

Native XCTest coverage is `CotypingLogitCacheTests`. To enable actual model
parity/cancellation tests through Xcode, set
`TEST_RUNNER_LOKALBOT_CANDIDATE_TEST_MODEL` to the Gemma GGUF path (Xcode strips
the `TEST_RUNNER_` prefix before launching the test host). Use an isolated
`TEST_RUNNER_LOKALBOT_STORAGE_ROOT`. These are non-UI tests.

## Visible context and memory replay

The [visible-context results](results/2026-10-02-visible-context/REPORT.md) record
the frozen prompt evaluation, retrieval regression, and fresh integration supplement.

`visible-context-cases.json` contains 40 original synthetic screen trees, saved
facts, and draft checkpoints: eight development cases and 32 held out. Trees
include text regions, roles, frames, hidden/secure flags, window/field identity,
and origins. `CotypingVisibleContext.capture` traverses the same metadata/text
boundary in live AX and replay, so the eval tests selection before prompt assembly.
Rejected branches are never read; selected IDs and text-read IDs are recorded.
Reference answers, split labels and selection expectations stay outside inference.

```sh
uv run --no-project python -S Benchmarks/Cotyping/visible_context_replay.py \
  --app /absolute/path/to/LokalBot.app/Contents/MacOS/LokalBot \
  --model /absolute/path/to/model.gguf \
  --split development --output /absolute/path/to/new-results
```

Run serially for LFM and Gemma. Each invocation compares neither source, visible
text only, saved meeting memory only, and both. Freeze source/executable/corpus
hashes before `--split heldout`; do not tune on the held-out results. The default
three-word/five-token budget, renderer, sampler and normalizer are unchanged.
These cases test paraphrased factual continuations, current visible facts versus
older saved facts, form labels, Serbian, and independent privacy permissions.
Twelve held-out controls require identical prompts and completions across all
four conditions. Two ordinary-writing cases also test unrelated nearby content.

The scorer reports complete expected factual words anywhere in the short
continuation, separately from strict first-word accuracy, stale-fact errors,
source-selection accuracy, forbidden reads, suppression, errors and warm model
latency. Errors and suppressed results count as factual misses. Invalid,
reordered, duplicate or prompt-override runs are rejected. This is a small,
synthetic grounding test, not a measure of user acceptance, broad language
quality, live AX compatibility, or end-to-end typing latency. Model timing
excludes model loading, real AX, debounce and overlay work. Local runs are
headless inference and non-UI tests; real UI tests must run remotely.

```sh
uv run --no-project python -S -m unittest discover -s Benchmarks/Cotyping -p 'test_*replay.py'
```


`visible-memory-link-cases.json` adds a separate frozen supplement: two development
and four held-out generic replies whose project is named only in the visible
conversation. The production memory query must use the selected visible text,
and both source grants must be enabled to retrieve the corresponding saved fact.
Visible terms can match a saved source title; only the draft and enabled window
title can qualify the body-overlap fallback. This prevents incidental conversation
words from introducing an unrelated project's facts.
Run it with the same runner and `--corpus Benchmarks/Cotyping/visible-memory-link-cases.json`.
The original context fixture stays unchanged and is rerun as a regression set
when the retrieval integration changes. The scorer checks permission-dependent
source selections, so a correct guess cannot hide a missing or unauthorized lookup.

# Decoder optimization loop (2026-10-10)

The [experiment report](results/2026-10-10-decoder-loop/REPORT.md) records nine
attempts, fresh confirmation results, typing/cancellation measurements, and the
remaining quality tradeoffs. Production defaults are unchanged.

`decoder_loop.py` compares sampler settings, reranking the same four finalists,
and three first-word confidence scores with fixed weights and rendered prompts.
`decoder_dynamic.py` runs AB/BA synthetic typing, backspace, cancellation and
recovery traces for the display-limit stop. Both use the native headless replay;
neither starts UI automation or reads personal writing.

The controls are replay-only JSON fields, absent from saved product settings:

| Field | Values / behavior |
| --- | --- |
| `candidateRanking` | `mean` (existing), `sum`, `firstWord`; requires candidate width 2 or 4; changes final ranking only |
| `firstWordThreshold` | 0–1, default 0.1; does not gate a forced midword completion |
| `confidenceBoundaryMode` | `selectedToken` (existing), `wordOnly`, `boundaryMass`; single-path native decoder only |
| `stopAtDisplayLimit` | Stop after an extra word proves the visible word limit is complete; default false |

`wordOnly` omits a token that starts the next word. `boundaryMass` instead
multiplies by the summed probability of boundary-initial vocabulary tokens and
EOS. Its tokenizer mask handles complete Unicode scalars, excludes partial UTF-8
bytes and non-EOS control tokens, and is built before warm request timing. This
is a path-based confidence estimate, not an exact marginal over every possible
tokenization or a calibrated user-acceptance probability. Mixed tokens that
extend the first word still count in full. Midword behavior remains unchanged.

Prepare development inputs from an extracted candidate-benchmark archive and
supply a separately authored confirmation corpus. The entire public corpus was
already evaluated in the older 2026-10-02 study, so a new subset is not a fresh
confirmation set:

```sh
uv run --no-project python Benchmarks/Cotyping/decoder_loop.py prepare \
  --prior /path/to/extracted-candidate-benchmark \
  --confirmation-corpus /path/to/new-independent-phrases.json \
  --output /private/tmp/decoder-loop
```

Use `run --app <Release executable> --model <GGUF> --output <same directory>
--arms control greedy no-repeat-penalty longer-budget ungated beam4` for the
initial ablations. The second round uses `--round 2 --arms control
word-only-observe boundary-mass-observe beam4-sum beam4-first-word display-stop`.
`calibrate --output <directory>` fits only development observations; an explicit
`--thresholds .30 .31 .32 .33 .34 .35` records a finer development grid. Native
runs named `word-only-calibrated` and `boundary-mass-calibrated` load the frozen
settings from `calibration.json`; append `-stop` to combine with display stopping.
Freeze the selected arms before using `--split confirmation`, and counterbalance
timing rounds. Do not retune after reading confirmation results.

Report first-word matching, matching reference characters, multiword matching,
nonmatching shown suggestions, coverage, and complete-request latency together. Character
credit counts the reference span of consecutive matching whole words after the
caret; it is not observed keystrokes saved. This loop's 1,361-checkpoint
confirmation set contains 112 new English and Serbian phrases authored by a
tool-disabled Opus consultation blind to decoder settings and results. None
duplicates a phrase in the original corpus or challenge set. Bootstrap whole phrases;
repeated timings are not additional quality examples. The typing traces are an
existing regression fixture, not an independent confirmation corpus.

## Blinded usefulness judging

The [Claude judge report](results/2026-10-10-claude-judge/REPORT.md) includes the
five-policy comparison, repeated ratings, low-value-word sensitivity checks,
and the current-output length control. The follow-up native hybrid experiment is
described below; those earlier offline numbers are not native hybrid timings.

`claude_judge.py` evaluates saved synthetic outputs with Claude Opus as an offline
judge. Its five frozen display policies are current, boundary-mass, intersection,
union, and a hybrid that preserves current suggestions but caps newly admitted
suggestions at one word. The hybrid and set-combination policies are offline
compositions, not production implementations or native latency measurements.

Preparation includes all 213 changed decisions and up to twelve shared shown
suggestions per category. The judge sees only a typed prefix and shuffled,
anonymous continuations; future reference text, decoder names, probability
scores, and latency are excluded. Thirty-two cases repeat with new IDs and
reversed option order. The primary rubric is an ordinal usefulness score from
−2 to +2 relative to silence at zero. Whole-phrase resampling measures uncertainty
across this corpus, not uncertainty across people or independent judge models.

```sh
uv run --no-project python Benchmarks/Cotyping/claude_judge.py prepare \
  --source /path/to/extracted-decoder-loop/evaluation \
  --output /private/tmp/new-blinded-judge
uv run --no-project python Benchmarks/Cotyping/claude_judge.py run \
  --output /private/tmp/new-blinded-judge --jobs 3
uv run --no-project python Benchmarks/Cotyping/claude_judge.py analyze \
  --output /private/tmp/new-blinded-judge
```

The `run` command sends the prepared synthetic packets to the installed Claude
CLI and requires authorization to use that remote judge. It runs without tools,
MCP servers, skills, or session persistence. It does not send repository source
or personal writing. Numeric ratings, explanations, and any contradictory
preference labels are retained; the analysis reports a sensitivity check that
excludes inconsistent cases without silently changing or rejudging their scores.

## Native selective one-word hybrid

`selectiveOneWordHybrid: true` enables the local replay experiment. It evaluates
the current selected-token confidence gate (0.1) and a boundary-mass fallback
(0.31) on **one sampled token stream**. A passing current suggestion is retained
exactly. Only when the current gate fails can the fallback admit a suggestion,
and that suggestion is capped to its first word after full normalization. This
preserves question, unsafe-insertion, and context-leak suppression. Midword
completion keeps the current ungated behavior.

Hybrid streaming publishes only the final normalized decision, so an uncapped
fallback cannot flash on screen. The experiment rejects beam search, logit
caching, display stopping, and changed primary confidence settings. The normal
app still constructs the current decoder by default.

`hybrid_benchmark.py` runs the native hybrid against the current decoder with
the same Release executable, Gemma weights, prompt, sampler, and token budget.
`hybrid-confirmation-cases.json` provides 64 new synthetic English/Serbian
phrases written before inference; preparation rejects duplicates from all prior
corpora. Previous development and confirmation cases are regression checks.
Static timing uses four alternating rounds; dynamic typing/cancellation uses
two. A separate mass-reference run verifies the native result equals the frozen
offline composition. It is excluded from the current-versus-hybrid timing pair.

```sh
uv run --no-project python Benchmarks/Cotyping/hybrid_benchmark.py prepare \
  --prior /path/to/extracted-decoder-loop/evaluation \
  --output /private/tmp/native-hybrid
uv run --no-project python Benchmarks/Cotyping/hybrid_benchmark.py run \
  --prior /path/to/extracted-decoder-loop/evaluation \
  --output /private/tmp/native-hybrid --app /path/to/Release/LokalBot \
  --model /path/to/gemma-4-E2B.i1-Q6_K.gguf
uv run --no-project python Benchmarks/Cotyping/hybrid_benchmark.py prepare-judge \
  --source /private/tmp/native-hybrid --output /private/tmp/native-hybrid-judge \
  --split fresh
uv run --no-project python Benchmarks/Cotyping/claude_judge.py run \
  --output /private/tmp/native-hybrid-judge --jobs 3
uv run --no-project python Benchmarks/Cotyping/claude_judge.py analyze \
  --output /private/tmp/native-hybrid-judge
```

Repeat `prepare-judge` with `--split regression` and a new output directory for
the old corpus. Every changed native output is judged, plus shared-output checks
and blind repeats. The fixed rubric excludes future reference text, decoder
identities, and timings. Report fresh quality separately from regression ratings;
an LLM usefulness score is not a human acceptance rate. Timing is a complete warm
headless engine call, not first-visible or end-to-end typing latency.
