"""Recheck exact matching, native recovery, tokenizer and blind-judge evidence."""
import argparse
from pathlib import Path
import it_q6_experiment as experiment

study = experiment.study
ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--without-judge', action='store_true')
    args = parser.parse_args()
    summary = study.read(ROOT / 'summary.json')
    meta = study.read(ROOT / 'case-meta.json')
    config = study.read(ROOT / 'matched.json')
    controls = study.read(ROOT / 'pre-inference-controls.json')
    assert study.sha(ROOT / 'METHOD.md') == controls['methodSHA256']
    assert study.sha(ROOT / 'models.json') == controls['modelManifestSHA256']
    assert study.sha(ROOT / 'input-tokenization.json') == controls['tokenizationSHA256']
    for name, digest in controls['scripts'].items():
        assert study.sha(ROOT / name) == digest
    tokens = study.read(ROOT / 'input-tokenization.json')
    assert tokens['exactNativeTokenParity'] and tokens['uniquePrompts'] == 402
    assert all(r['sequences'] == tokens['models']['q6']['sequences'] for r in tokens['models'].values())
    alignment = study.read(ROOT / 'bos-alignment.json')
    assert len(alignment) == 3
    assert all(item['everyOtherByteIdentical'] and item['newValue'] is False for item in alignment)
    assert all(item['changedBytes'] == (0 if item['arm'] == 'q6' else 1) for item in alignment)
    trace_checks = matched_checks = midword_checks = recovery_checks = 0
    for arm in experiment.IDS:
        trace = study.observed(ROOT, 'trace', 'fresh', arm)
        production = study.observed(ROOT, 'production', 'fresh', arm)
        for identifier, row in trace.items():
            assert study.candidate(row, .1, .31) == production[identifier]['text']
            trace_checks += 1
        for number in [1, 2]:
            matched = study.observed(ROOT, 'matched', 'fresh', arm, number)
            for identifier, row in matched.items():
                language = meta[identifier]['language']
                assert row['text'] == study.candidate(trace[identifier], **config['cutoffs'][arm][language])
                matched_checks += 1
                if meta[identifier]['kind'] == 'midword':
                    assert row['text'] == production[identifier]['text']
                    midword_checks += 1
            for language, frequency in config['frequencies'].items():
                assert sum(bool(row['text']) for i, row in matched.items() if meta[i]['language'] == language) == frequency['matched']
            cancelled = study.observed(ROOT, 'production', 'cancellation', arm, number)
            for identifier, row in cancelled.items():
                if identifier.endswith('-replacement'):
                    cold = cancelled[identifier.removesuffix('-replacement') + '-cold']
                    assert all(row.get(k) == cold.get(k) for k in ['prompt', 'text', 'suppression', 'error', 'cancelled'])
                    recovery_checks += 1
    if not args.without_judge:
        quality = summary['quality']
        assert quality['models'] == ['claude-opus-5-5'] and quality['repeat']['cases'] == 24
        for arm in experiment.IDS:
            for language, frequency in config['frequencies'].items():
                q = quality['policies']['matched'][arm][language]
                assert q['shown'] == frequency['matched'] and q['n'] == frequency['total']
    else:
        assert 'quality' not in summary
        assert not list((ROOT / 'judge/batches').glob('*/ratings.json'))
        assert not list((ROOT / 'judge/batches').glob('*/receipt.json'))
        failures = list((ROOT / 'judge/cli-limit-failures').glob('*/response.json'))
        assert len(failures) == 25
        assert all(study.read(path)['api_error'] == 'usage_limit_reached' for path in failures)
        api_error = study.read(ROOT / 'judge/batches/primary-01/api-error.json')['error']
        assert api_error['code'] == 404
        assert any(r['reason'] == 'model-ignored-by-guardrail' for r in api_error['metadata']['ineligibility_reasons'])
    protocol = study.read(ROOT / 'judge/protocol.json')
    result = dict(summary['validation'], traceProductionChecks=trace_checks,
        nativeMatchedTraceChecks=matched_checks, preservedMidwordChecks=midword_checks,
        replacementColdChecks=recovery_checks, inputTokenParityPrompts=tokens['uniquePrompts'],
        judgeBatches=len(protocol['batches']), judgePrimaryCases=protocol['primaryCases'],
        judgeRepeatCases=protocol['repeatCases'], allSilentCases=288-protocol['primaryCases'],
        exactFrequencyVerified=True, judgeCompleted=not args.without_judge,
        judgeCoverageVerified=not args.without_judge)
    study.write(ROOT / 'validation.json', result)
    print(result)


if __name__ == '__main__':
    main()
