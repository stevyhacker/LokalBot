"""Recheck exact matching, native recovery, tokenizer and blind-judge evidence."""
import argparse
from pathlib import Path
import json
import it_q6_experiment as experiment
import claude_judge as judge

study = experiment.study
ROOT = Path(__file__).resolve().parent


def validate_direct_judge():
    protocol = study.read(ROOT / 'judge/protocol.json')
    amendment = study.read(ROOT / 'judge-direct-api-amendment.json')
    assert amendment['adapterSHA256'] == study.sha(ROOT / 'run_anthropic_judge.py')
    assert amendment['protocolSHA256'] == study.sha(ROOT / 'judge/protocol.json')
    assert amendment['rubricSHA256'] == judge.digest(judge.RUBRIC)
    assert amendment['systemSHA256'] == judge.digest(judge.SYSTEM)
    assert amendment['schema'] == judge.SCHEMA
    totals = dict(batches=0, cases=0, options=0, inputTokens=0, outputTokens=0, thinkingTokens=0)
    for batch in protocol['batches']:
        folder = ROOT / 'judge/batches' / batch['id']
        request = (folder / 'request.txt').read_text()
        packet = study.read(folder / 'packet.json')
        assert set(packet) == {'cases'}
        assert all(set(c) == {'id','prefix','options'} for c in packet['cases'])
        assert all(set(o) == {'id','continuation'} for c in packet['cases'] for o in c['options'])
        assert request == judge.RUBRIC + json.dumps(packet['cases'], ensure_ascii=False, separators=(',', ':'))
        assert judge.digest(request) == batch['requestSHA256']
        payload = study.read(folder / 'anthropic-request.json')
        assert payload == dict(model='claude-opus-5-5', max_tokens=16000, system=judge.SYSTEM,
            messages=[dict(role='user',content=request)], thinking=dict(type='adaptive',display='omitted'),
            output_config=dict(effort='high'))
        receipt = study.read(folder / 'receipt.json')
        raw = study.read(folder / 'anthropic-response.json')
        assert raw['model'] == 'claude-opus-5-5' and raw['stop_reason'] == 'end_turn'
        assert raw['type'] == 'message' and raw['role'] == 'assistant'
        assert all(b['type'] in ['text','thinking','redacted_thinking'] and not b.get('thinking') for b in raw['content'])
        result = json.loads(''.join(b['text'] for b in raw['content'] if b['type'] == 'text'))
        judge.validate_judgments(packet, result, strict_preference=False)
        assert set(result) == {'cases'}
        assert all(set(c) == {'id','ratings','preferred'} for c in result['cases'])
        assert all(set(r) == {'id','utility','first_word','flags','reason'} for c in result['cases'] for r in c['ratings'])
        assert result == study.read(folder / 'ratings.json')
        normalized = study.read(folder / 'response.json')
        assert normalized['structured_output'] == result
        assert normalized['originalModel'] == raw['model']
        assert normalized['originalResponseSHA256'] == study.sha(folder / 'anthropic-response.json')
        assert receipt['apiRequestSHA256'] == study.sha(folder / 'anthropic-request.json')
        assert receipt['apiResponseSHA256'] == study.sha(folder / 'anthropic-response.json')
        assert receipt['responseSHA256'] == study.sha(folder / 'response.json')
        assert receipt['requestSHA256'] == batch['requestSHA256']
        assert receipt['responseID'] == raw['id'] and receipt['requestID']
        assert receipt['models'] == ['claude-opus-5-5'] and receipt['transport'] == 'Anthropic Messages API'
        assert not any(receipt[k] for k in ['isError','toolsEnabled','suppliedPersonalWriting',
            'suppliedSourceCode','suppliedFutureReference','suppliedImplementationLabels'])
        totals['batches'] += 1
        totals['cases'] += len(result['cases'])
        totals['options'] += sum(len(c['ratings']) for c in result['cases'])
        totals['inputTokens'] += raw['usage']['input_tokens']
        totals['outputTokens'] += raw['usage']['output_tokens']
        totals['thinkingTokens'] += raw['usage'].get('output_tokens_details',{}).get('thinking_tokens',0)
    assert totals['batches'] == 25 and totals['cases'] == 296
    failed = study.read(ROOT / 'judge/anthropic-format-failures/primary-01/failure.json')
    assert failed['returnedRatings'] == 0
    totals['failedFormatPreflights'] = 1
    totals['failedPreflightInputTokens'] = failed['usage']['input_tokens']
    totals['failedPreflightOutputTokens'] = failed['usage']['output_tokens']
    assert len(list((ROOT / 'judge/cli-limit-failures').glob('*/response.json'))) == 25
    assert study.read(ROOT / 'judge/batches/primary-01/api-error.json')['error']['code'] == 404
    return totals


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--without-judge', action='store_true')
    args = parser.parse_args()
    summary = study.read(ROOT / 'summary.json')
    meta = study.read(ROOT / 'case-meta.json')
    config = study.read(ROOT / 'matched.json')
    controls = study.read(ROOT / 'pre-inference-controls.json')
    assert study.sha(ROOT / 'METHOD.md') == controls['methodSHA256']
    assert study.sha(ROOT / 'models.json') == controls['modelManifestSHA256']
    assert study.sha(ROOT / 'input-tokenization.json') == controls['tokenizationSHA256']
    for name, digest in controls['scripts'].items():
        assert study.sha(ROOT / name) == digest
    tokens = study.read(ROOT / 'input-tokenization.json')
    assert tokens['exactNativeTokenParity'] and tokens['uniquePrompts'] == 402
    assert all(r['sequences'] == tokens['models']['q6']['sequences'] for r in tokens['models'].values())
    alignment = study.read(ROOT / 'bos-alignment.json')
    assert len(alignment) == 3
    assert all(item['everyOtherByteIdentical'] and item['newValue'] is False for item in alignment)
    assert all(item['changedBytes'] == (0 if item['arm'] == 'q6' else 1) for item in alignment)
    trace_checks = matched_checks = midword_checks = recovery_checks = 0
    for arm in experiment.IDS:
        trace = study.observed(ROOT, 'trace', 'fresh', arm)
        production = study.observed(ROOT, 'production', 'fresh', arm)
        for identifier, row in trace.items():
            assert study.candidate(row, .1, .31) == production[identifier]['text']
            trace_checks += 1
        for number in [1, 2]:
            matched = study.observed(ROOT, 'matched', 'fresh', arm, number)
            for identifier, row in matched.items():
                language = meta[identifier]['language']
                assert row['text'] == study.candidate(trace[identifier], **config['cutoffs'][arm][language])
                matched_checks += 1
                if meta[identifier]['kind'] == 'midword':
                    assert row['text'] == production[identifier]['text']
                    midword_checks += 1
            for language, frequency in config['frequencies'].items():
                assert sum(bool(row['text']) for i, row in matched.items() if meta[i]['language'] == language) == frequency['matched']
            cancelled = study.observed(ROOT, 'production', 'cancellation', arm, number)
            for identifier, row in cancelled.items():
                if identifier.endswith('-replacement'):
                    cold = cancelled[identifier.removesuffix('-replacement') + '-cold']
                    assert all(row.get(k) == cold.get(k) for k in ['prompt', 'text', 'suppression', 'error', 'cancelled'])
                    recovery_checks += 1
    if not args.without_judge:
        judge_validation = validate_direct_judge()
        before = study.read(ROOT / 'before-direct-judge-summary.json')
        assert all(summary[key] == value for key, value in before.items())
        installation = study.read(ROOT / 'judge-followup-installation-receipt.json')
        assert installation['before'] == installation['after'] == study.read(ROOT / 'unchanged-app-receipt.json')['after']
        assert installation['unchanged'] and not installation['appBuiltOrInstalledByFollowup'] and not installation['defaultChangedByFollowup']
        quality = summary['quality']
        assert quality['models'] == ['claude-opus-5-5'] and quality['repeat']['cases'] == 24
        for arm in experiment.IDS:
            for language, frequency in config['frequencies'].items():
                q = quality['policies']['matched'][arm][language]
                assert q['shown'] == frequency['matched'] and q['n'] == frequency['total']
    else:
        assert 'quality' not in summary
        assert not list((ROOT / 'judge/batches').glob('*/ratings.json'))
        assert not list((ROOT / 'judge/batches').glob('*/receipt.json'))
        failures = list((ROOT / 'judge/cli-limit-failures').glob('*/response.json'))
        assert len(failures) == 25
        assert all(study.read(path)['api_error'] == 'usage_limit_reached' for path in failures)
        api_error = study.read(ROOT / 'judge/batches/primary-01/api-error.json')['error']
        assert api_error['code'] == 404
        assert any(r['reason'] == 'model-ignored-by-guardrail' for r in api_error['metadata']['ineligibility_reasons'])
    protocol = study.read(ROOT / 'judge/protocol.json')
    result = dict(summary['validation'], traceProductionChecks=trace_checks,
        nativeMatchedTraceChecks=matched_checks, preservedMidwordChecks=midword_checks,
        replacementColdChecks=recovery_checks, inputTokenParityPrompts=tokens['uniquePrompts'],
        judgeBatches=len(protocol['batches']), judgePrimaryCases=protocol['primaryCases'],
        judgeRepeatCases=protocol['repeatCases'], allSilentCases=288-protocol['primaryCases'],
        exactFrequencyVerified=True, judgeCompleted=not args.without_judge,
        judgeCoverageVerified=not args.without_judge)
    if not args.without_judge:
        result['directAPIJudgeVerification'] = judge_validation
        result['previouslyPublishedNativeResultsUnchanged'] = True
        result['followupInstalledHashesUnchanged'] = True
    study.write(ROOT / 'validation.json', result)
    print(result)


if __name__ == '__main__':
    main()
