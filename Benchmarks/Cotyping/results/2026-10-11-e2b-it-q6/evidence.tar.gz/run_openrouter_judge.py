"""Judge the frozen synthetic packets with Opus 5.5 via OpenRouter/Anthropic.

This transport fallback preserves CLI quota failures and the original rubric.
No credentials are written to requests, logs or evidence files.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import json
from pathlib import Path
import time
import urllib.error
import urllib.request

import claude_judge as judge

ROOT = Path(__file__).resolve().parent
FOLDER = ROOT / 'judge'
MODEL = 'anthropic/claude-opus-5.5'


def preserve_cli_failures(protocol):
    amendment = ROOT / 'judge-transport-amendment.json'
    if amendment.exists():
        return
    failures = []
    for batch in protocol['batches']:
        source = FOLDER / 'batches' / batch['id']
        response = json.loads((source / 'response.json').read_text())
        assert response['is_error'] and response['api_error'] == 'usage_limit_reached'
        assert response['modelUsage'] == {} and not (source / 'ratings.json').exists()
        target = FOLDER / 'cli-limit-failures' / batch['id']
        target.mkdir(parents=True, exist_ok=False)
        for name in ['response.json', 'stderr.log', 'execution.json']:
            (source / name).rename(target / name)
        failures.append(batch['id'])
    judge.write_json(amendment, dict(atUTC=datetime.now(timezone.utc).isoformat(),
        reason='Claude Code subscription returned HTTP 429 usage_limit_reached before any judgments. Use the already configured OpenRouter account with the same named Claude Opus 5.5 model, restricted to Anthropic.',
        cliFailedBatches=failures, cliRatingsReceived=0, requestedModel=MODEL,
        modelReceiptNormalization='anthropic/claude-opus-5.5 -> claude-opus-5-5; raw API model/provider and response retained and verified.',
        rubricSHA256=judge.digest(judge.RUBRIC), systemSHA256=judge.digest(judge.SYSTEM),
        unchanged='All packet/request hashes, rubric, system message, schema, option orders, high reasoning effort and no-tool restriction. No ratings pooled from earlier studies.',
        maxOutputTokens=16000, maximumBatches=25,
        maximumTokenCostUSD=9.0, note='At catalog pricing $4/$20 per million tokens, output ceiling is $8 for all 25 batches; total input is bounded below $1. No automatic retries.'))


def run_batch(batch, key):
    folder = FOLDER / 'batches' / batch['id']
    if (folder / 'receipt.json').exists():
        return dict(batch=batch['id'], reused=True)
    request = (folder / 'request.txt').read_text()
    assert judge.digest(request) == batch['requestSHA256']
    packet = json.loads((folder / 'packet.json').read_text())
    assert set(packet) == {'cases'}
    assert all(set(case) == {'id', 'prefix', 'options'} for case in packet['cases'])
    assert all(set(option) == {'id', 'continuation'} for case in packet['cases'] for option in case['options'])
    assert len(request.encode()) < 40000
    payload = dict(model=MODEL, messages=[dict(role='system', content=judge.SYSTEM), dict(role='user', content=request)],
        max_tokens=16000, reasoning=dict(effort='high', exclude=True),
        provider=dict(only=['anthropic'], allow_fallbacks=False, require_parameters=True),
        response_format=dict(type='json_schema', json_schema=dict(name='autocomplete_judgments', strict=True, schema=judge.SCHEMA)))
    target = folder / 'api-response.json'
    assert not target.exists() and not (folder / 'api-error.json').exists(), 'Refuse to overwrite an API response, including an error.'
    judge.write_json(folder / 'api-request.json', payload)
    started = time.monotonic()
    try:
        api_request = urllib.request.Request('https://openrouter.ai/api/v1/chat/completions',
            data=json.dumps(payload).encode(), headers={'Authorization':'Bearer '+key, 'Content-Type':'application/json'}, method='POST')
        with urllib.request.urlopen(api_request, timeout=600) as response:
            target.write_bytes(response.read())
    except urllib.error.HTTPError as error:
        (folder / 'api-error.json').write_bytes(error.read())
        raise RuntimeError(f'HTTP {error.code} for {batch["id"]}; response retained') from None
    elapsed = time.monotonic() - started
    response = json.loads(target.read_text())
    assert response['model'] == MODEL and response['provider'] == 'Anthropic'
    assert not response.get('error')
    choice = response['choices'][0]
    assert choice['finish_reason'] == 'stop' and not choice['message'].get('tool_calls')
    result = judge.validate_judgments(packet, json.loads(choice['message']['content']), strict_preference=False)
    # Documented adapter allows the unchanged frozen statistics reader to consume
    # this API response. The validator separately re-parses the original response.
    normalized = dict(is_error=False, structured_output=result, transport='OpenRouter',
                      originalModel=response['model'], originalProvider=response['provider'],
                      originalResponseSHA256=judge.digest(target.read_bytes()))
    judge.write_json(folder / 'response.json', normalized)
    judge.write_json(folder / 'ratings.json', result)
    judge.write_json(folder / 'preference-disagreements.json', judge.preference_disagreements(result))
    judge.write_json(folder / 'execution.json', dict(exitCode=0, wallSeconds=elapsed, requestedModel=MODEL,
                    transport='OpenRouter', usage=response.get('usage')))
    judge.write_json(folder / 'receipt.json', dict(models=['claude-opus-5-5'], apiModel=response['model'],
        provider=response['provider'], transport='OpenRouter', isError=False, durationMs=elapsed*1000,
        requestSHA256=judge.digest(request), responseSHA256=judge.digest((folder/'response.json').read_bytes()),
        apiRequestSHA256=judge.digest((folder/'api-request.json').read_bytes()),
        apiResponseSHA256=judge.digest(target.read_bytes()), toolsEnabled=False,
        suppliedPersonalWriting=False, suppliedSourceCode=False, suppliedFutureReference=False,
        suppliedImplementationLabels=False))
    return dict(batch=batch['id'], cases=len(result['cases']), model=response['model'],
                provider=response['provider'], costUSD=response.get('usage',{}).get('cost'))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--key-file', type=Path, required=True)
    parser.add_argument('--batch')
    args = parser.parse_args()
    protocol = json.loads((FOLDER / 'protocol.json').read_text())
    assert len(protocol['batches']) == 25
    input_bytes = sum(len((judge.SYSTEM + (FOLDER / 'batches' / b['id'] / 'request.txt').read_text()
                         + json.dumps(judge.SCHEMA)).encode()) for b in protocol['batches'])
    assert input_bytes < 240000, 'Keep input token cost below the documented ceiling.'
    if not args.batch:
        assert (FOLDER / 'batches/primary-01/receipt.json').exists(), 'Require one successful preflight before batching.'
    preserve_cli_failures(protocol)
    key = args.key_file.read_text().strip()
    assert key and '\n' not in key
    selected = [b for b in protocol['batches'] if not args.batch or b['id'] == args.batch]
    assert selected
    failures = []
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = {pool.submit(run_batch, batch, key): batch for batch in selected}
        for future in as_completed(futures):
            try:
                print(json.dumps(future.result()), flush=True)
            except Exception as error:
                failures.append(dict(batch=futures[future]['id'], error=str(error)))
                print(json.dumps(failures[-1]), flush=True)
    if failures:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
