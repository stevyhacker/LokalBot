"""Verify and recompute a published evidence archive without native inference."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--publication', type=Path, required=True)
    parser.add_argument('--extract', type=Path, required=True)
    args = parser.parse_args()
    manifest = json.loads((args.publication / 'evidence-manifest.json').read_text())
    archive = args.publication / manifest['archive']
    assert sha(archive) == manifest['sha256']
    args.extract.mkdir(exist_ok=False)
    with tarfile.open(archive) as bundle:
        assert all(member.isfile() for member in bundle.getmembers())
        assert set(bundle.getnames()) == {member['path'] for member in manifest['members']}
        bundle.extractall(args.extract, filter='data')
    for member in manifest['members']:
        path = args.extract / member['path']
        assert path.stat().st_size == member['bytes'] and sha(path) == member['sha256']
    has_quality = 'quality' in json.loads((args.extract / 'summary.json').read_text())
    names = ['summary.json', 'validation.json', 'TABLES.md']
    if has_quality:
        names += ['quality-examples.json', 'EXAMPLES.md', 'judged-example-selection.json']
    before = {name: sha(args.extract / name) for name in names}
    with (args.publication / 'archive-reproduction.log').open('w') as log:
        commands = [
            ['it_q6_analysis.py', '--root', str(args.extract)] + ([] if has_quality else ['--without-judge']),
            ['validate_evidence.py'] + ([] if has_quality else ['--without-judge']),
            ['make_tables.py' if has_quality else 'make_pending_tables.py'],
        ]
        if has_quality:
            commands.append(['make_examples.py'])
        for command in commands:
            subprocess.run([sys.executable, *command], cwd=args.extract,
                           stdout=log, stderr=subprocess.STDOUT, check=True)
    after = {name: sha(args.extract / name) for name in names}
    assert before == after
    result = dict(archiveSHA256=manifest['sha256'], verifiedMembers=len(manifest['members']),
                  byteIdenticalRecomputed=after, modelInference=False, contactedJudge=False)
    (args.publication / 'archive-reproduction.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
