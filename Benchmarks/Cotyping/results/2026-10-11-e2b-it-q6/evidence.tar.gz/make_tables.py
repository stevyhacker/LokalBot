"""Render all three IT/base arms from the validated numerical summary."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
NAMES = {'q6': 'Current E2B base i1 Q6', 'unsloth': 'Unsloth E2B IT Q6_K', 'bartowski': 'Bartowski E2B IT Q6_K'}


def ci(pair):
    return f"{pair['delta']:+.3f} [{pair['delta95CI'][0]:+.3f}, {pair['delta95CI'][1]:+.3f}]"


def main():
    data = json.loads((ROOT / 'summary.json').read_text())
    quality, timing = data['quality']['policies']['matched'], data['timing']
    lines = ['**Warm timing and matched-frequency quality**', '',
             '| Variant | Warm mean / p95, ms | Matched mean / p95, ms | EN utility | SR Latin utility | Helpful / poor | Utility delta vs current [95% interval] |',
             '|---|---:|---:|---:|---:|---:|---:|']
    for arm, name in NAMES.items():
        t = timing['normal']['steady']['fresh'][arm]['all']['paired']['candidate']
        m = timing['normal']['matched']['fresh'][arm]['all']['paired']['candidate']
        q = quality[arm]
        lines.append(f"| {name} | {t['mean']:.1f} / {t['p95']:.1f} | {m['mean']:.1f} / {m['p95']:.1f} | {q['en']['meanUtility']:.3f} | {q['sr_latn']['meanUtility']:.3f} | {q['all']['helpful']} / {q['all']['poor']} | {ci(q['all']['delta'])} |")
    lines += ['', '**Language-specific quality**', '',
              '| Variant | EN helpful / poor | EN delta [95% interval] | SR Latin helpful / poor | SR Latin delta [95% interval] |',
              '|---|---:|---:|---:|---:|']
    for arm, name in NAMES.items():
        a, b = quality[arm]['en'], quality[arm]['sr_latn']
        lines.append(f"| {name} | {a['helpful']} / {a['poor']} | {ci(a['delta'])} | {b['helpful']} / {b['poor']} | {ci(b['delta'])} |")
    lines += ['', '**Long fields, typing and cancellation**', '',
              '| Variant | Long mean / p95, ms | Typing mean / p95, ms | Cancellation through replacement, paired mean current → candidate, ms | Peak RSS GB |',
              '|---|---:|---:|---:|---:|']
    for arm, name in NAMES.items():
        a = timing['normal']['production']['long'][arm]['all']['paired']['candidate']
        b = timing['normal']['production']['dynamic'][arm]['all']['paired']['candidate']
        c = timing['cancellation'][arm]['throughReplacement']
        rss = timing['resources'][arm]['maximumResidentBytes']['median'] / 1e9
        lines.append(f"| {name} | {a['mean']:.1f} / {a['p95']:.1f} | {b['mean']:.1f} / {b['p95']:.1f} | {c['default']['mean']:.1f} → {c['candidate']['mean']:.1f} | {rss:.2f} |")
    lines += ['', '**Native confidence gates fitted without quality labels**', '',
              '| Variant | EN primary / fallback | SR Latin primary / fallback |', '|---|---:|---:|']
    for arm, name in NAMES.items():
        c = data['matching']['cutoffs'][arm]
        a, b = c['en'], c['sr_latn']
        lines.append(f"| {name} | {a['primary']:.5f} / {a['fallback']:.5f} | {b['primary']:.5f} / {b['fallback']:.5f} |")
    (ROOT / 'TABLES.md').write_text('\n'.join(lines) + '\n')


if __name__ == '__main__':
    main()
