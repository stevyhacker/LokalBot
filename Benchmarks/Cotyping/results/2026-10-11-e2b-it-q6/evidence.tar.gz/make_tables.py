"""Render all three IT/base arms from the validated numerical summary."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
NAMES = {'q6': 'Current E2B base i1 Q6', 'unsloth': 'Unsloth E2B IT Q6_K', 'bartowski': 'Bartowski E2B IT Q6_K'}


def ci(pair):
    return f"{pair['delta']:+.3f} [{pair['delta95CI'][0]:+.3f}, {pair['delta95CI'][1]:+.3f}]"


def main():
    data = json.loads((ROOT / 'summary.json').read_text())
    quality, timing = data['quality']['policies']['matched'], data['timing']
    lines = ['**Warm timing and matched-frequency quality**', '',
             'All matched arms show 112/144 English and 109/144 Serbian Latin suggestions. Utility is Claude Opus 5.5 opinion on a −2..2 scale with silence at zero, averaged across every checkpoint. Helpful is utility >0; poor is utility <0. Timing is native completion, excluding model load, debounce, accessibility and rendering. Intervals use 5,000 paired bootstrap draws over 48 bilingual scenarios.', '',
             '| Variant | Warm mean / p95, ms | Matched mean / p95, ms | EN utility | SR Latin utility | Helpful / poor | Utility delta vs current [95% interval] |',
             '|---|---:|---:|---:|---:|---:|---:|']
    for arm, name in NAMES.items():
        t = timing['normal']['steady']['fresh'][arm]['all']['paired']['candidate']
        m = timing['normal']['matched']['fresh'][arm]['all']['paired']['candidate']
        q = quality[arm]
        lines.append(f"| {name} | {t['mean']:.1f} / {t['p95']:.1f} | {m['mean']:.1f} / {m['p95']:.1f} | {q['en']['meanUtility']:.3f} | {q['sr_latn']['meanUtility']:.3f} | {q['all']['helpful']} / {q['all']['poor']} | {ci(q['all']['delta'])} |")
    lines += ['', '**Language-specific quality**', '',
              '| Variant | EN helpful / poor | EN delta [95% interval] | SR Latin helpful / poor | SR Latin delta [95% interval] |',
              '|---|---:|---:|---:|---:|']
    for arm, name in NAMES.items():
        a, b = quality[arm]['en'], quality[arm]['sr_latn']
        lines.append(f"| {name} | {a['helpful']} / {a['poor']} | {ci(a['delta'])} | {b['helpful']} / {b['poor']} | {ci(b['delta'])} |")
    lines += ['', '**Matched timing detail**', '',
              '| Variant | Mean delta [95% interval], ms | Shown-only mean / p95, ms | EN mean / p95, ms | SR Latin mean / p95, ms |',
              '|---|---:|---:|---:|---:|']
    for arm, name in NAMES.items():
        t = timing['normal']['matched']['fresh'][arm]
        shown = t['all']['shownOnly']['candidate']
        en, sr = t['en']['paired']['candidate'], t['sr_latn']['paired']['candidate']
        lines.append(f"| {name} | {ci(t['all']['paired'])} | {shown['mean']:.1f} / {shown['p95']:.1f} | {en['mean']:.1f} / {en['p95']:.1f} | {sr['mean']:.1f} / {sr['p95']:.1f} |")
    lines += ['', '**Long fields, typing and cancellation**', '',
              '| Variant | Long mean / p95, ms | Typing mean / p95, ms | Cancellation return, paired mean current → candidate, ms | Cancellation through replacement, paired mean current → candidate, ms | Median peak RSS GB |',
              '|---|---:|---:|---:|---:|---:|']
    for arm, name in NAMES.items():
        a = timing['normal']['production']['long'][arm]['all']['paired']['candidate']
        b = timing['normal']['production']['dynamic'][arm]['all']['paired']['candidate']
        c = timing['cancellation'][arm]['throughReplacement']
        ret = timing['cancellation'][arm]['returned']
        rss = timing['resources'][arm]['maximumResidentBytes']['median'] / 1e9
        lines.append(f"| {name} | {a['mean']:.1f} / {a['p95']:.1f} | {b['mean']:.1f} / {b['p95']:.1f} | {ret['default']['mean']:.1f} → {ret['candidate']['mean']:.1f} | {c['default']['mean']:.1f} → {c['candidate']['mean']:.1f} | {rss:.2f} |")
    lines += ['', 'Long, typing and cancellation measurements use production gates. Cancellation comparisons include only mutually cancelled pairs; baselines differ by candidate and use only four source scenarios.', '',
              '**Quality at unchanged production gates (unequal suggestion frequency)**', '',
              '| Variant | Shown /288 | Helpful / poor | Mean utility |', '|---|---:|---:|---:|']
    for arm, name in NAMES.items():
        q = data['quality']['policies']['production'][arm]['all']
        lines.append(f"| {name} | {q['shown']} | {q['helpful']} / {q['poor']} | {q['meanUtility']:.3f} |")
    lines += ['', '**Native confidence gates fitted without quality labels**', '',
              '| Variant | EN primary / fallback | SR Latin primary / fallback |', '|---|---:|---:|']
    for arm, name in NAMES.items():
        c = data['matching']['cutoffs'][arm]
        a, b = c['en'], c['sr_latn']
        lines.append(f"| {name} | {a['primary']:.5f} / {a['fallback']:.5f} | {b['primary']:.5f} / {b['fallback']:.5f} |")
    lines += ['', 'The frozen implementation uses fallback = min(1, 3.1 × primary), so both IT fallback thresholds saturate at 1. These cutoffs are evaluation-only; current-Q6 text and all midword outputs remain unchanged.', '',
              '**Bartowski minus Unsloth at matched frequency**', '', '| Language | Utility difference [95% interval] |', '|---|---:|']
    for language, pair in data['publisherITQualityPairs']['bartowski-vs-unsloth'].items():
        lines.append(f"| {language} | {ci(pair)} |")
    (ROOT / 'TABLES.md').write_text('\n'.join(lines) + '\n')


if __name__ == '__main__':
    main()
