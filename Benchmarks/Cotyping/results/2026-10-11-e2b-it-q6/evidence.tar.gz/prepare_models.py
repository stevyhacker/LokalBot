"""Inspect downloaded IT artifacts and control input BOS without changing weights."""
from pathlib import Path
import json
import inspect_gguf as gg
import normalize_and_inspect as norm

ROOT = Path(__file__).resolve().parent
INPUT_KEYS = {
    'tokenizer.ggml.model', 'tokenizer.ggml.pre', 'tokenizer.ggml.tokens',
    'tokenizer.ggml.scores', 'tokenizer.ggml.merges',
    'tokenizer.ggml.bos_token_id', 'tokenizer.ggml.add_bos_token',
    'tokenizer.ggml.add_eos_token', 'tokenizer.ggml.add_space_prefix',
}


def write(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')


def checked_existing(original):
    """Resume already verified clones after a pre-inference metadata assertion."""
    source = Path(original['path'])
    model = json.loads((ROOT / ('model-' + original['id'] + '.json')).read_text())
    target = Path(model['path'])
    offset, old = norm.find_bos(source)
    if old and target == source:
        return norm.normalize(original)
    assert norm.sha(source) == original['sha256']
    assert norm.sha(target) == model['sha256']
    assert source.stat().st_size == target.stat().st_size == original['bytes']
    assert norm.find_bos(target) == (offset, False)
    differences = []
    with source.open('rb') as a, target.open('rb') as b:
        position = 0
        while chunk := a.read(8 * 1024 * 1024):
            other = b.read(len(chunk))
            if chunk != other:
                differences.extend(position + i for i, (x, y) in enumerate(zip(chunk, other)) if x != y)
            position += len(chunk)
        assert not b.read(1)
    assert differences == ([offset] if old else [])
    return model, dict(arm=original['id'], source=str(source), sourceSHA256=original['sha256'],
        evaluation=str(target), evaluationSHA256=model['sha256'], offset=offset,
        oldValue=old, newValue=False, changedBytes=len(differences), everyOtherByteIdentical=True)


def main():
    models = [json.loads((ROOT / 'model-q6.json').read_text())]
    models += json.loads((ROOT / 'downloaded.json').read_text())
    assert [m['id'] for m in models] == ['q6', 'unsloth', 'bartowski']
    assert not (ROOT / 'models.json').exists()
    write('models-publisher.json', models)
    evaluated, receipts, parsed = [], [], {}
    for model in models:
        result, receipt = checked_existing(model)
        evaluated.append(result)
        receipts.append(receipt)
        parsed[model['id']] = gg.parse(Path(result['path']))
        write('model-' + model['id'] + '.json', result)
    baseline = parsed['q6']
    differences = {}
    for arm, data in parsed.items():
        a, b = baseline['tokenizerFields'], data['tokenizerFields']
        differences[arm] = {k: dict(current=a.get(k), candidate=b.get(k))
                            for k in a.keys() | b.keys() if a.get(k) != b.get(k)}
        input_differences = set(differences[arm]) & INPUT_KEYS
        assert not input_differences, (arm, input_differences)
        # Unsloth changes only <eos>'s token type. Retain this stopping-related
        # difference; ordinary input tokens are verified separately below.
        detailed = json.loads((ROOT / 'tokenizer-differences.json').read_text())[arm]
        changes = detailed.get('tokenizer.ggml.token_type', {}).get('changed', [])
        assert changes == ([dict(id=1, token='<eos>', current=3, candidate=1)] if arm == 'unsloth' else [])
        assert data['metadata']['general.architecture'] == 'gemma4'
        assert data['tensorShapesSHA256'] == baseline['tensorShapesSHA256']
    write('models.json', evaluated)
    write('bos-alignment.json', receipts)
    write('gguf-inspection.json', dict(models=parsed, tokenizerDifferences=differences,
        matchedInputKeys=sorted(INPUT_KEYS), inputTokenizerMetadataMatches=True,
        note='Automatic BOS is aligned to current Q6. Publisher chat templates are ignored by the fixed raw-prefix prompt renderer; EOS/stopping metadata is preserved. IT weights and tensor precision may differ.'))
    print(json.dumps(dict(types={arm:data['storedTypes'] for arm,data in parsed.items()},
                         tokenizerDifferences=differences), indent=2))


if __name__ == '__main__':
    main()
