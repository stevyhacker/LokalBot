"""Complete frozen synthetic judge packets through the Anthropic Messages API.

Only ANTHROPIC_API_KEY is read from the explicitly authorized environment file.
Credentials never enter request artifacts, logs, or subprocess arguments.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from copy import deepcopy
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import shlex
import time
import urllib.error
import urllib.request

import claude_judge as judge

ROOT = Path(__file__).resolve().parent
FOLDER = ROOT / 'judge'
MODEL = 'claude-opus-5-5'
ENDPOINT = 'https://api.anthropic.com/v1/messages'
VERSION = '2023-06-01'


def api_schema():
    schema = deepcopy(judge.SCHEMA)
    properties = schema['properties']['cases']['items']['properties']['ratings']['items']['properties']
    for field, values in [('utility', list(range(-2, 3))), ('first_word', list(range(3)))]:
        properties[field] = dict(type='integer', enum=values)
    return schema


def payload_for(request):
    return dict(model=MODEL, max_tokens=16000, system=judge.SYSTEM,
                messages=[dict(role='user', content=request)],
                thinking=dict(type='adaptive', display='omitted'),
                output_config=dict(effort='high'))


def read_authorized_key(path):
    values = []
    for line in path.read_text().splitlines():
        match = re.match(r'^\s*(?:export\s+)?ANTHROPIC_API_KEY\s*=\s*(.*?)\s*$', line)
        if match:
            pieces = shlex.split(match.group(1), comments=True, posix=True)
            if len(pieces) == 1 and pieces[0]:
                values.append(pieces[0])
    if len(values) != 1 or '\n' in values[0]:
        raise ValueError('Expected one nonempty ANTHROPIC_API_KEY assignment')
    return values[0]


def amend_protocol(protocol):
    path = ROOT / 'judge-direct-api-amendment.json'
    script_hash = judge.digest(Path(__file__).read_bytes())
    if path.exists():
        assert json.loads(path.read_text())['adapterSHA256'] == script_hash
        return
    assert not list((FOLDER / 'batches').glob('*/ratings.json'))
    assert not list((FOLDER / 'batches').glob('*/anthropic-response.json'))
    judge.write_json(path, dict(atUTC=datetime.now(timezone.utc).isoformat(),
        reason='The user explicitly authorized the existing ANTHROPIC_API_KEY in the main checkout after the Claude CLI quota and configured OpenRouter model guardrail blocked all ratings.',
        priorRatingsReceived=0, transport='Anthropic Messages API', endpoint=ENDPOINT,
        apiVersion=VERSION, requestedModel=MODEL, effort='high',
        thinking=dict(type='adaptive', display='omitted'), toolsEnabled=False,
        adapterSHA256=script_hash, protocolSHA256=judge.digest((FOLDER / 'protocol.json').read_bytes()),
        rubricSHA256=judge.digest(judge.RUBRIC), systemSHA256=judge.digest(judge.SYSTEM),
        outputFormat='Plain JSON requested by the unchanged frozen rubric; parsed and coverage-validated against the original schema and packets. No API-level constrained output decoder.',
        formatCorrection='One schema-constrained direct API preflight returned only one empty case and no ratings. Original request, response, usage, adapter and amendment are preserved under judge/anthropic-format-failures/primary-01. Correct output transport only; no valid scores existed or were discarded.',
        schema=judge.SCHEMA, maxOutputTokensPerBatch=16000, maximumBatches=len(protocol['batches']),
        automaticRetries=False,
        responseAdapter='response.json contains the parsed original API JSON ratings, actual model ID, transport and SHA-256 of the unmodified anthropic-response.json. Both are independently validated.',
        unchanged='All frozen case IDs, anonymous option orders, packet/request hashes, system instruction, rubric, scoring, matching, native inputs, timings, default model and installed application.',
        credentials='Read only the specifically authorized variable in memory; never persisted in this evidence or supplied as evaluation data.',
        documentation=['https://platform.claude.com/docs/en/api/messages/create',
                       'https://platform.claude.com/docs/en/build-with-claude/structured-outputs',
                       'https://platform.claude.com/docs/en/build-with-claude/thinking']))


def run_batch(batch, key):
    folder = FOLDER / 'batches' / batch['id']
    if (folder / 'receipt.json').exists():
        receipt = json.loads((folder / 'receipt.json').read_text())
        assert receipt['transport'] == 'Anthropic Messages API'
        assert receipt['requestSHA256'] == batch['requestSHA256']
        assert receipt['apiResponseSHA256'] == judge.digest((folder / 'anthropic-response.json').read_bytes())
        return dict(batch=batch['id'], reused=True)
    request = (folder / 'request.txt').read_text()
    assert judge.digest(request) == batch['requestSHA256']
    packet = json.loads((folder / 'packet.json').read_text())
    assert set(packet) == {'cases'}
    assert all(set(case) == {'id', 'prefix', 'options'} for case in packet['cases'])
    assert all(set(option) == {'id', 'continuation'} for case in packet['cases'] for option in case['options'])
    assert request == judge.RUBRIC + json.dumps(packet['cases'], ensure_ascii=False, separators=(',', ':'))
    payload = payload_for(request)
    target = folder / 'anthropic-response.json'
    assert not target.exists() and not (folder / 'anthropic-error.json').exists(), 'Refuse to overwrite an API outcome.'
    judge.write_json(folder / 'anthropic-request.json', payload)
    started = time.monotonic()
    try:
        api_request = urllib.request.Request(ENDPOINT, data=json.dumps(payload).encode(),
            headers={'x-api-key':key, 'anthropic-version':VERSION, 'Content-Type':'application/json'}, method='POST')
        with urllib.request.urlopen(api_request, timeout=600) as response:
            raw = response.read()
            assert key.encode() not in raw, 'Unexpected credential echo'
            target.write_bytes(raw)
            request_id = response.headers.get('request-id')
    except urllib.error.HTTPError as error:
        body = error.read().replace(key.encode(), b'[REDACTED]')
        (folder / 'anthropic-error.json').write_bytes(body)
        raise RuntimeError(f'HTTP {error.code} for {batch["id"]}; response retained') from None
    elapsed = time.monotonic() - started
    response = json.loads(target.read_text())
    assert response['model'] == MODEL and response['type'] == 'message' and response['role'] == 'assistant'
    assert response['stop_reason'] == 'end_turn' and not response.get('error')
    assert all(block['type'] in ['text', 'thinking', 'redacted_thinking'] for block in response['content'])
    assert all(not block.get('thinking') for block in response['content'])
    content = ''.join(block['text'] for block in response['content'] if block['type'] == 'text')
    result = judge.validate_judgments(packet, json.loads(content), strict_preference=False)
    normalized = dict(is_error=False, structured_output=result, transport='Anthropic Messages API',
                      originalModel=response['model'], originalResponseSHA256=judge.digest(target.read_bytes()))
    judge.write_json(folder / 'response.json', normalized)
    judge.write_json(folder / 'ratings.json', result)
    judge.write_json(folder / 'preference-disagreements.json', judge.preference_disagreements(result))
    judge.write_json(folder / 'execution.json', dict(exitCode=0, wallSeconds=elapsed, requestedModel=MODEL,
        transport='Anthropic Messages API', requestID=request_id, usage=response.get('usage')))
    judge.write_json(folder / 'receipt.json', dict(models=[response['model']], apiModel=response['model'],
        transport='Anthropic Messages API', isError=False, durationMs=elapsed*1000,
        requestID=request_id, responseID=response['id'], requestSHA256=judge.digest(request),
        responseSHA256=judge.digest((folder/'response.json').read_bytes()),
        apiRequestSHA256=judge.digest((folder/'anthropic-request.json').read_bytes()),
        apiResponseSHA256=judge.digest(target.read_bytes()), toolsEnabled=False,
        suppliedPersonalWriting=False, suppliedSourceCode=False, suppliedFutureReference=False,
        suppliedImplementationLabels=False))
    return dict(batch=batch['id'], cases=len(result['cases']), model=response['model'],
                seconds=round(elapsed, 1), usage=response.get('usage'))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--env-file', type=Path, required=True)
    parser.add_argument('--batch')
    args = parser.parse_args()
    protocol = json.loads((FOLDER / 'protocol.json').read_text())
    assert len(protocol['batches']) == 25
    if not args.batch:
        assert (FOLDER / 'batches/primary-01/receipt.json').exists(), 'Require a successful preflight before batching.'
    selected = [b for b in protocol['batches'] if not args.batch or b['id'] == args.batch]
    assert selected
    amend_protocol(protocol)
    key = read_authorized_key(args.env_file)
    failures = []
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = {pool.submit(run_batch, batch, key): batch for batch in selected}
        for future in as_completed(futures):
            try:
                print(json.dumps(future.result()), flush=True)
            except Exception as error:
                # Do not print arbitrary exception contents that might contain request headers.
                failures.append(dict(batch=futures[future]['id'], errorType=type(error).__name__))
                print(json.dumps(failures[-1]), flush=True)
    if failures:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
