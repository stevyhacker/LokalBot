"""Render verified native measurements while external Claude ratings are blocked."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
NAMES = {'q6': 'Current E2B base i1 Q6', 'unsloth': 'Unsloth E2B IT Q6_K', 'bartowski': 'Bartowski E2B IT Q6_K'}


def main():
    data = json.loads((ROOT / 'summary.json').read_text())
    assert 'quality' not in data
    timing = data['timing']
    lines = ['**Native measurements; Claude quality ratings pending**', '',
        'All matched arms show 112/144 English and 109/144 Serbian Latin suggestions. These timings measure native completion, excluding load, debounce, accessibility and rendering.', '',
        '| Variant | Warm mean / p95, ms | Matched mean / p95, ms | Matched mean delta [95% interval], ms | Matched shown-only mean / p95, ms |',
        '|---|---:|---:|---:|---:|']
    for arm, name in NAMES.items():
        t = timing['normal']['steady']['fresh'][arm]['all']['paired']['candidate']
        m = timing['normal']['matched']['fresh'][arm]['all']
        a, pair, shown = m['paired']['candidate'], m['paired'], m['shownOnly']['candidate']
        lo, hi = pair['delta95CI']
        lines.append(f"| {name} | {t['mean']:.1f} / {t['p95']:.1f} | {a['mean']:.1f} / {a['p95']:.1f} | {pair['delta']:+.2f} [{lo:+.2f}, {hi:+.2f}] | {shown['mean']:.1f} / {shown['p95']:.1f} |")
    lines += ['', '**By language at matched frequency**', '',
        '| Variant | English mean / p95, ms | Serbian Latin mean / p95, ms | Exact authored first-word matches /288 (not Claude utility) |',
        '|---|---:|---:|---:|']
    for arm, name in NAMES.items():
        v = timing['normal']['matched']['fresh'][arm]
        a, b = (v[lang]['paired']['candidate'] for lang in ['en', 'sr_latn'])
        lines.append(f"| {name} | {a['mean']:.1f} / {a['p95']:.1f} | {b['mean']:.1f} / {b['p95']:.1f} | {data['outputs']['matched'][arm]['all']['referenceFirstWord']} |")
    lines += ['', '**Production gates: long fields, typing and cancellation**', '',
        '| Variant | Long mean / p95, ms | Typing mean / p95, ms | Cancellation return, paired current → candidate, ms | Cancellation through replacement, paired current → candidate, ms | Median peak RSS, GB |',
        '|---|---:|---:|---:|---:|---:|']
    for arm, name in NAMES.items():
        a = timing['normal']['production']['long'][arm]['all']['paired']['candidate']
        b = timing['normal']['production']['dynamic'][arm]['all']['paired']['candidate']
        c, d = (timing['cancellation'][arm][key] for key in ['returned', 'throughReplacement'])
        rss = timing['resources'][arm]['maximumResidentBytes']['median'] / 1e9
        lines.append(f"| {name} | {a['mean']:.1f} / {a['p95']:.1f} | {b['mean']:.1f} / {b['p95']:.1f} | {c['default']['mean']:.1f} → {c['candidate']['mean']:.1f} | {d['default']['mean']:.1f} → {d['candidate']['mean']:.1f} | {rss:.2f} |")
    lines += ['', 'Cancellation comparisons include only pairs where both models actually received cancellation and returned cancelled. Each candidate therefore has a different paired baseline; only four source scenarios were used.', '',
        '**Native confidence gates, fitted without quality labels**', '',
        '| Variant | EN primary / fallback | SR Latin primary / fallback |', '|---|---:|---:|---:|']
    for arm, name in NAMES.items():
        c = data['matching']['cutoffs'][arm]; a, b = c['en'], c['sr_latn']
        lines.append(f"| {name} | {a['primary']:.5f} / {a['fallback']:.5f} | {b['primary']:.5f} / {b['fallback']:.5f} |")
    lines += ['', 'The frozen implementation uses fallback = min(1, 3.1 × primary), so both IT fallback thresholds saturate at 1. These cutoffs are evaluation-only; current-Q6 text and all midword outputs remain unchanged.']
    (ROOT / 'TABLES.md').write_text('\n'.join(lines) + '\n')


if __name__ == '__main__':
    main()
