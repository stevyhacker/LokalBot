"""Annotate the preselected literal examples and disclose a few judged contrasts."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ARMS = ['q6', 'unsloth', 'bartowski']


def literal(text):
    return '`' + text.replace('|', '\\|') + '`'


def cell(case, arm):
    policy = arm + '-matched'
    value = case['ratings'][policy]['utility']
    text = case['policies'][policy]
    return (literal(text) if text else '—') + f' **({value:+d})**'


def table(lines, cases):
    lines += ['| Typed prefix | Current Q6 | Unsloth IT Q6 | Bartowski IT Q6 |',
              '|---|---|---|---|']
    for case in cases:
        lines.append('| ' + ' | '.join([literal(case['prefix'] + '▏')] + [cell(case, a) for a in ARMS]) + ' |')


def main():
    cases = json.loads((ROOT / 'quality-examples.json').read_text())
    by_id = {case['id']: case for case in cases}
    original = json.loads((ROOT / 'example-selection.json').read_text())['ids']
    lines = ['**Literal suggestions with blinded Claude Opus 5.5 ratings**', '',
        '`▏` marks the cursor; append the continuation directly. `—` means silence. Parentheses show Claude’s utility: +2 strongly useful, +1 useful, 0 neutral, −1 weak, −2 disruptive. These are model opinions, not human acceptance scores.', '',
        'The first twelve examples are unchanged from the pending report: the first three differing boundary and first three differing midword checkpoints per language in frozen corpus order. They were selected before Claude returned ratings.', '']
    for language, label in [('en', 'English'), ('sr_latn', 'Serbian Latin')]:
        lines += [f'**{label}: preselected examples**', '']
        table(lines, [by_id[i] for i in original if by_id[i]['language'] == language])
        lines += ['']
    lines += ['**Additional judged improvements and regressions**', '',
        'For each language, the table adds the first two cases in corpus order where an IT candidate scores above current Q6, then the first two where one scores below it, excluding examples above. This selection uses the completed ratings and is illustrative; the full sample determines the aggregate result.', '']
    extra = []
    used = set(original)
    for language in ['en', 'sr_latn']:
        for sign in [1, -1]:
            selected = []
            for case in cases:
                if case['language'] != language or case['id'] in used:
                    continue
                current = case['ratings']['q6-matched']['utility']
                if any(sign * (case['ratings'][a+'-matched']['utility'] - current) > 0 for a in ARMS[1:]):
                    selected.append(case)
                    used.add(case['id'])
                    if len(selected) == 2:
                        break
            extra.extend(selected)
    table(lines, extra)
    lines += ['', 'The authored future was absent from every Claude packet. All [288 exact cases and ratings](quality-examples.json) are available for inspection. Different plausible continuations may be useful; [the report](REPORT.md) includes uncertainty and reversed-order consistency checks.']
    (ROOT / 'EXAMPLES.md').write_text('\n'.join(lines) + '\n')
    (ROOT / 'judged-example-selection.json').write_text(json.dumps(dict(
        originalPreJudgeSelection=original, additionalPostJudgeSelection=[c['id'] for c in extra],
        rule='First two IT-above-current, then first two IT-below-current per language in frozen corpus order, excluding earlier selections.'), indent=2) + '\n')


if __name__ == '__main__':
    main()
