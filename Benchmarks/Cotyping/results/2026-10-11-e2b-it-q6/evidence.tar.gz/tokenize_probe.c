// Vocabulary-only probe using the exact libllama linked by the replay app.
#include "llama.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    if (argc != 2) return 2;
    llama_backend_init();
    struct llama_model_params params = llama_model_default_params();
    params.vocab_only = true;
    params.n_gpu_layers = 0;
    struct llama_model *model = llama_model_load_from_file(argv[1], params);
    if (!model) return 3;
    const struct llama_vocab *vocab = llama_model_get_vocab(model);
    uint32_t size;
    while (fread(&size, sizeof(size), 1, stdin) == 1) {
        if (size > 1024 * 1024) return 4;
        char *text = malloc(size + 1);
        if (!text || fread(text, 1, size, stdin) != size) return 5;
        text[size] = 0;
        int32_t needed = -llama_tokenize(vocab, text, (int32_t)size, NULL, 0, true, true);
        if (needed < 0) return 6;
        llama_token *tokens = malloc(((size_t)needed + 1) * sizeof(llama_token));
        if (!tokens) return 7;
        int32_t count = llama_tokenize(vocab, text, (int32_t)size, tokens, needed + 1, true, true);
        if (count < 0) return 8;
        uint32_t output_size = (uint32_t)count;
        if (fwrite(&output_size, sizeof(output_size), 1, stdout) != 1) return 9;
        if (fwrite(tokens, sizeof(llama_token), count, stdout) != (size_t)count) return 10;
        free(tokens);
        free(text);
    }
    llama_model_free(model);
    llama_backend_free();
    return 0;
}
