"""Download selected public E2B IT artifacts and verify pinned SHA-256."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import time
import urllib.request

ROOT = Path(__file__).resolve().parent
DEST = ROOT / 'models'
DEST.mkdir(exist_ok=True)
SELECTED = [
    ('unsloth', 'unsloth/gemma-4-E2B-it-GGUF', 'gemma-4-E2B-it-Q6_K.gguf'),
    ('bartowski', 'bartowski/google_gemma-4-E2B-it-GGUF', 'google_gemma-4-E2B-it-Q6_K.gguf'),
]

def sha(path):
    with path.open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()

def download(item):
    arm, repo, name = item
    metadata = json.loads((ROOT/'sources'/(repo.replace('/', '__')+'.json')).read_text())
    info = next(f for f in metadata['siblings'] if f['rfilename'] == name)
    expected = info['lfs']['sha256']
    path = DEST / (arm+'.gguf')
    url = f'https://huggingface.co/{repo}/resolve/{metadata["sha"]}/{name}'
    if not path.exists():
        part = path.with_suffix('.part')
        for attempt in range(3):
            try:
                request = urllib.request.Request(url+'?download=true&study=q6-'+str(int(time.time())), headers={'User-Agent':'LokalBot-Q6-study'})
                digest = hashlib.sha256(); size = 0; report = 1_000_000_000
                with urllib.request.urlopen(request, timeout=90) as response, part.open('wb') as file:
                    while data := response.read(8*1024*1024):
                        file.write(data); digest.update(data); size += len(data)
                        if size >= report:
                            print(json.dumps({'arm':arm, 'downloadedGB':round(size/1e9,2)}), flush=True); report += 1_000_000_000
                assert size == info['size'] and digest.hexdigest() == expected
                part.rename(path); break
            except Exception as error:
                print(json.dumps({'arm':arm, 'attempt':attempt+1, 'error':str(error)}), flush=True)
                if attempt == 2: raise
    assert path.stat().st_size == info['size'] and sha(path) == expected
    receipt = dict(id=arm, path=str(path), file=name, bytes=info['size'], sha256=expected, repository=repo,
                   revision=metadata['sha'], downloadURL=url, verifiedAtUTC=datetime.now(timezone.utc).isoformat())
    (ROOT/f'model-{arm}.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'verified':arm,'sha256':expected}),flush=True)
    return receipt

if __name__ == '__main__':
    (ROOT/'sources').mkdir(exist_ok=True)
    for arm, repo, name in SELECTED:
        with urllib.request.urlopen('https://huggingface.co/api/models/'+repo+'?blobs=true',timeout=60) as response:
            metadata=json.load(response)
        (ROOT/'sources'/(repo.replace('/','__')+'.json')).write_text(json.dumps(metadata,indent=2)+'\n')
        with urllib.request.urlopen(f'https://huggingface.co/{repo}/raw/{metadata["sha"]}/README.md',timeout=60) as response:
            card=response.read()
        (ROOT/'sources'/(repo.replace('/','__')+'.md')).write_bytes(card)
        print(json.dumps({'pinned':repo,'revision':metadata['sha']}),flush=True)
    records = list(ThreadPoolExecutor(max_workers=2).map(download, SELECTED))
    (ROOT/'downloaded.json').write_text(json.dumps(records,indent=2)+'\n')
