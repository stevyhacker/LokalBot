"""Compare exact native input tokens, retaining each publisher's EOG metadata."""
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import it_q6_experiment as experiment

root = Path(__file__).resolve().parent
study = experiment.study


def main():
    library = Path(study.read(root / 'binary.json')['path']).parent.parent / 'Resources/llama-cpp'
    command = ['clang', '-O2', '-std=c11', '-I' + str(library / 'include'),
               str(root / 'tokenize_probe.c'), '-L' + str(library), '-lllama',
               '-Wl,-rpath,' + str(library), '-o', str(root / 'tokenize-probe')]
    subprocess.run(command, check=True)
    prompts = sorted({c['prefix'] for f in (root / 'inputs').glob('*.json')
                      for c in study.read(f)['cases']} | {'Please check the ', 'Hvala na pomoći, '})
    assert all('<eos>' not in p for p in prompts)
    request = b''.join(struct.pack('<I', len(p.encode())) + p.encode() for p in prompts)
    records = {}
    for model in study.read(root / 'models.json'):
        with (root / ('tokenize-' + model['id'] + '.log')).open('wb') as log:
            result = subprocess.run([str(root / 'tokenize-probe'), model['path']],
                                    input=request, stdout=subprocess.PIPE, stderr=log, check=True)
        output = result.stdout
        sequences, offset = [], 0
        while offset < len(output):
            count, = struct.unpack_from('<I', output, offset)
            offset += 4
            sequences.append(list(struct.unpack_from('<' + 'i' * count, output, offset)))
            offset += 4 * count
        assert offset == len(output) and len(sequences) == len(prompts)
        records[model['id']] = dict(sha256=hashlib.sha256(output).hexdigest(), sequences=sequences)
    assert all(r['sequences'] == records['q6']['sequences'] for r in records.values())
    study.write(root / 'input-tokenization.json', dict(uniquePrompts=len(prompts), prompts=prompts,
        models=records, exactNativeTokenParity=True, inputAddSpecial=True, parseSpecial=True,
        compileCommand=command, probeSourceSHA256=study.sha(root / 'tokenize_probe.c'),
        probeExecutableSHA256=study.sha(root / 'tokenize-probe'),
        librarySHA256=study.sha(library / 'libllama.dylib'),
        headerSHA256=study.sha(library / 'include/llama.h')))
    print('Exact token IDs match across all models for', len(prompts), 'unique native input prefixes.')


if __name__ == '__main__':
    main()
