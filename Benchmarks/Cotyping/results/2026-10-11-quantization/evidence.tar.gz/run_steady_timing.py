"""Explicit follow-up for the first-pass Q8 warm-up effect; no new settings."""
from pathlib import Path
import quantization_experiment as study

root = Path(__file__).resolve().parent
plan = study.read(root/'steady-timing-plan.json')
for round_number, order in zip(plan['rounds'], plan['orders']):
    for arm in order:
        study.run_one(root, arm, 'production', round_number, 'fresh')
