from pathlib import Path
import json

root=Path(__file__).resolve().parent
d=json.loads((root/'summary.json').read_text())
arms=['q6','q4','iq4','q5','q8']
names=dict(q6='Q6_K (current)',q4='Q4_K_M',iq4='IQ4_XS',q5='Q5_K_M',q8='Q8_0')
models={m['id']:m for m in d['models']}
lines=[]
def line(text=''):lines.append(text)
def native(mode, dataset, arm):return d['timing']['normal'][mode][dataset][arm]['all']['paired']
def ms(row):return f"{row['candidate']['mean']:.1f} / {row['candidate']['p95']:.1f}"
def ci(row):return f"{row['delta']:+.2f} [{row['delta95CI'][0]:+.2f}, {row['delta95CI'][1]:+.2f}]"

line('**Warmed short-request timing and resource cost**')
line()
line('| Quantization | File GB | File change | Warm mean / p95 ms | Mean change vs Q6 | Peak RSS GB¹ |')
line('|---|---:|---:|---:|---:|---:|')
for a in arms:
    row=native('steady','fresh',a)
    change=(row['candidate']['mean']/row['default']['mean']-1)*100
    line(f"| {names[a]} | {models[a]['bytes']/1e9:.3f} | {(models[a]['bytes']/models['q6']['bytes']-1)*100:+.1f}% | {ms(row)} | {change:+.1f}% | {d['timing']['resources'][a]['maximumResidentBytes']['median']/1e9:.2f} |")
line()
line('¹ Median of ten production processes’ peak resident memory, including mapped weights; decimal GB. This is not a measurement of total system/GPU memory. Separate process footprint stays around 0.41 GB for every arm. Warmed timings use the two additional reversed-order rounds (576 observations per model).')
line()
line('**Production timing, including the original two passes**')
line()
line('| Quantization | Fresh mean / p95 ms | Long mean / p95 ms | Typing/backspace mean / p95 ms |')
line('|---|---:|---:|---:|')
for a in arms:line(f"| {names[a]} | {ms(native('production','fresh',a))} | {ms(native('production','long',a))} | {ms(native('production','dynamic',a))} |")
line()
line('Q8 fresh means were 86.7 and 57.8 ms in the original passes. The extra warm-run result above avoids using that first-use effect as the estimate of everyday short-request latency. Long/dynamic/cancellation timings retain the original two-pass cohort; they were not rerun in the warm-only follow-up.')
line()
line('**Equal suggestion frequency**')
line()
line('Every arm shows 124/144 English and 108/144 Serbian Latin suggestions: 232/288 overall. All midword outputs remain unchanged by frequency matching. The thresholds below are evaluation-only.')
line()
line('| Quantization | English primary / fallback | Serbian Latin primary / fallback | Matched mean / p95 ms | Paired mean difference [95% interval], ms |')
line('|---|---:|---:|---:|---:|')
for a in arms:
    cuts=d['matching']['cutoffs'][a];r=native('matched','fresh',a)
    line(f"| {names[a]} | {cuts['en']['primary']:.4f} / {cuts['en']['fallback']:.4f} | {cuts['sr_latn']['primary']:.4f} / {cuts['sr_latn']['fallback']:.4f} | {ms(r)} | {ci(r)} |")
line()
line('**Claude quality ratings**')
line()
line('Usefulness is an ordinal −2..2 score relative to silence=0, averaged over every checkpoint, including suppressed suggestions. Helpful means >0; poor means <0. Each language has 144 distinct checkpoints. These are model judgments, not acceptance rates.')
for mode in ['production','matched']:
    line();line(f'At {"unchanged production thresholds" if mode=="production" else "equal suggestion frequency"}:');line()
    line('| Quantization | EN shown | EN helpful / poor | EN mean utility | SR Latin shown | SR Latin helpful / poor | SR Latin mean utility | Overall difference [95% interval] |')
    line('|---|---:|---:|---:|---:|---:|---:|---:|')
    for a in arms:
        q=d['quality']['policies'][mode][a];en=q['en'];sr=q['sr_latn']
        line(f"| {names[a]} | {en['shown']} | {en['helpful']} / {en['poor']} | {en['meanUtility']:.3f} | {sr['shown']} | {sr['helpful']} / {sr['poor']} | {sr['meanUtility']:.3f} | {ci(q['all']['delta'])} |")
line()
line('**Cancellation and recovery**')
line()
line('| Quantization | Both cancelled, pairs | Return mean Q6 → arm, ms | Replacement-complete mean Q6 → arm, ms | Replacement-complete p95 Q6 → arm, ms | Mean replacement difference [95% interval], ms |')
line('|---|---:|---:|---:|---:|---:|')
for a in arms:
    c=d['timing']['cancellation'][a];r=c['returned'];x=c['throughReplacement']
    line(f"| {names[a]} | {x['candidate']['n']} | {r['default']['mean']:.1f} → {r['candidate']['mean']:.1f} | {x['default']['mean']:.1f} → {x['candidate']['mean']:.1f} | {x['default']['p95']:.1f} → {x['candidate']['p95']:.1f} | {ci(x)} |")
line()
line('Each model attempted 96 cancellations. Q4 delivered/cancelled 82; the other models delivered/cancelled 83. Both arms must cancel on the same request to enter a pair, so paired baseline values vary. There are only four independent bilingual cancellation scenarios; the 82–83 events are correlated repeats, and these intervals/tails are diagnostic. All 96 replacement/cold checks per model match (480/480).')
line()
rep=d['quality']['repeat']
line(f"Claude Opus 5.5 rated 240 primary cases and 24 reversed-order repeats. The repeats contained {rep['options']} distinct options: {rep['exactUtilityAgreement']*100:.1f}% exact utility agreement, {rep['showVsSilenceAgreement']*100:.1f}% agreement on positive utility versus silence, and {rep['meanAbsoluteDifference']:.3f} mean absolute score difference. Numeric-utility/preference inconsistencies: {len(d['quality']['preferenceInconsistencies'].get('primary',[]))} primary and {len(d['quality']['preferenceInconsistencies'].get('repeat',[]))} repeat cases. Raw ratings and a sensitivity analysis excluding inconsistent cases are retained.")
(root/'tables.md').write_text('\n'.join(lines)+'\n')
