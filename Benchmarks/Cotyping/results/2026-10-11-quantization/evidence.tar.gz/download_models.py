from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
import time
import urllib.request

root = Path(__file__).resolve().parent
destination = root / 'models'
destination.mkdir(exist_ok=True)
imatrix = json.loads((root / 'imatrix-metadata.json').read_text())
static = json.loads((root / 'static-metadata.json').read_text())
arms = [('q6', imatrix, 'gemma-4-E2B.i1-Q6_K.gguf'),
        ('q4', imatrix, 'gemma-4-E2B.i1-Q4_K_M.gguf'),
        ('iq4', imatrix, 'gemma-4-E2B.i1-IQ4_XS.gguf'),
        ('q5', imatrix, 'gemma-4-E2B.i1-Q5_K_M.gguf'),
        ('q8', static, 'gemma-4-E2B.Q8_0.gguf')]

def sha(path):
    with path.open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()

def download(item):
    arm, metadata, name = item
    info = next(f for f in metadata['siblings'] if f['rfilename'] == name)
    expected = info['lfs']['sha256']
    path = (Path('/Users/0xmithrandir/Library/Application Support/me.dotenv.LokalBot/models') / name
            if arm == 'q6' else destination / name)
    url = f"https://huggingface.co/{metadata['id']}/resolve/{metadata['sha']}/{name}"
    if not path.exists():
        part = path.with_suffix('.gguf.part')
        for attempt in range(3):
            try:
                request = urllib.request.Request(url + '?download=true&study=quant-' + str(int(time.time())),
                                                 headers={'User-Agent': 'LokalBot-quantization-evaluation'})
                digest = hashlib.sha256()
                written = 0
                next_progress = 1_000_000_000
                with urllib.request.urlopen(request, timeout=90) as response, part.open('wb') as file:
                    while data := response.read(8 * 1024 * 1024):
                        file.write(data)
                        digest.update(data)
                        written += len(data)
                        if written >= next_progress:
                            print(json.dumps({'arm': arm, 'downloadedGB': round(written / 1e9, 2)}), flush=True)
                            next_progress += 1_000_000_000
                assert written == info['size'] and digest.hexdigest() == expected
                part.rename(path)
                break
            except Exception as error:
                print(json.dumps({'arm': arm, 'attempt': attempt + 1, 'error': str(error)}), flush=True)
                if attempt == 2:
                    raise
        actual = expected
    else:
        actual = sha(path)
    assert actual == expected and path.stat().st_size == info['size']
    result = dict(id=arm, path=str(path), file=name, bytes=info['size'], sha256=actual,
                  repository=metadata['id'], revision=metadata['sha'], downloadURL=url,
                  verifiedAtUTC=datetime.now(timezone.utc).isoformat())
    (root / f'model-{arm}.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'verified': arm, 'bytes': info['size'], 'sha256': actual}), flush=True)
    return result

with ThreadPoolExecutor(max_workers=2) as pool:
    models = list(pool.map(download, arms))
(root / 'models.json').write_text(json.dumps(models, indent=2) + '\n')
print('All model downloads verified.', flush=True)
