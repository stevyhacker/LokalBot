**Warmed short-request timing and resource cost**

| Quantization | File GB | File change | Warm mean / p95 ms | Mean change vs Q6 | Peak RSS GB¹ |
|---|---:|---:|---:|---:|---:|
| Q6_K (current) | 3.845 | +0.0% | 53.4 / 107.2 | +0.0% | 4.15 |
| Q4_K_M | 3.428 | -10.9% | 48.4 / 96.3 | -9.4% | 3.74 |
| IQ4_XS | 3.304 | -14.1% | 53.4 / 100.8 | +0.0% | 3.61 |
| Q5_K_M | 3.630 | -5.6% | 56.9 / 111.4 | +6.6% | 3.94 |
| Q8_0 | 4.967 | +29.2% | 58.2 / 117.2 | +8.9% | 5.28 |

¹ Median of ten production processes’ peak resident memory, including mapped weights; decimal GB. This is not a measurement of total system/GPU memory. Separate process footprint stays around 0.41 GB for every arm. Warmed timings use the two additional reversed-order rounds (576 observations per model).

**Production timing, including the original two passes**

| Quantization | Fresh mean / p95 ms | Long mean / p95 ms | Typing/backspace mean / p95 ms |
|---|---:|---:|---:|
| Q6_K (current) | 53.6 / 107.5 | 151.4 / 243.5 | 45.8 / 85.9 |
| Q4_K_M | 49.1 / 99.5 | 151.0 / 245.0 | 39.5 / 83.2 |
| IQ4_XS | 53.4 / 99.7 | 143.7 / 228.0 | 41.0 / 76.6 |
| Q5_K_M | 56.4 / 109.8 | 159.7 / 260.7 | 47.0 / 92.8 |
| Q8_0 | 72.2 / 160.2 | 159.8 / 251.0 | 51.4 / 118.1 |

Q8 fresh means were 86.7 and 57.8 ms in the original passes. The extra warm-run result above avoids using that first-use effect as the estimate of everyday short-request latency. Long/dynamic/cancellation timings retain the original two-pass cohort; they were not rerun in the warm-only follow-up.

**Equal suggestion frequency**

Every arm shows 124/144 English and 108/144 Serbian Latin suggestions: 232/288 overall. All midword outputs remain unchanged by frequency matching. The thresholds below are evaluation-only.

| Quantization | English primary / fallback | Serbian Latin primary / fallback | Matched mean / p95 ms | Paired mean difference [95% interval], ms |
|---|---:|---:|---:|---:|
| Q6_K (current) | 0.0996 / 0.3089 | 0.1039 / 0.3220 | 53.5 / 107.6 | +0.00 [+0.00, +0.00] |
| Q4_K_M | 0.0874 / 0.2710 | 0.0852 / 0.2640 | 49.2 / 97.8 | -4.31 [-5.45, -3.09] |
| IQ4_XS | 0.0906 / 0.2810 | 0.1040 / 0.3224 | 53.8 / 101.0 | +0.35 [-0.84, +1.66] |
| Q5_K_M | 0.0982 / 0.3044 | 0.0975 / 0.3022 | 56.9 / 111.2 | +3.41 [+2.18, +4.71] |
| Q8_0 | 0.1008 / 0.3125 | 0.1041 / 0.3226 | 57.5 / 114.8 | +4.01 [+3.16, +4.95] |

**Claude quality ratings**

Usefulness is an ordinal −2..2 score relative to silence=0, averaged over every checkpoint, including suppressed suggestions. Helpful means >0; poor means <0. Each language has 144 distinct checkpoints. These are model judgments, not acceptance rates.

At unchanged production thresholds:

| Quantization | EN shown | EN helpful / poor | EN mean utility | SR Latin shown | SR Latin helpful / poor | SR Latin mean utility | Overall difference [95% interval] |
|---|---:|---:|---:|---:|---:|---:|---:|
| Q6_K (current) | 124 | 103 / 7 | 1.028 | 108 | 74 / 22 | 0.576 | +0.00 [+0.00, +0.00] |
| Q4_K_M | 120 | 101 / 10 | 1.021 | 107 | 71 / 24 | 0.528 | -0.03 [-0.11, +0.05] |
| IQ4_XS | 121 | 101 / 7 | 1.014 | 108 | 77 / 25 | 0.562 | -0.01 [-0.09, +0.07] |
| Q5_K_M | 124 | 103 / 10 | 1.035 | 107 | 76 / 17 | 0.625 | +0.03 [-0.03, +0.09] |
| Q8_0 | 124 | 104 / 9 | 1.062 | 108 | 77 / 18 | 0.639 | +0.05 [-0.01, +0.10] |

At equal suggestion frequency:

| Quantization | EN shown | EN helpful / poor | EN mean utility | SR Latin shown | SR Latin helpful / poor | SR Latin mean utility | Overall difference [95% interval] |
|---|---:|---:|---:|---:|---:|---:|---:|
| Q6_K (current) | 124 | 103 / 7 | 1.028 | 108 | 74 / 22 | 0.576 | +0.00 [+0.00, +0.00] |
| Q4_K_M | 124 | 104 / 10 | 1.049 | 108 | 71 / 24 | 0.528 | -0.01 [-0.10, +0.07] |
| IQ4_XS | 124 | 103 / 7 | 1.028 | 108 | 77 / 25 | 0.562 | -0.01 [-0.09, +0.07] |
| Q5_K_M | 124 | 103 / 10 | 1.035 | 108 | 77 / 17 | 0.632 | +0.03 [-0.03, +0.10] |
| Q8_0 | 124 | 104 / 9 | 1.062 | 108 | 77 / 18 | 0.639 | +0.05 [-0.01, +0.10] |

**Cancellation and recovery**

| Quantization | Both cancelled, pairs | Return mean Q6 → arm, ms | Replacement-complete mean Q6 → arm, ms | Replacement-complete p95 Q6 → arm, ms | Mean replacement difference [95% interval], ms |
|---|---:|---:|---:|---:|---:|
| Q6_K (current) | 83 | 33.7 → 33.7 | 214.6 → 214.6 | 409.8 → 409.8 | +0.00 [+0.00, +0.00] |
| Q4_K_M | 82 | 34.0 → 37.0 | 216.9 → 222.0 | 409.8 → 423.3 | +5.11 [+0.52, +12.44] |
| IQ4_XS | 82 | 34.1 → 38.5 | 216.5 → 211.7 | 409.8 → 395.3 | -4.86 [-12.84, +0.75] |
| Q5_K_M | 82 | 34.0 → 40.2 | 216.9 → 235.3 | 409.8 → 434.3 | +18.41 [+14.27, +21.69] |
| Q8_0 | 83 | 33.7 → 32.1 | 214.6 → 214.4 | 409.8 → 389.2 | -0.16 [-8.97, +10.75] |

Each model attempted 96 cancellations. Q4 delivered/cancelled 82; the other models delivered/cancelled 83. Both arms must cancel on the same request to enter a pair, so paired baseline values vary. There are only four independent bilingual cancellation scenarios; the 82–83 events are correlated repeats, and these intervals/tails are diagnostic. All 96 replacement/cold checks per model match (480/480).

Claude Opus 5.5 rated 240 primary cases and 24 reversed-order repeats. The repeats contained 39 distinct options: 66.7% exact utility agreement, 89.7% agreement on positive utility versus silence, and 0.359 mean absolute score difference. Numeric-utility/preference inconsistencies: 0 primary and 0 repeat cases. Raw ratings and a sensitivity analysis excluding inconsistent cases are retained.
