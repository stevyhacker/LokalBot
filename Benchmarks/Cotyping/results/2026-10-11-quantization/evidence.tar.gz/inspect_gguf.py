"""Read GGUF metadata and tensor layout without loading or executing model code."""
from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path
import struct

root=Path(__file__).resolve().parent
SCALAR={0:'B',1:'b',2:'H',3:'h',4:'I',5:'i',6:'f',7:'?',10:'Q',11:'q',12:'d'}
TYPE_NAMES={0:'F32',1:'F16',2:'Q4_0',3:'Q4_1',6:'Q5_0',7:'Q5_1',8:'Q8_0',
            10:'Q2_K',11:'Q3_K',12:'Q4_K',13:'Q5_K',14:'Q6_K',23:'IQ4_XS',30:'BF16'}

def parse(path):
    with path.open('rb') as file:
        def scalar(code):
            fmt='<'+SCALAR[code];return struct.unpack(fmt,file.read(struct.calcsize(fmt)))[0]
        def string():
            return file.read(scalar(10)).decode('utf-8')
        def value(kind):
            if kind==8:return string()
            if kind==9:
                subtype=scalar(4);count=scalar(10)
                return [value(subtype) for _ in range(count)]
            return scalar(kind)
        assert file.read(4)==b'GGUF'
        version=scalar(4);assert version==3
        n_tensors=scalar(10);n_kv=scalar(10)
        metadata={}
        for _ in range(n_kv):
            name=string();metadata[name]=value(scalar(4))
        tensors=[]
        for _ in range(n_tensors):
            name=string();dims=[scalar(10) for _ in range(scalar(4))]
            tensors.append(dict(name=name,shape=dims,type=scalar(4),offset=scalar(10),parameters=math.prod(dims)))
        alignment=metadata.get('general.alignment',32)
        start=(file.tell()+alignment-1)//alignment*alignment
        tensors.sort(key=lambda t:t['offset'])
        grouped=defaultdict(lambda:dict(tensors=0,parameters=0,paddedBytes=0))
        for index,tensor in enumerate(tensors):
            end=tensors[index+1]['offset'] if index+1<len(tensors) else path.stat().st_size-start
            tensor['paddedBytes']=end-tensor['offset']
            label=TYPE_NAMES.get(tensor['type'],str(tensor['type']))
            grouped[label]['tensors']+=1;grouped[label]['parameters']+=tensor['parameters'];grouped[label]['paddedBytes']+=tensor['paddedBytes']
        digest=lambda value:hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        return dict(version=version,tensorDataOffset=start,tensorCount=n_tensors,
                    metadata={k:v for k,v in metadata.items() if not isinstance(v,list) and not k.startswith('tokenizer.')},
                    tokenizerSHA256=digest({k:v for k,v in metadata.items() if k.startswith('tokenizer.')}),
                    architectureSHA256=digest({k:v for k,v in metadata.items() if k.startswith('gemma4.')}),
                    tensorShapesSHA256=digest(sorted((t['name'],t['shape']) for t in tensors)),
                    storedTypes=grouped,tensors=tensors)

def main():
    models=json.loads((root/'models.json').read_text())
    parsed={m['id']:parse(Path(m['path'])) for m in models}
    baseline=parsed['q6']
    for arm,data in parsed.items():
        for key in ['tokenizerSHA256','architectureSHA256','tensorShapesSHA256']:
            assert data[key]==baseline[key],(arm,key)
    maps={arm:{t['name']:t for t in data['tensors']} for arm,data in parsed.items()}
    common=[name for name,tensor in maps['q6'].items() if all(
        maps[arm][name]['type']==tensor['type'] and maps[arm][name]['paddedBytes']==tensor['paddedBytes'] for arm in parsed)]
    common_hashes={}
    for model in models:
        arm=model['id'];hashes={}
        with Path(model['path']).open('rb') as file:
            for name in common:
                tensor=maps[arm][name];file.seek(parsed[arm]['tensorDataOffset']+tensor['offset'])
                left=tensor['paddedBytes'];digest=hashlib.sha256()
                while left:
                    data=file.read(min(left,8*1024*1024));assert data
                    digest.update(data);left-=len(data)
                hashes[name]=digest.hexdigest()
        common_hashes[arm]=hashes
    matches={arm:sum(value==common_hashes['q6'][name] for name,value in hashes.items()) for arm,hashes in common_hashes.items()}
    report=dict(models=parsed,commonTensorCount=len(common),commonTensorBytes=sum(maps['q6'][n]['paddedBytes'] for n in common),
                commonTensorMatches=matches,commonTensorSHA256=common_hashes,
                note='Metadata, tokenizer and shapes match. Common-type tensor hashes are extra provenance evidence; publisher cards identify the same upstream model, but do not supply a full unquantized checkpoint hash.')
    (root/'gguf-inspection.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'commonTensorCount':len(common),'commonTensorMatches':matches,
                      'types':{arm:data['storedTypes'] for arm,data in parsed.items()}},indent=2))

if __name__=='__main__':main()
