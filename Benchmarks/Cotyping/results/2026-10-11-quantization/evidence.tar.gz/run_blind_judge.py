"""Send only reviewed fictional prefixes and anonymous continuations to Opus."""
from pathlib import Path
import quantization_experiment as study
import claude_judge as judge

root = Path(__file__).resolve().parent
folder = root/'judge'
prefixes = {case['prefix'] for case in study.read(root/'inputs/fresh.json')['cases']}
protocol = study.read(folder/'protocol.json')
for batch in protocol['batches']:
    packet = study.read(folder/'batches'/batch['id']/'packet.json')
    assert set(packet) == {'cases'}
    for case in packet['cases']:
        assert set(case) == {'id', 'prefix', 'options'}
        assert case['prefix'] in prefixes
        assert all(set(option) == {'id', 'continuation'} for option in case['options'])
judge.run(folder, jobs=4, selected=[], model='claude-opus-5-5')
