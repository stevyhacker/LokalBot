import importlib.util, json, random, hashlib
from pathlib import Path
p=Path('/Users/0xmithrandir/.codex/worktrees/experimental-autocomplete-hybrid/LokalBot/Benchmarks/Cotyping/latency_experiment.py')
spec=importlib.util.spec_from_file_location('study',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
arms=[a for a in m.ARMS if a!='current'];random.Random(10112026).shuffle(arms)
order=[('current',1),('installed',1),('current',2)]+[(a,1) for a in arms]+[('current',3)]
plan=m.OUT/'screen-order.json'
if not plan.exists():m.write(plan,dict(order=order,seed=10112026,edgesSHA256=m.sha(m.OUT/'inputs/edges.json'),startedAtUTC=m.now()))
for arm,r in order:
 m.run_one(arm,'regression',r)
 if arm=='current' and r==2:
  paths=[m.OUT/'prior-regression.jsonl']+[m.OUT/f'run-regression-{a}-{n}/raw.jsonl' for a,n in order[:3]]
  refs=[{x['id']:x for x in m.rows(path) if not x['id'].startswith('warmup-')} for path in paths]
  differences=[]
  base=refs[0]
  for path,rs in zip(paths[1:],refs[1:]):
   assert base.keys()==rs.keys(), (path,len(base),len(rs))
   diffs=[k for k in base if (base[k]['prompt'],base[k]['text'],base[k].get('suppression'))!=(rs[k]['prompt'],rs[k]['text'],rs[k].get('suppression'))]
   differences.append(dict(path=str(path),changed=diffs))
  m.write(m.OUT/'aa-parity.json',dict(pairedCases=len(base),comparisons=differences))
  assert not any(d['changed'] for d in differences),differences
  print('A/A and frozen installed parity: 288/288 each',flush=True)
m.analyze()
