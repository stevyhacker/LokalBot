from pathlib import Path
import json, shutil
root=Path('/Users/0xmithrandir/.codex/worktrees/experimental-autocomplete-hybrid/LokalBot')
p=root/'LokalBot/Cotyping/Llama/LlamaCotypingRuntime.swift';s=p.read_text()
s=s.replace('    private let replayThreadCount: Int32?\n','    private let replayThreadCount: Int32?\n    private let replayBatchThreadCount: Int32?\n')
s=s.replace('searchExperiment: CotypingSearchExperiment = .baseline, replayThreadCount: Int32? = nil,','searchExperiment: CotypingSearchExperiment = .baseline, replayThreadCount: Int32? = nil,\n         replayBatchThreadCount: Int32? = nil,')
s=s.replace('        self.replayThreadCount = replayThreadCount\n','        self.replayThreadCount = replayThreadCount\n        self.replayBatchThreadCount = replayBatchThreadCount\n')
s=s.replace('        cparams.n_threads_batch = threads\n','        cparams.n_threads_batch = replayBatchThreadCount ?? threads\n');p.write_text(s)
p=root/'LokalBot/Cotyping/CotypingQualityReplay.swift';s=p.read_text()
s=s.replace('        var nativeThreads: Int32?\n','        var nativeThreads: Int32?\n        var nativeBatchThreads: Int32?\n')
s=s.replace('        var cancelled = false\n','        var cancelled = false\n        var cancellationRequestedAfterMs: Double?\n')
s=s.replace('                    replayThreadCount: fixture.nativeThreads), modelPath: model.path)','                    replayThreadCount: fixture.nativeThreads,\n                    replayBatchThreadCount: fixture.nativeBatchThreads), modelPath: model.path)')
s=s.replace('                observation.nativeThreads = fixture.nativeThreads\n','                observation.nativeThreads = fixture.nativeThreads\n                observation.nativeBatchThreads = fixture.nativeBatchThreads\n')
s=s.replace('              input.nativeThreads.map({ (1...32).contains($0) }) ?? true else {','              input.nativeThreads.map({ (1...32).contains($0) }) ?? true,\n              input.nativeBatchThreads.map({ (1...32).contains($0) }) ?? true else {')
s=s.replace('let nativeControls = input.searchExperiment != nil || input.nativeThreads != nil || input.firstWordThreshold != nil', 'let nativeControls = input.searchExperiment != nil || input.nativeThreads != nil || input.nativeBatchThreads != nil || input.firstWordThreshold != nil')
old='''            do {
                let generation = Task { try await engine.generate(request) }
                let canceller = item.cancelAfterMs.map { delay in
                    Task {
                        try? await Task.sleep(for: .milliseconds(delay))
                        if !Task.isCancelled { generation.cancel() }
                    }
                }
                defer { canceller?.cancel() }
                let result = try await generation.value
'''
new='''            let generation = Task { try await engine.generate(request) }
            let canceller: Task<Double?, Never>? = item.cancelAfterMs.map { delay in
                Task {
                    try? await Task.sleep(for: .milliseconds(delay))
                    guard !Task.isCancelled else { return nil }
                    let issued = milliseconds(since: start)
                    generation.cancel()
                    return issued
                }
            }
            defer { canceller?.cancel() }
            do {
                let result = try await generation.value
                canceller?.cancel()
                let cancellationIssued = await canceller?.value
'''
assert old in s;s=s.replace(old,new)
s=s.replace('                                   attempts: attempt, prewarmMs: prewarmMs)','                                   attempts: attempt, prewarmMs: prewarmMs,\n                                   cancellationRequestedAfterMs: cancellationIssued)')
s=s.replace('                if error is CancellationError {\n                    return Observation','                if error is CancellationError {\n                    canceller?.cancel()\n                    let cancellationIssued = await canceller?.value\n                    return Observation')
s=s.replace('                        prewarmMs: prewarmMs, cancelled: true)','                        prewarmMs: prewarmMs, cancelled: true, cancellationRequestedAfterMs: cancellationIssued)')
p.write_text(s)
p=root/'LokalBotTests/CotypingFirstWordConfidenceTests.swift';s=p.read_text()
old='''        input.nativeThreads = 4
        for delay'''
new='''        input.nativeThreads = 4
        input.nativeBatchThreads = 0
        XCTAssertThrowsError(try CotypingQualityReplay.validateHybrid(input, engine: local))
        input.nativeBatchThreads = 33
        XCTAssertThrowsError(try CotypingQualityReplay.validateHybrid(input, engine: local))
        input.nativeBatchThreads = 14
        XCTAssertNoThrow(try CotypingQualityReplay.validateHybrid(input, engine: local))
        for delay'''
assert old in s;p.write_text(s.replace(old,new))
p=root/'Benchmarks/Cotyping/latency_experiment.py';s=p.read_text()
s=s.replace("certified_threads2={'searchExperiment':'certified','nativeThreads':2})", "certified_threads2={'searchExperiment':'certified','nativeThreads':2},\n    split_batch14={'searchExperiment':'certified','nativeThreads':2,'nativeBatchThreads':14})")
s=s.replace("binary=read(OUT/'binary.json');path=", "binary=read(OUT/('binary-threadsplit.json' if dataset.endswith('-threadsplit') else 'binary.json'));path=")
s=s.replace("p.add_argument('--dataset',choices=['regression','fresh','long','dynamic','edges','cancellation'])", "p.add_argument('--dataset')")
p.write_text(s)
out=root/'Benchmarks/Cotyping/results/2026-10-11-latency'
for dataset in ['fresh','dynamic','long','edges','cancellation']:
 for suffix in ['.json','-meta.json']:
  shutil.copy2(out/'inputs'/f'{dataset}{suffix}',out/'inputs'/f'{dataset}-threadsplit{suffix}')
(out/'threadsplit-plan.json').write_text(json.dumps(dict(
 reason='Close the independent generation/batch thread-count recommendation after observing slower cancellation in the combined two-thread arm.',
 beforeThreadsplitInference=True,controls='Same E2B, prompts, sampler, budgets and gates; second frozen binary has only independent batch-thread setting and cancellation-issued timestamp instrumentation.',
 rounds='Three counterbalanced fresh rounds of current, certified_threads2, split_batch14; one matched dynamic/long/Unicode/cancellation pass for all three. This follow-up reuses the frozen corpus and is not a new holdout.',
 compare='Select only if output-identical. Treat small latency changes as uncertain; do not claim improved cancellation from a configured timer without measuring actual delivery.',
 arms=dict(current={},certified_threads2=dict(searchExperiment='certified',nativeThreads=2),split_batch14=dict(searchExperiment='certified',nativeThreads=2,nativeBatchThreads=14))),indent=2)+'\n')
print('Independent batch threads and actual cancellation timestamp added.')
