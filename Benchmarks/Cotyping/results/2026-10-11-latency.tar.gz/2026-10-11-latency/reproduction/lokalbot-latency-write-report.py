from pathlib import Path
import json,statistics,hashlib,re
root=Path('/Users/0xmithrandir/.codex/worktrees/experimental-autocomplete-hybrid/LokalBot')
out=root/'Benchmarks/Cotyping/results/2026-10-11-latency'
read=lambda name:json.loads((out/name).read_text())
a=read('paired-analysis.json');integrity=read('state-integrity.json');q=read('claude-quality/summary.json')
names={'current':'Current decoder','reuse':'Skip identical-state restores only','memo':'Reuse scalar candidate rankings','certified':'Reuse + bounded-search skip proof','width2':'Two prefix paths','budget8':'Eight search expansions','exact':'Exact typed prefix only','threads2':'Reuse + 2 CPU threads','threads4':'Reuse + 4 CPU threads','threads2_only':'2 CPU threads only','certified_threads2':'Reuse + proof + 2 CPU threads','split_batch14':'Reuse + proof + 2 generation / 14 prefill'}
table=['| Workload | Current mean / p95 ms | Candidate mean / p95 ms | Mean reduction |','|---|---:|---:|---:|']
for dataset,label in [('fresh','Fresh EN + Serbian Latin'),('dynamic','Typing, backspace and recovery'),('long','Long fields, cold/prewarmed mix'),('edges','Unicode, digraphs and code switching')]:
 b,c=a[dataset]['current']['parts']['all'],a[dataset]['certified_threads2']['parts']['all']
 table.append(f"| {label} | {b['meanMs']:.1f} / {b['p95Ms']:.1f} | {c['meanMs']:.1f} / {c['p95Ms']:.1f} | {-c['paired']['relativePercent']:.1f}% |")
attempts=['| Variant | Development mean / p95 ms | Fresh mean / p95 ms | Changed fresh outputs /144 |','|---|---:|---:|---:|']
for arm in ['current','reuse','memo','certified','threads2_only','threads2','threads4','certified_threads2','width2','budget8','exact']:
 d=a['regression'][arm]['parts']['all'];f=a['fresh'].get(arm)
 ftext=f"{f['parts']['all']['meanMs']:.1f} / {f['parts']['all']['p95Ms']:.1f}" if f else 'Not advanced'
 changed=str(len(f['changedUniqueIDs'])) if f else '—'
 attempts.append(f"| {names[arm]} | {d['meanMs']:.1f} / {d['p95Ms']:.1f} | {ftext} | {changed} |")
report=f'''**E2B autocomplete latency experiments — 11 October 2026**

The strongest confirmed native-generation result is **per-request ranking reuse + bounded-search skip proof + two CPU threads**. On this M4 Max, mean latency fell **67.0 → 51.6 ms (23.0%)** and p95 **142.4 → 98.9 ms (30.5%)** on fresh English/Serbian Latin text. **All 1,496 paired non-cancelled observations in the primary study matched the current decoder exactly**, including suppression decisions and repeated measurements. This covers 728 distinct request IDs, many deliberately related. The 95% scenario-bootstrap interval for mean reduction is **21.6–24.4%**.

**Keep E2B as the default.** The installed app and its saved hybrid switch remain unchanged. These new performance controls are **replay-only**, with `baseline` still the production default. The draft PR contains the implementation seams, evidence and tests; this report does not claim that the faster candidate has been installed or released.

{chr(10).join(table)}

English mean latency improved **58.5 → 45.7 ms (21.9%)**; Serbian Latin **75.6 → 57.5 ms (23.9%)**. Every fresh arm retaining the same outputs showed **111/144 suggestions**: **61/72 English and 50/72 Serbian Latin**. Production gates stayed at 0.1/0.31. The older matched-frequency development set remained 250/288; do not mix those coverage figures.

**What was tested**

Eleven new variants, **75 serial replay runs and 11,064 measured requests**, excluding 600 warmups, across two separately pinned binaries. E2B weights, raw prompt text, sampler, token/word budgets and per-dataset confidence settings stayed fixed. Metal offload stayed enabled. The ordinary native thread setting on this machine is 14; reducing CPU workers did not switch inference off the GPU.

{chr(10).join(attempts)}

The table's main confirmation rows use three counterbalanced fresh rounds. Other fresh ablations use one round and are exploratory. Root-restore skipping alone was slower in screening and did not advance. Ranking reuse stores only ordered candidate IDs and full-vocabulary-normalized scalar scores within one request, avoiding repeated search work without the old full-logit LRU's retained buffers. Identical-state reuse requires authoritative single-token logits provenance, not just equal token IDs. The extra skip proof bounds alternatives at their first divergence from the retained baseline path; it does not claim a globally optimal unrestricted continuation.

The proof's incremental benefit is **not established**: memoization with two threads measured 51.2 ms in one fresh pass, versus the proof combination's repeated 51.6 ms. The latter is the strongest *confirmed* configuration, not evidence that the proof independently helps. Keep this distinction when selecting a smaller production patch.

**Separate generation and prefill threads**

A second frozen binary added independent prefill threads and recorded the actual cancellation-issuance timestamp. It reused the same corpus, so this is a follow-up, **not a new holdout**. Its three-round fresh results were:

| Configuration | Fresh mean / p95 ms | Dynamic mean ms, one pass | Long mix mean ms, one pass |
|---|---:|---:|---:|
| Current 14/14 | 68.6 / 143.2 | 105.1 | 178.6 |
| Reuse + proof, 2/2 | 51.8 / 100.1 | 82.9 | 162.3 |
| Reuse + proof, 2/14 | 52.7 / 100.8 | 83.2 | 168.8 |

All outputs matched. Splitting the threads did not improve ordinary generation overall, but cancellation exposed a tradeoff:

| Threads / search | Actual cancellation issued, ms | Request returned, ms | Immediate replacement, ms | Cancel + replacement, ms |
|---|---:|---:|---:|---:|
| Current 14/14 | 7.8 | 80.8 | 258.8 | 339.6 |
| Reuse + proof, 2/2 | 7.3 | 95.6 | 240.5 | 336.1 |
| Reuse + proof, 2/14 | 7.5 | 79.6 | 243.7 | 323.3 |

These are **12 long-prefill interruptions per arm in one follow-up pass**, requested after 5 ms. The faster normal configuration returned from cancellation later. The split setting traded about 1 ms of ordinary generation for a better cancellation-return point estimate. Do not infer a native/GPU mechanism from this alone. The explicit cold-reset cost is outside generation timing, and outstanding GPU synchronization may affect immediate replacement measurements. The useful next metric is cancellation through the *next usable suggestion*, including cleanup, rather than cancellation return alone.

**Claude quality judgment**

Claude Opus 5.5 judged all 83 changed fresh checkpoints plus 24 shared-output controls. Anonymous alternatives were deduplicated; no model/implementation labels, latency, intended future references, personal writing or product source were sent. There were 24 repeat cases, with **39/42 repeated option utility ratings agreeing exactly** and no preference/utility inconsistencies. Silence has utility 0; ratings run from −2 to +2.

| Ablation | Wins / losses / ties vs current, all 144 checkpoints | Mean utility delta, 95% scenario interval | Decision |
|---|---:|---:|---|
| Exact prefix only | 4 / 72 / 68 | −1.500 [−1.743, −1.250] | Reject: slower and much worse |
| Two prefix paths | 2 / 8 / 134 | −0.097 [−0.201, +0.007] | Keep width 4; negative trend, uncertainty includes zero |
| Eight expansions | 1 / 0 / 143 | +0.021 [0, +0.063] | One improved example is insufficient to reduce the budget |

The narrower search's losses were mostly Serbian Latin (2 wins / 7 losses); English had one loss. The exact-prefix policy often leaves the model in a poor midword state. The eight-expansion improvement avoids a repetitive tail on one Serbian prefix. The latency finalists retain identical suggestions, so their measured quality delta is zero by output equivalence; this is not a new human-acceptance claim. See [examples](EXAMPLES.md) and [judge summary](claude-quality/summary.json).

**Prewarming and closed gaps**

Prewarming already exists in the product. This study verifies its native behavior rather than introducing another prewarm trigger. On the original configuration, long-field generation fell **213.3 → 124.6 ms** after a **95.0 ms** prewarm; total work became **219.5 ms**. The fast candidate was **195.2 → 103.5 ms**, plus **94.0 ms** prewarm, totaling **197.5 ms**. This moves work earlier and does not itself save total compute. All 288 cold/prewarm output pairs across both phases matched.

Previously incomplete work now covered: exact-only/no-overshoot ablation, shared prefix ranking work, thread-count and independent batch-thread experiments, focus-style prewarming, typing/backspace/field-scope traces, Unicode normalization/digraph/ASCII/code-switching edges, and cancellation during short search and long prefill. All **216/216 cancellation recoveries** across controls and candidates matched cold references. The six native Qwen tests that previously lacked their separate fixture now ran and passed.

**Recommendation and remaining experiments**

1. Retain E2B, width 4, the 32-expansion fallback, prompt and confidence gates. Per-request ranking reuse is the smallest promising integration step. Keep the search-skip proof separate until its incremental benefit is isolated on new text.
2. Treat two CPU generation threads as a promising setting **for this M4 Max**, with generation/prefill controls separate. Two/two is the fastest confirmed native configuration; two/fourteen is the more interesting next rollout candidate when interruption responsiveness matters. Neither is established as a universal Apple Silicon default. Existing installed settings remain unchanged.
3. Run a new, pre-registered EN/Serbian Latin holdout comparing memoization with/without the proof and 14/14, 2/2, 2/14 and 4/14 threads; repeat long-field and dynamic traces. Then measure at least 100 interruptions through the next usable suggestion, with actual timer delivery, GPU synchronization and cache-reset cost inside the measured window. Follow with end-to-end debounce/AX/overlay timestamps on a remote UI runner and another Apple Silicon hardware class.

Claude's [final advisory review](claude-final-advice/ADVICE.md) favors memoization first, keeping the proof separately gated, and 2/14 as the next thread candidate because of the cancellation tradeoff. That is advice based on the same data, not an additional validation sample. Its broad statement about memo-only parity should be read within the actual tested workloads in the table; the full 1,496-observation check belongs to the proof-plus-memo finalist.

Multi-sequence batching, speculative full-logit caching, token-history learning and fine-tuning remain separate projects. They were not silently counted as completed here. The optional EuroLLM alternative and large-MoE ceiling from the earlier model queue do not isolate this fixed-E2B latency question. No private writing was mined for training or evaluation.

**Method and limits**

Primary source baseline: `43451050913894f14e37be354ee9e5b5395dc082`, based on master `193460c3def4e11aa44dc95e28bef8724c783e80`. Installed executable SHA-256 `ef6783c6e24a1d42f10ff76a353670c9e418132ddc33b73c2cd20d76baeb7b37`; E2B weight SHA-256 `20f49b221691c71d955e1d5a840b6e26329db4a5e1626f702fa4226e80a9c629`. Both remained unchanged after the study. New benchmark binaries are pinned separately in the archived metadata.

M4 Max, 48 GiB, macOS 27.0.1; release builds, isolated local storage/defaults, fixed seed `0xC0FFEE`, temperature 0.1, top-p 0.7, top-k 20, min-p 0.08, repetition penalty 1.05, six free tokens/four displayed words. Each process has eight excluded warmups. Model inference, builds and native tests were not run concurrently. Claude calls were remote and used only synthetic packets/aggregate statistics.

Native timing includes generation, healing and normalization. It excludes model load, spelling checks, explicit fixture cache resets, debounce, accessibility reads and overlay publication; prewarm is separately timed. It is **not time from keystroke to visible suggestion**. A/A controls reproduce the prior 288 saved outputs and the installed app byte-for-byte in text/suppression, and all prompt strings match within each paired comparison. The first controls averaged 74.8/75.5/75.6 ms; the copied installed app measured 75.5 ms.

Confidence intervals use 5,000 paired bootstrap draws over original scenarios, grouping both languages and nearby checkpoints: 24 fresh pairs, six dynamic source pairs, six long-field source pairs, 16 edge prefixes and three targeted cancellation prefixes. Repeated rounds are kept within their scenario rather than counted as independent examples. The long/dynamic grouping corrects the initially convenient per-trace IDs; the frozen inputs were not changed. Tail percentiles are empirical pooled observations, not confidence intervals. Do not pool latency between the two binaries/cohorts. One machine, synthetic text and one model judge do not establish user acceptance, battery cost or hardware portability.

[Validation](VALIDATION.md) · [Paired statistics](paired-analysis.json) · [Raw replay/judge/source archive](../2026-10-11-latency.tar.gz) · [SHA-256 manifest](../2026-10-11-latency-manifest.json) · [Previous experiment index](../2026-10-10-experiments.md)
'''
(out/'REPORT.md').write_text(report)
examples=read('claude-quality/examples.json');chosen=[]
for arm,language in [('exact','en'),('exact','sr_latn'),('width2','sr_latn'),('budget8','sr_latn')]:
 group=[e for e in examples if e['arm']==arm and e['language']==language]
 group.sort(key=lambda e:(-e['delta'] if arm=='budget8' else e['delta'],e['id']))
 if group:chosen.append(group[0])
text=['**Fresh latency-ablation examples**','','The fastest confirmed configuration produces exactly the current suggestion in every paired case. These examples show why changing the search constraints was less attractive. Selection: largest judged loss for exact-only in each language and width-two in Serbian; the sole budget-eight change. Every judged case is retained in the raw archive.','']
for e in chosen:
 text += [f"**{names[e['arm']]} — {e['language']}**",'',f"Typed: `{e['prefix']}`",'',f"Current (and fastest exact-output candidate): `{e['current']}` — utility {e['currentRating']['utility']}",'',f"Ablation: `{e['candidate']}` — utility {e['candidateRating']['utility']}",'',f"Claude: {e['candidateRating']['reason']}",'']
text+=['One model opinion on synthetic text, not a user acceptance measurement. The budget-eight improvement is one checkpoint, not a demonstrated general quality gain.','']
(out/'EXAMPLES.md').write_text('\n'.join(text))
logs=Path('/private/tmp/lokalbot-latency-20261011')
swift=(logs/'tests-final.log').read_text(errors='replace');assert '** TEST SUCCEEDED **' in swift and 'Executed 195 tests, with 0 failures' in swift
assert '** BUILD SUCCEEDED **' in (logs/'build-threadsplit.log').read_text(errors='replace')
assert 'Ran 61 tests' in (logs/'python-tests-final.log').read_text() and (logs/'swiftlint-final.log').read_text()==''
counts={k:sum(len(v[k]) for ds in integrity.values() for v in ds.values()) for k in ['recovery','prewarm']}
assert counts==dict(recovery=216,prewarm=288),counts
assert all(x['recoveredExactly'] for ds in integrity.values() for v in ds.values() for x in v['recovery'])
assert all(x['sameOutput'] for ds in integrity.values() for v in ds.values() for x in v['prewarm'])
for ds in a:
 for arm in ['certified','certified_threads2','split_batch14']:
  if arm in a[ds]:assert a[ds][arm]['changedObservations']==0,(ds,arm)
validation='''**Validation — 11 October 2026 latency study**

- Release benchmark builds succeeded for both pinned source snapshots. The final binary adds independent batch threads and actual cancellation-issuance timestamps; the app default remains `baseline`.
- Final focused non-UI XCTest: **195 passed, zero failed, zero skipped**. Covers the original 14 cotyping test classes plus new prefix-index, replay-control and cold/warm Unicode parity checks. Native parity includes default threads, two/two and two/fourteen. The separate pinned Qwen 0.8B fixture was supplied, so all six formerly skipped native checks ran.
- **61 benchmark Python tests passed**. Full strict SwiftLint and `git diff --check` passed. App project configuration and dependency pins are unchanged; no XcodeGen update was needed.
- 75 complete replay receipts, 11,064 measured rows plus 600 warmups. Every receipt's input and raw-output SHA-256 was checked. No replay errors. Primary A/A and copied-installed controls each match all 288 prior saved outputs; follow-up binary parity matches all 144 fresh outputs per selected arm.
- The main fastest candidate matches 1,496/1,496 non-cancelled paired observations in phase one and another 728/728 in phase two. Repeats are included and are not independent quality examples. Split threads also match all 728 follow-up observations.
- All 216 cancellation/recovery checks and all 288 cold/prewarm pairs across both phases match their cold reference exactly. This establishes state recovery, not instantaneous abort or cancellation latency improvement.
- Claude quality: verified `claude-opus-5-5`, tools/MCP disabled, all 107 primary and 24 repeat cases validated. No future references, private writing or product source sent. 39/42 repeat utility ratings agree; no inconsistent preferred/utility responses.
- Installed executable and E2B model hashes remain unchanged from the frozen plan. The existing hybrid setting is still enabled and there is no stale selector-test storage override. This study **did not reinstall or release an app**.
- No local UI tests. No CI workflow was changed, manually dispatched or retried. PR remains experimental/draft.

The final XCTest invocation used Debug, `-parallel-testing-enabled NO`, the 14 cotyping `-only-testing` selectors, an isolated `TEST_RUNNER_LOKALBOT_STORAGE_ROOT`, and the pinned E2B path through `TEST_RUNNER_LOKALBOT_CANDIDATE_TEST_MODEL`. Release uses `CODE_SIGNING_ALLOWED=NO` for headless benchmark copies; this is not a signing or installation receipt.

**Reproduction**

Extract the raw archive into a separate directory. It contains frozen inputs and metadata, original raw JSONL/stderr/receipts, phase-specific source patches, binary/model hashes, run order, Claude packets/responses and analysis snapshots. Model weights and app bundles are not redistributed. Read the recorded phase source/pins before comparing timings.

The runner supports `--output`, `--scratch` and `--model`; choose new directories and copy the frozen `inputs/` and `plan.json` there. `pin --binary <Release app executable>` verifies the E2B hash and refuses to replace existing binary metadata. Run `current` and `certified_threads2` against `fresh`, using new round numbers; never overwrite a frozen or failed attempt. `split_batch14` sets two generation/fourteen batch threads. The source defaults still point at this dated study, so supply new paths for a rerun.

The output-identical optimizations are available only through replay fields: `searchExperiment` (`baseline`, `reuseRoot`, `memoized`, `certified`, `widthTwo`, `budgetEight`, `exactOnly`), `nativeThreads` and `nativeBatchThreads`. Scope, delays, cancellation and prewarm controls are native-only and validated. Normal app construction leaves all of these at their existing defaults. Quality judgments require separate explicit authorization to send synthetic fixtures externally.

No existing expected output was relaxed. Three focused tests were added, and the new Unicode parity test also exercises thread settings. Earlier PR-wide changed expectations remain documented in the PR description.
'''
(out/'VALIDATION.md').write_text(validation)
loghash={name:hashlib.sha256((logs/name).read_bytes()).hexdigest() for name in ['build-final.log','build-threadsplit.log','tests.log','tests-final.log','swiftlint-final.log','python-tests-final.log']}
(out/'validation-receipt.json').write_text(json.dumps(dict(tests=195,skipped=0,failures=0,pythonTests=61,replayRuns=75,measuredRows=11064,warmups=600,recoveryPairs=216,prewarmPairs=288,localLogSHA256=loghash),indent=2)+'\n')
print('Wrote report, examples, validation and checked counts.')
