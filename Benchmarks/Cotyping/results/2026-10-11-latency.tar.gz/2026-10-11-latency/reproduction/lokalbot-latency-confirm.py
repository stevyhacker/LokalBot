import importlib.util,random
from pathlib import Path
p=Path('/Users/0xmithrandir/.codex/worktrees/experimental-autocomplete-hybrid/LokalBot/Benchmarks/Cotyping/latency_experiment.py')
spec=importlib.util.spec_from_file_location('study',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
assert (m.OUT/'analysis.json').exists(), 'Screening must finish before confirmation.'
if 'certified_threads2' not in m.ARMS:
 m.ARMS['certified_threads2']=dict(searchExperiment='certified',nativeThreads=2)
plan=m.OUT/'followup-order.json'
if not plan.exists():m.write(plan,dict(frozenAtUTC=m.now(),arms={a:m.ARMS[a] for a in ['threads2_only','certified_threads2']},order=['threads2_only','certified_threads2'],
 purpose='Separate thread-count contribution and test the combination of the two independently promising search/thread changes. Select on development before fresh confirmation.'))
for arm in ['threads2_only','certified_threads2']:m.run_one(arm,'regression',1)
base={r['id']:r for r in m.rows(m.OUT/'run-regression-current-1/raw.jsonl')[8:]}
rs=m.rows(m.OUT/'run-regression-certified_threads2-1/raw.jsonl')[8:]
assert all((r['text'],r.get('suppression'))==(base[r['id']]['text'],base[r['id']].get('suppression')) for r in rs)
finalists=['current','certified','certified_threads2']
order=[]
# Counterbalance which arm comes first/second/third within each dataset.
for n in range(1,4):
 for d in ['fresh','dynamic','long']:
  for a in finalists[n-1:]+finalists[:n-1]:order.append((a,d,n))
  if n==1 and d=='fresh':
   for a in ['exact','width2','budget8','memo','threads2','threads2_only','threads4']:order.append((a,'fresh',1))
for d in ['edges','cancellation']:
 for a in finalists:order.append((a,d,1))
plan=m.OUT/'confirmation-order.json'
if not plan.exists():m.write(plan,dict(frozenAtUTC=m.now(),finalists=finalists,order=order,
 selection='Certified search was the fastest exact-output 14-thread screening candidate. Combine it with the faster two-thread setting; verify the combination on development before this untouched fresh set. Non-finalist fresh rows remain exploratory ablations.',
 repeats='Three counterbalanced rounds for primary fresh/dynamic/long comparisons; one pass for Unicode/stress and secondary ablations.'))
for a,d,n in order:m.run_one(a,d,n)
m.analyze()
