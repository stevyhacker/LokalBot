from pathlib import Path
import importlib.util, json
root=Path('/Users/0xmithrandir/.codex/worktrees/experimental-autocomplete-hybrid/LokalBot')
p=root/'Benchmarks/Cotyping/latency_experiment.py'
s=p.read_text().replace("threads4={'searchExperiment':'memoized','nativeThreads':4})", "threads4={'searchExperiment':'memoized','nativeThreads':4}, threads2_only={'nativeThreads':2})")
s=s.replace("'dynamic','edges']", "'dynamic','edges','cancellation']");p.write_text(s)
spec=importlib.util.spec_from_file_location('study',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
settings=m.read(m.OUT/'inputs/fresh.json');settings.pop('cases')
base=m.rows(m.OUT/'run-regression-current-1/raw.jsonl')[8:]
inputs={r['id']:r for r in m.read(m.OUT/'inputs/regression.json')['cases']}
selected=sorted(base,key=lambda r:r['cache']['prefixSearchMs'],reverse=True)[:3]
cases=[];meta={}
for i,r in enumerate(selected):
 for delay in [1,25,60,130]:
  stem=f'cancel-search-{i}-{delay}'
  for action in ['cancel','recover','coldReference']:
   identifier=f'{stem}-{action}'
   case=dict(id=identifier,prefix=inputs[r['id']]['prefix'],cacheScope=stem,resetCache=action!='recover')
   if action=='cancel':case['cancelAfterMs']=delay
   cases.append(case);meta[identifier]=dict(scenario=stem,language='sr_latn',kind=action)
m.write(m.OUT/'inputs/cancellation.json',dict(settings,cases=cases));m.write(m.OUT/'inputs/cancellation-meta.json',meta)
m.write(m.OUT/'supplement-plan.json',dict(frozenAtUTC=m.now(),reason='Isolate thread-count contribution after the combined candidate improved screening; stress cancellation across prefill/search/free decode on the three slowest development prefixes.',
 threadAblation=dict(threads2_only={'nativeThreads':2}),cancellationCases=len(cases),cancellationSHA256=m.sha(m.OUT/'inputs/cancellation.json'),
 limits='Cancellation cases are adaptively selected stress tests, not fresh quality evidence. Wall delays do not guarantee a particular cancellation stage; use returned counters.'))
print('Prepared thread-only ablation and 36 cancellation/recovery cases.')
