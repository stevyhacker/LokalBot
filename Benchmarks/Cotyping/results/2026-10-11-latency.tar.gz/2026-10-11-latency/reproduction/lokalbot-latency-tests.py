from pathlib import Path
import json, importlib.util, unicodedata
root=Path('/Users/0xmithrandir/.codex/worktrees/experimental-autocomplete-hybrid/LokalBot')
p=root/'LokalBotTests/CotypingTokenPrefixIndexTests.swift'
s=p.read_text(); anchor='    func testInvalidLogitsDoNotWin() {'
addition='''    func testExactOnlyAblationRejectsOvershootAndPreservesByteFragments() {
        let pieces = [Array(" č".utf8), Array(" ča".utf8), Array(" čas".utf8), Array(" čaj".utf8)]
        let index = CotypingTokenPrefixIndex(vocabularySize: 4) { pieces[Int($0)] }
        let logits: [Float] = [2, 3, 5, 5]
        logits.withUnsafeBufferPointer { buffer in
            let remaining = Array(" ča".utf8)[...]
            XCTAssertEqual(index.bestTokens(in: buffer.baseAddress!, matching: remaining,
                preferWordExtendingOvershoot: false, limit: 4), [2, 3, 1, 0])
            XCTAssertEqual(index.bestTokens(in: buffer.baseAddress!, matching: remaining,
                preferWordExtendingOvershoot: false, limit: 4, exactOnly: true), [1, 0])
        }
    }

'''
assert anchor in s;p.write_text(s.replace(anchor,addition+anchor))
p=root/'LokalBotTests/CotypingTokenHealingTests.swift';s=p.read_text()
anchor='    private func request(prompt: String, wordPrefix: String) -> CotypingRequest {'
addition='''    @MainActor
    func testNativeSearchReusePreservesColdAndWarmUnicodeOutputs() async throws {
        guard let model = ProcessInfo.processInfo.environment["LOKALBOT_CANDIDATE_TEST_MODEL"] else {
            throw XCTSkip("Set LOKALBOT_CANDIDATE_TEST_MODEL for search-reuse parity.")
        }
        let prefixes = ["Mačka se stalno skriva iza kauča čim uključimo usi",
                        "Molim te sačekaj da pošaljem obaveš", "Račun je plaćen, proveri knjiž",
                        "The delivery driver called because the numb", "Please review the ",
                        "Pošalji mi ažurirani izveš".decomposedStringWithCanonicalMapping,
                        String(repeating: "The project notes mention testing and examples. ", count: 40)
                            + "Dogovorili smo sledeći sa"]
        var reference: [CotypingNormalizationResult] = []
        for experiment in [CotypingSearchExperiment.baseline, .reuseRoot, .memoized, .certified] {
            let runtime = LlamaCotypingRuntime(selectiveOneWordHybrid: true, searchExperiment: experiment)
            let engine = LocalLlamaCotypingEngine(runtime: runtime, modelPath: model)
            try await engine.prewarm()
            for (index, prefix) in prefixes.enumerated() {
                let request = CotypingRequest(
                    prompt: prefix, prefixText: prefix, trailingText: "", isMultiLine: false,
                    maxTokens: 6, maxWords: 4, temperature: 0.1, topP: 0.7, topK: 20, minP: 0.08,
                    repeatPenalty: 1.05, seed: 0xC0FFEE, generation: 0,
                    wordPrefixAtCaret: CotypingMidWord.currentPartialWord(in: prefix))
                await engine.clearReplayCache()
                let cold = try await engine.generate(request)
                if experiment == .baseline { reference.append(cold) }
                XCTAssertEqual(cold, reference[index], "\\(experiment): \\(prefix)")
                await engine.clearReplayCache()
                try await engine.prewarm(for: request)
                let warmed = try await engine.generate(request)
                XCTAssertEqual(warmed, reference[index], "Warm \\(experiment): \\(prefix)")
            }
            await engine.unload()
        }
    }

'''
assert anchor in s;p.write_text(s.replace(anchor,addition+anchor))
p=root/'LokalBotTests/CotypingFirstWordConfidenceTests.swift';s=p.read_text()
anchor='    @MainActor\n    func testNativeHybridMatchesCompositionAndNeverStreamsUncappedFallback() async throws {'
addition='''    func testReplayLatencyControlsRejectRemoteAndInvalidLimits() throws {
        let local = CotypingQualityReplay.Engine.local(model: URL(fileURLWithPath: "/synthetic.gguf"))
        let remote = CotypingQualityReplay.Engine.remote(
            baseURL: URL(string: "https://example.com")!, model: "test", extraBodyJSON: nil)
        var input = try JSONDecoder().decode(CotypingQualityReplay.Input.self,
            from: Data(#"{"cases":[{"id":"a","prefix":"Hello","cancelAfterMs":5}],"nativeThreads":2}"#.utf8))
        XCTAssertNoThrow(try CotypingQualityReplay.validateHybrid(input, engine: local))
        XCTAssertThrowsError(try CotypingQualityReplay.validateHybrid(input, engine: remote))
        input.nativeThreads = 0
        XCTAssertThrowsError(try CotypingQualityReplay.validateHybrid(input, engine: local))
        input.nativeThreads = 33
        XCTAssertThrowsError(try CotypingQualityReplay.validateHybrid(input, engine: local))
        input.nativeThreads = 4
        for delay in [Double.nan, .infinity, -1, 1001] {
            input.cases[0].cancelAfterMs = delay
            XCTAssertThrowsError(try CotypingQualityReplay.validateHybrid(input, engine: local))
        }
    }

'''
assert anchor in s;p.write_text(s.replace(anchor,addition+anchor))
# Frozen supplement before any measured run: accents, digraphs, ASCII and code switching.
out=root/'Benchmarks/Cotyping/results/2026-10-11-latency'
settings=json.loads((out/'inputs/fresh.json').read_text());settings.pop('cases')
prefixes=[
 ('sr_latn','Molim te pošalji računovodstvu ažurirani izveš'),
 ('sr_latn','Čekam da završiš sledeći zadatak pre nego što kren'),
 ('sr_latn','U fioci se nalaze rezervni ključevi i punja'),
 ('sr_latn','Želim da proverim da li je porudž'),
 ('sr_latn','Đorđe će nam poslati potvrdu o plaća'),
 ('sr_latn','Njena poslednja poruka objašnjava zašto kas'),
 ('sr_latn','Ljubazno vas molim da proverite važu'),
 ('sr_latn','Sačekaj da džez koncert poč'),
 ('sr_latn','Molim te posalji racunovodstvu azurirani izves'),
 ('sr_latn','Djordje ce nam poslati potvrdu o placa'),
 ('sr_latn','Deploy je završen, sada proveri health che'),
 ('sr_latn','Molim te reviewuj pull request pre nego što ga mer'),
 ('en','The café closes early, so please confirm the reserv'),
 ('en','Please send Đorđe the latest build before the meet'),
 ('en','The account balance is 125.50 and the reference is INV-20'),
 ('en','Use PostgreSQL for the archive and keep the existing sche')]
cases=[];meta={}
for i,(lang,prefix) in enumerate(prefixes):
 for normalization in ['NFC','NFD']:
  key=f'edge-{i:02}-{normalization}'
  cases.append(dict(id=key,prefix=unicodedata.normalize(normalization,prefix),resetCache=True))
  meta[key]=dict(scenario=i,language=lang,kind=normalization)
for name,obj in [('edges',dict(settings,cases=cases)),('edges-meta',meta)]:
 p=out/'inputs'/f'{name}.json';assert not p.exists();p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
p=root/'Benchmarks/Cotyping/latency_experiment.py';s=p.read_text().replace("choices=['regression','fresh','long','dynamic']","choices=['regression','fresh','long','dynamic','edges']");p.write_text(s)
print('Added three focused tests and 32 frozen Unicode/code-switching cases.')
