import importlib.util,shutil,subprocess
from pathlib import Path
p=Path('/Users/0xmithrandir/.codex/worktrees/experimental-autocomplete-hybrid/LokalBot/Benchmarks/Cotyping/latency_experiment.py')
spec=importlib.util.spec_from_file_location('study',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
source=m.ROOT/'.build/HybridDerivedData/Build/Products/Release/LokalBot.app'
target=m.TMP/'threadsplit.app';shutil.copytree(source,target)
m.write(m.OUT/'binary-threadsplit.json',dict(path=str(target/'Contents/MacOS/LokalBot'),sha256=m.sha(target/'Contents/MacOS/LokalBot'),createdAtUTC=m.now()))
subprocess.run(['git','diff','--','LokalBot'],cwd=m.ROOT,stdout=(m.OUT/'threadsplit-source.patch').open('w'),check=True)
arms=['current','certified_threads2','split_batch14'];order=[]
for n in range(1,4):
 for a in arms[n-1:]+arms[:n-1]:order.append((a,'fresh-threadsplit',n))
for d in ['dynamic','long','edges','cancellation']:
 for a in arms:order.append((a,d+'-threadsplit',1))
m.write(m.OUT/'threadsplit-order.json',dict(order=order,startedAtUTC=m.now(),analysisClusters='Fresh: 24 original paired sentences. Dynamic and long: six original paired sentences, not 12 traces or 24 checkpoint pairs. Cancellation: three source prefixes.'))
for a,d,n in order:
 m.run_one(a,d,n)
 if d=='fresh-threadsplit' and n==1:
  reference={r['id']:r for r in m.rows(m.OUT/'run-fresh-current-1/raw.jsonl')[8:]}
  rs=m.rows(m.OUT/f'run-{d}-{a}-{n}/raw.jsonl')[8:]
  changed=[r['id'] for r in rs if (r['prompt'],r['text'],r.get('suppression'))!=(reference[r['id']]['prompt'],reference[r['id']]['text'],reference[r['id']].get('suppression'))]
  m.write(m.OUT/f'threadsplit-{a}-parity.json',dict(paired=144,changed=changed))
  assert not changed,(a,changed)
m.analyze()
