import hashlib,json,pathlib,shutil,subprocess,datetime
repo=pathlib.Path('/Users/0xmithrandir/.codex/worktrees/4d628f81-0a81-4922-926a-c8c47dc4dbec/LokalBot')
out=repo/'Benchmarks/Cotyping/results/2026-10-10-calibration';temp=pathlib.Path('/private/tmp/lokalbot-calibration-20261010')
provenance=out/'provenance';provenance.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files=list((repo/'LokalBot/Cotyping').rglob('*.swift'))
files += [repo/x for x in ['LokalBot/Models/AppSettings.swift','LokalBot/Engines/ModelCatalog.swift','LokalBotTests/CotypingFirstWordConfidenceTests.swift','Benchmarks/Cotyping/confidence_calibration.py','Benchmarks/Cotyping/test_confidence_calibration.py','Benchmarks/Cotyping/claude_judge.py','Benchmarks/Cotyping/model_study.py','Benchmarks/Cotyping/quality_replay.py']]
manifest={}
for source in files:
    relative=source.relative_to(repo); target=provenance/'source'/relative;target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target);manifest[str(relative)]=sha(source)
(out/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name in ['download.py','preflight.py','reference-parity.py','build.log','tests.log','lint.log','python-tests.log','preflight.log','download.log']:
    source=temp/name
    if source.exists():shutil.copyfile(source,provenance/name)
for p in (temp/'models').glob('*receipt.json'):shutil.copyfile(p,provenance/p.name)
(out/'timing-plan.json').write_text(json.dumps({'createdAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rounds':[['baseline','luchador','gemma4_it','qwen3_base4','salamandra2','yugogpt7','original'],['original','yugogpt7','salamandra2','qwen3_base4','gemma4_it','luchador','baseline'],['qwen3_base4','salamandra2','yugogpt7','original','baseline','luchador','gemma4_it']],'traceTimingsExcluded':True,'noConcurrentBuildDownloadOrGPUBenchmark':True},indent=2)+'\n')
(out/'implementation-notes.json').write_text(json.dumps({'createdAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'planScriptSHA256':json.loads((out/'plan.json').read_text())['scriptSHA256'],'currentScriptSHA256':sha(repo/'Benchmarks/Cotyping/confidence_calibration.py'),'changeAfterPlan':'Clamp probability cutoffs to 1 when disabling a branch, retaining the exact native count assertion. Added a focused test. No model quality results or holdout outputs inspected to make this adjustment.'},indent=2)+'\n')
print(json.dumps({'sourceFiles':len(manifest),'output':str(out)}))
