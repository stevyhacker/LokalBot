import pathlib,sys
repo=pathlib.Path('/Users/0xmithrandir/.codex/worktrees/4d628f81-0a81-4922-926a-c8c47dc4dbec/LokalBot')
sys.path.insert(0,str(repo/'Benchmarks/Cotyping'))
from confidence_calibration import OUT,IDS,read,run_one
from calibration_stress import run_one as run_long,analyze as analyze_long
for i,order in enumerate(read(OUT/'timing-plan.json')['rounds'],1):
    for model in order:run_one('confirmation','matched',model,i)
for model in IDS+['original']:run_one('confirmation','frozen',model)
for model in ['baseline','original']:run_one('confirmation','asis',model)
for i,order in enumerate([IDS,list(reversed(IDS)),IDS[3:]+IDS[:3]],1):
    for model in order:run_long(model,i)
analyze_long()
