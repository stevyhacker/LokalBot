import concurrent.futures, hashlib, json, pathlib, subprocess, time
root = pathlib.Path('/private/tmp/lokalbot-calibration-20261010')
repo = pathlib.Path('/Users/0xmithrandir/.codex/worktrees/4d628f81-0a81-4922-926a-c8c47dc4dbec/LokalBot')
queued = json.loads((repo/'Benchmarks/Cotyping/results/2026-10-10-models/claude-test-list.json').read_text())['models']
def download(m):
    q = m['quantization']; p = root/'models'/q['filename']; part = p.with_suffix('.part')
    start = time.monotonic()
    if not p.exists():
        subprocess.run(['curl','--fail','--location','--silent','--show-error','--retry','3','--continue-at','-','--output',str(part),q['downloadURL']],check=True)
        assert part.stat().st_size == q['bytes'], m['id']
        part.rename(p)
    with p.open('rb') as f: sha = hashlib.file_digest(f, 'sha256').hexdigest()
    assert sha == q['publishedSHA256'], m['id']
    receipt = dict(id=m['id'],path=str(p),sha256=sha,bytes=p.stat().st_size,url=q['downloadURL'],verified=True,seconds=time.monotonic()-start)
    (root/'models'/(m['id']+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(download,queued))
