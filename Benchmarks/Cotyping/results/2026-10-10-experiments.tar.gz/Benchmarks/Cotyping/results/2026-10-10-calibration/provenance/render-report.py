import json, pathlib, hashlib, statistics, datetime, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
read=lambda name: json.loads((ROOT/name).read_text())
write=lambda name,x:(ROOT/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
a=read('analysis.json');long=read('long-analysis.json');refs=read('confirmation-references.json')
names={'baseline':'Gemma E2B hybrid','luchador':'Luchador E4B hybrid','gemma4_it':'Stock Gemma E4B IT hybrid','qwen3_base4':'Qwen3 4B Base hybrid','salamandra2':'Salamandra 2B hybrid','yugogpt7':'YugoGPT 7B hybrid','original':'E2B single gate'}
order=['luchador','gemma4_it','baseline','qwen3_base4','salamandra2','yugogpt7','original']
models={m['id']:m for m in read('models.json')}
selection=dict(selectedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),model='luchador',
    status='experimental default candidate selected under the user fallback rule',
    reason='No new candidate beats Luchador on the predeclared matched-frequency word-boundary utility. It is not proven superior to E2B overall.',
    modelPin=models['luchador'],fallbackModel=models['baseline'],
    gatesForAnAppTrial={'selectiveOneWordHybrid':True,'firstWordThreshold':.1,'hybridFallbackThreshold':.31},
    calibratedGatesStatus='replay-only; holdout quantiles must not be installed as production calibration',
    appDefaultsChanged=False,installedAppChanged=False,prCIChanged=False,
    knownTradeoffs='SR Latin midword judged utility and latency favor E2B; confirm with a native speaker and a prospective frozen-gate trial.')
write('selection.json',selection)

inputs={c['id']:c['prefix'] for c in read('confirmation-input.json')['cases']}
judgments=read('judge-confirmation/scores.json')
observed={m:{r['id']:r for r in map(json.loads,(ROOT/f'confirmation-matched-1-{m}/observations.jsonl').read_text().splitlines())} for m in ['baseline','luchador','gemma4_it']}
chosen=[]
for language,kind,direction,count in [('en','boundary',1,2),('en','boundary',-1,1),('sr_latn','boundary',1,1),('sr_latn','boundary',-1,1),('sr_latn','midword',1,1),('sr_latn','midword',-1,3)]:
    candidates=[]
    for k,ref in refs.items():
        if ref['language']!=language or ref['kind']!=kind:continue
        scores={m:judgments[k][observed[m][k]['text']]['utility'] for m in observed}
        if (scores['luchador']-scores['baseline'])*direction>0:candidates.append(k)
    chosen.extend(candidates[:count])
example_data=[]; lines=['# Paired examples','',
    'Illustrative wins and losses from the same matched-frequency confirmation run. The score table in REPORT.md uses every case. These examples are selected in corpus order within language, checkpoint type and win/loss strata, not an additional test. `▌` marks the caret; append the suffix exactly. Claude utility is −2…+2; silence is zero.','']
for i,k in enumerate(chosen,1):
    record=dict(id=k,prefix=inputs[k],language=refs[k]['language'],kind=refs[k]['kind'],options={})
    lines += [f'## {i}. {refs[k]["language"]} · {refs[k]["kind"]}','',f'Typed: `{inputs[k]}▌`','', '| Model | Offered suffix | Opus utility |','|---|---|---:|']
    for m in observed:
        text=observed[m][k]['text'];rating=judgments[k][text]
        record['options'][m]=dict(text=text,combined=inputs[k]+text,rating=rating)
        cell='`'+text.replace('`','ˋ').replace('|','\\|')+'`' if text else 'Silence'
        lines.append(f'| {names[m]} | {cell} | {rating["utility"]:+d} |')
    lines += ['']; example_data.append(record)
(ROOT/'EXAMPLES.md').write_text('\n'.join(lines)+'\n');write('examples.json',example_data)

native=[p for p in ROOT.glob('*/receipt.json') if read(str(p.relative_to(ROOT))).get('complete')]
calls=0;warm=0;errors=0
for path in native:
    raw=path.parent/'raw.jsonl';rs=[json.loads(s) for s in raw.read_text().splitlines()]
    calls+=len(rs);warm+=sum(r['id'].startswith('warmup-') for r in rs);errors+=sum(bool(r.get('error')) for r in rs)
reference=read('original-binary-parity/receipt.json');calls+=reference['requests'];warm+=8
parity_files=list(ROOT.glob('*/trace-parity.json'));assert not any(read(str(p.relative_to(ROOT))) for p in parity_files)
assert not reference['differences'] and errors==0
validation=dict(nativeCalls=calls,warmups=warm,measuredOrDiagnosticCalls=calls-warm,nativeRuns=len(native)+1,
    primaryTimedCalls=7*3*192,longTimedCalls=6*3*32,nativeErrors=errors,counterfactualParityRuns=len(parity_files),
    immutableBuildParityRequests=reference['requests'],immutableBuildParityDifferences=0,
    swiftTests=67,pythonTests=61,strictSwiftLint='passed',releaseBuild='passed',localUITestsRun=False,
    repeatedPrimaryOutputDifferences=0,modelChecksumsVerified=6)
write('validation.json',validation)

text=['# Confidence calibration and model confirmation — 10 October 2026','',
    '**Luchador remains the experimental default pick under the requested fallback rule: none of the four new candidates beats its predeclared word-start score. It is not a demonstrated universal upgrade over E2B.** At equal frequency, its combined English/Serbian Latin advantage over E2B is only +0.021 utility, with a 95% scenario-cluster interval of −0.177 to +0.214. E2B is faster and had fewer poor Serbian Latin outputs.','',
    'The experiment, native replay controls, model downloads, fresh Claude judgments and timing runs are complete. [selection.json](selection.json) records the choice and pinned rollback model. The installed app and app defaults were **not changed** in this experiment; the existing draft PR and CI were left alone. The learned cutoffs remain replay controls.','',
    '## Matched-frequency confirmation','',
    'Every arm showed **140/192 suggestions**, exactly **70/96 in English and 70/96 in Serbian Latin**. That consists of 38/64 word-start suggestions and 32/32 midword suggestions per language. No Cyrillic input cases enter selection. The judge still penalized unwanted script/language switches out of Latin.','',
    'Useful means Claude utility >0; poor means <0. Remaining shown suggestions are neutral. Utility is an ordinal −2…+2 score relative to silence, not a human acceptance rate. “E2B single gate” is the legacy decoder with its own matched-frequency cutoff; “E2B hybrid” is the previously enabled hybrid design. All rows below are calibrated comparison configurations.','',
    '| Model | Word-start utility (primary) | Overall utility | Useful / poor of 140 shown | English useful / poor of 70 | Serbian Latin useful / poor of 70 | Mean / p95 ms |',
    '|---|---:|---:|---:|---:|---:|---:|']
for m in order:
    v=a['arms']['matched-'+m];t=v['latency']['overall'];en=v['allLanguages']['en'];sr=v['allLanguages']['sr_latn'];o=v['overall']
    text.append(f'| {names[m]} | {v["boundary"]["meanUtility"]:.3f} | {o["meanUtility"]:.3f} | {o["useful"]} / {o["poor"]} | {en["useful"]} / {en["poor"]} | {sr["useful"]} / {sr["poor"]} | {t["meanMs"]:.1f} / {t["p95Ms"]:.1f} |')
text += ['',
    'The Luchador vs stock IT difference is unresolved: primary utility difference +0.047, 95% interval −0.031 to +0.125. Their sizes (~6.33 GB) and latency are nearly identical. Stock IT does not establish an advantage over the fine-tune. Qwen3 4B and YugoGPT do not improve the combined tradeoff; Salamandra is much faster but has weak Serbian Latin quality here. This round covers E2B, Luchador and all four Claude additions; the earlier LFM2.5/Qwen3.5/base-E4B runs are not mixed into this matched-frequency ranking.','',
    '**The clearest decoder result is the E2B hybrid:** compared with the matched single gate, it gives 13 more useful suggestions and 11 fewer poor ones at essentially the same latency. Overall utility improves +0.104 [0.021, 0.193]; word-start utility +0.156 [0.031, 0.289]. This is evidence for the selective hybrid versus the single gate, both calibrated to equal frequency—not proof that threshold fitting alone caused the gain.','',
    '## What calibration changed','',
    'The replay can retain a whole normalized candidate and its one-word alternative while recording both gate scores. Native verification reconstructs each gated output from that trace. The trace does not reject low-confidence text; it is excluded from performance comparisons. Two positive replay thresholds are configurable globally or per case; ordinary app defaults remain 0.1 and 0.31.','',
    'Seven fallback/primary ratios were fixed in advance: 0.5, 1, 2, 3.1, 5, 10 and 1,000,000 (effectively primary-only). Development Claude utility chose one ratio per model at equal word-start frequency. The chosen ratios were E2B/Luchador 3.1, stock IT/Qwen3 2, and Salamandra/YugoGPT 0.5. Language-specific cutoffs were frozen before confirmation inference.','',
    'The strict matched-frequency table uses **unlabeled confirmation confidence quantiles**, with the development ratio fixed. It is a transductive diagnostic, not deployable calibration. No confirmation quality labels set those cutoffs. The frozen development cutoffs are also evaluated independently:','',
    '| Model | Confirmation shown using frozen development cutoffs / 192 | Overall utility |','|---|---:|---:|']
for m in order:
    v=a['arms']['frozen-'+m]['overall'];text.append(f'| {names[m]} | {v["shown"]} | {v["meanUtility"]:.3f} |')
text += ['',
    'The intended 140/192 rate drifted on unseen inputs. In particular E2B reached 153 and Luchador 138, so their frozen-cutoff utility totals are not a fair equal-frequency ranking. Exact language labels are supplied by the fixture; an automatic production language router was not tested. These are score/cutoff calibrations, not calibrated probabilities of acceptance.','',
    'With the original 0.1/0.31 gates, heldout E2B hybrid shows 117/192 and Luchador 165/192. Their overall utilities are 0.542 and 0.797 respectively. That large apparent advantage shrinks substantially after matching frequency. These as-is figures are a different comparison from the main table.','',
    '## Latency beyond short prefixes','',
    'Primary latency comprises 576 actual native requests per arm in three serial, reordered rounds, with tracing disabled and confidence early exits enabled. Loading and eight warmups per process are excluded. Times include generation, token healing and normalization; they exclude debounce, accessibility, overlay rendering and first-visible UI latency.','',
    'The separate long-document stress set uses 16 fresh/shared pairs, balanced by language, with production context limits and frozen development cutoffs. Its suggestion rates are **not matched**; use it to understand prefill cost, not to rank quality. Each model has 96 measured requests:','',
    '| Model | Fresh-context mean / p95 ms | Shared-prefix mean / p95 ms |','|---|---:|---:|']
for m in order[:-1]:
    f=long[m]['transitions']['fresh'];s=long[m]['transitions']['shared']
    text.append(f'| {names[m]} | {f["meanMs"]:.1f} / {f["p95Ms"]:.1f} | {s["meanMs"]:.1f} / {s["p95Ms"]:.1f} |')
text += ['',
    'Luchador has a real fresh-context cost: ~394 ms mean versus E2B ~221 ms. This is another reason to keep E2B readily selectable. The existing focus prewarm path is outside this measurement; no claim is made about observed app UI latency.','',
    '## Serbian Latin: the useful next target','',
    'The weak slice is **midword completion**, where the confidence gate is intentionally bypassed. Luchador has 15/32 poor Serbian Latin midword suggestions here versus E2B 10/32. Stock IT has a similar weakness. Word-start calibration cannot repair these cases. [EXAMPLES.md](EXAMPLES.md) shows paired wins and losses; [examples.json](examples.json) also contains the exact concatenated text and judge reasons.','',
    'A code audit supplies a concrete hypothesis: `CotypingCoordinator+Prediction.swift` treats a fragment as a valid standalone word when the spelling-language gate cannot apply. `CotypingSpellChecker.swift` explicitly identifies unsupported Serbian/Croatian/Montenegrin dictionaries as that condition. This disables the preference for a token that extends the partial word. The fixtures held `wordPrefixIsValidWord=true` for every model; they did not run the live spelling/language classifier. The source establishes a path worth testing, not that it caused every bad sample. English midword results also bypass the live dictionary and are limited by that assumption.','',
    'A post-hoc diagnostic capped every midword suggestion to one word using the already collected blind ratings. Luchador utility **fell** 0.672→0.589; poor outputs fell only 24→22. E2B also lost utility. So a blanket one-word cap is not the next fix. See [posthoc-midword-cap.json](posthoc-midword-cap.json); this is a diagnostic on observed confirmation data, not a new validated variant.','',
    'Recommended next work: audit Serbian Latin partial-word conditioning and token healing on a new, frozen corpus; compare Luchador and E2B with realistic spelling-language verdicts and fixed deployable cutoffs. Have a native Serbian speaker rate the disagreement cases. Retain the hybrid and the E2B rollback; a language/model router is only a future hypothesis and its memory/switching latency has not been measured.','',
    '## Claude and uncertainty','',
    'Fresh blind Claude Opus 5.5 packets include only synthetic prefixes and anonymous full/one-word continuations. No future reference, model names, latency or product source is included in the authored packets. Sixteen cases repeat per split with reversed option order. Confirmation CLI calls additionally used safe mode to disable automatic repository/customization discovery; development used the existing no-tools/no-settings/no-session protocol. Requests, responses, model IDs and hashes are retained.','',
    'Repeat agreement: development 108/126 exact and 117/126 sign; confirmation 86/110 exact and 98/110 sign. Intervals use 5,000 paired bootstrap draws over 32 scenario clusters, grouping English/Serbian translations and nearby checkpoints together. They are conditional on this corpus, fitted policy and one judge; they do not include human variation, all training uncertainty or a multiple-comparison correction. No significant per-language superiority is claimed.','',
    'Claude separately reviewed the completed aggregates and agreed that the literal Luchador fallback condition is met, while its superiority over E2B is unresolved. Its advice is post-hoc interpretation, not an additional blind quality vote: [ADVICE.md](claude-interpretation/ADVICE.md). Its reference to “calibration beating the single gate” is interpreted here more precisely as the two calibrated decoder designs being compared. The long-context results above were completed after that advisory response.','',
    '## Implementation and validation','',
    '- Added opt-in confidence tracing, configurable hybrid thresholds and per-case replay cutoffs; retained the same model files, prompt, sampling and token budget.',
    '- Six pinned model files passed SHA-256 checks and native load/replay. Salamandra metadata matches 24 layers, width 2048 and vocabulary 256,000, resolving the quantizer card’s copied 7B prose at the architecture level. YugoGPT carries generic Mistral metadata; source attribution still relies on the pinned quantizer repository, not an upstream-weight equivalence proof.',
    f'- {calls:,} native benchmark calls, including {warm:,} warmups; {validation["primaryTimedCalls"]:,} primary timing calls and {validation["longTimedCalls"]} long-context timing calls. Zero replay errors and zero repeated primary-output changes.',
    f'- {len(parity_files)} native runs matched their traced counterfactual outputs. The instrumented build matched the immutable previous build on all 200 reference requests, including exact prompts, text and suppression.',
    '- Release build passed; 67 focused Swift tests passed, including native hybrid parity and new confidence invariants. All 61 Python tests and strict lint on changed Swift files passed. No local UI tests or PR CI changes.',
    '', 'Runtime: M4 Max, 48 GiB, macOS 27.0.1, AC power, libllama b11474. Binary SHA-256 `'+read('binary.json')['sha256']+'`. Base commit `'+read('binary.json')['head']+'`; experiment source snapshots and hashes preserve the uncommitted implementation used for the study.','',
    'Reproduction/evidence: [plan.json](plan.json), [calibration.json](calibration.json), [matched.json](matched.json), [models.json](models.json), [analysis.json](analysis.json), [long-analysis.json](long-analysis.json), [validation.json](validation.json). Every run retains input, raw output, stderr and a receipt. The model manifest contains pinned download URLs and hashes; temporary local paths may need updating for a future run.']
(ROOT/'REPORT.md').write_text('\n'.join(text)+'\n')
print(json.dumps({'report':str(ROOT/'REPORT.md'),'validation':validation},indent=2))
