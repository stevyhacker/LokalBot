import json,os,pathlib,subprocess,tempfile,time,hashlib
repo=pathlib.Path('/Users/0xmithrandir/.codex/worktrees/4d628f81-0a81-4922-926a-c8c47dc4dbec/LokalBot')
out=repo/'Benchmarks/Cotyping/results/2026-10-10-calibration'
source=out/'development-asis-1-baseline'
app=pathlib.Path('/private/tmp/lokalbot-model-study-20261010/benchmark-LokalBot.app/Contents/MacOS/LokalBot')
assert hashlib.sha256(app.read_bytes()).hexdigest()=='29a8cec1971d86b877dfa910f01b82fddd587a42e2532712b5841551e7612eeb'
model=json.loads((out/'models.json').read_text())[0]['path']
directory=out/'original-binary-parity';directory.mkdir()
with tempfile.TemporaryDirectory(prefix='lokalbot-calibration-parity-') as tmp:
    root=pathlib.Path(tmp);(root/'home').mkdir()
    env=dict(os.environ,CFFIXED_USER_HOME=str(root/'home'),LOKALBOT_STORAGE_ROOT=str(root/'storage'),LOKALBOT_DEFAULTS_SUITE='me.dotenv.LokalBot.'+root.name)
    with (directory/'observations.jsonl').open('w') as stdout,(directory/'stderr.log').open('w') as stderr:
        subprocess.run([str(app),'--cotyping-replay',str(source/'input.json'),'--model-path',model],env=env,stdout=stdout,stderr=stderr,check=True,timeout=600)
a=[json.loads(x) for x in (directory/'observations.jsonl').read_text().splitlines()]
b=[json.loads(x) for x in (source/'raw.jsonl').read_text().splitlines()]
assert len(a)==len(b)
diff=[{'old':x,'new':y} for x,y in zip(a,b) if any(x.get(k)!=y.get(k) for k in ['id','prompt','text','suppression'])]
(directory/'receipt.json').write_text(json.dumps({'requests':len(a),'differences':diff,'referenceBinarySHA256':hashlib.sha256(app.read_bytes()).hexdigest()},indent=2)+'\n')
assert not diff
print(json.dumps({'nativeReferenceParity':len(a),'differences':0}))
