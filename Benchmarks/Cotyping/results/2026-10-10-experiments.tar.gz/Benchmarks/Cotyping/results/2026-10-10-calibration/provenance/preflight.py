import hashlib,json,pathlib,struct,subprocess,sys
repo=pathlib.Path('/Users/0xmithrandir/.codex/worktrees/4d628f81-0a81-4922-926a-c8c47dc4dbec/LokalBot')
out=repo/'Benchmarks/Cotyping/results/2026-10-10-calibration'
temp=pathlib.Path('/private/tmp/lokalbot-calibration-20261010')
def sha(path):
    with open(path,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def metadata(path):
    with open(path,'rb') as f:
        def number(fmt):return struct.unpack('<'+fmt,f.read(struct.calcsize('<'+fmt)))[0]
        def string():return f.read(number('Q')).decode('utf-8')
        def value(kind,keep=True):
            if kind==8:return string()
            if kind==9:
                element,n=number('I'),number('Q')
                for _ in range(n):value(element,False)
                return {'arrayType':element,'count':n}
            return number({0:'B',1:'b',2:'H',3:'h',4:'I',5:'i',6:'f',7:'?',10:'Q',11:'q',12:'d'}[kind])
        assert f.read(4)==b'GGUF';version=number('I');tensors=number('Q');n=number('Q')
        data={'version':version,'tensorCount':tensors}
        for _ in range(n):
            key=string();kind=number('I');v=value(kind)
            data[key]=v
        return data
verified={};allmeta={}
for model in json.loads((out/'models.json').read_text()):
    p=pathlib.Path(model['path']);digest=sha(p)
    assert digest==model['sha256'] and p.stat().st_size==model['bytes'],model['id']
    verified[model['id']]=digest;meta=metadata(p);allmeta[model['id']]=meta
    arch=meta['general.architecture']
    print(json.dumps({'id':model['id'],'name':meta.get('general.name'),'architecture':arch,'blocks':meta.get(arch+'.block_count'),'embedding':meta.get(arch+'.embedding_length'),'vocabulary':meta.get('tokenizer.ggml.tokens'),'source':{k:v for k,v in meta.items() if k.startswith('general.base_model')}}),flush=True)
    if model['id']=='salamandra2':
        assert arch=='llama' and meta['llama.block_count']==24 and meta['llama.embedding_length']==2048
        assert meta['tokenizer.ggml.tokens']['count']==256000
(out/'verified-models.json').write_text(json.dumps(verified,indent=2)+'\n')
(out/'gguf-metadata.json').write_text(json.dumps(allmeta,indent=2,ensure_ascii=False)+'\n')
app=temp/'replay-LokalBot.app/Contents/MacOS/LokalBot'
(out/'binary.json').write_text(json.dumps({'path':str(app),'sha256':sha(app),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'libllama':'b11474','instrumented':True},indent=2)+'\n')
(out/'hardware.json').write_text(json.dumps({'chip':subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip(),'memoryBytes':int(subprocess.check_output(['sysctl','-n','hw.memsize'],text=True)),'os':subprocess.check_output(['sw_vers'],text=True),'power':subprocess.check_output(['pmset','-g','batt'],text=True)},indent=2)+'\n')
