import json,pathlib,csv,statistics,sys,collections
sys.path.insert(0,'Benchmarks/Cotyping');import model_study as s
p=s.DEFAULT_OUTPUT
names={'baseline':'Gemma 4 E2B + hybrid (installed)','lfm12':'LFM2.5 1.2B Base','qwen2':'Qwen3.5 2B Base','lfm26':'LFM2.5 2.6B Base','gemma4':'Gemma 4 E4B Base','luchador':'Gemma 4 E4B Luchador','baseline-current':'Gemma 4 E2B + original decoder'}
screen=s.read(p/'screen-analysis.json');confirmation=s.read(p/'confirmation-analysis.json');timing=s.read(p/'timing-supplement.json');best=s.read(p/'selection.json')['model'];plan=s.read(p/'plan.json')
# Export every anonymous-judge result, including silence and reference metrics.
all_export=[]
for split,analysis in [('screen',screen),('confirmation',confirmation)]:
 cases=s.read(p/f'judge-{split}/cases.json');scores=s.read(p/f'judge-{split}/scores.json')
 refs=s.read(p/f'{split}-references.json')
 for case in cases:
  all_export.append({'split':split,'id':case['id'],'phraseID':case['phraseID'],'category':case['category'],'kind':case['kind'],'prefix':case['prefix'],'options':{names[a]:{'text':text,**scores[case['id']][a]} for a,text in case['policies'].items()}})
s.write(p/'all-comparisons.json',all_export)
with (p/'all-comparisons.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['split','id','category','kind','typed_prefix','model','suggestion','utility','first_word','flags','reason'])
 for c in all_export:
  for name,o in c['options'].items():w.writerow([c['split'],c['id'],c['category'],c['kind'],c['prefix'],name,o['text'],o['utility'],o['first_word'],','.join(o['flags']),o['reason']])
# Select examples by a fixed hash within wins, losses and ties, not by prose appeal.
confirm_cases=[c for c in all_export if c['split']=='confirmation'];chosen=[]
for language in ['en','sr']:
 for sign in [1,-1,0]:
  candidates=[]
  for c in confirm_cases:
   if ('sr' if c['category'].startswith('sr_') else 'en')!=language:continue
   a=c['options'][names[best]];b=c['options'][names['baseline']];d=a['utility']-b['utility']
   if (d>0)-(d<0)==sign and a['text']!=b['text']:candidates.append(c)
  chosen.extend(sorted(candidates,key=lambda c:s.judge.digest('model-study-example:'+c['id']))[:2 if sign else 1])
def cell(v):return str(v).replace('|','\\|').replace('\n',' ↵ ')
def text_cell(v):return '`'+cell(v).replace('`','')+'`' if v else '*(silence)*'
lines=['# Five-model autocomplete evaluation — 10 October 2026','',
       'Measured on this Mac with the exact installed Release app. The five candidate models used the same hybrid decoder, completion prompt, six-token generation budget and four-word display limit. The installed Gemma 4 E2B model is the primary control; the original decoder is an additional control.','',
       '## Outcome','',
       f'**{names[best]} was selected by the frozen screening rule.** Its independent confirmation result is reported below. Model choice in the installed app remains Gemma 4 E2B with the experimental hybrid enabled. The PR and its CI were left alone.','',
       '## Main comparison: 320 checkpoints, 64 phrases','',
       'Useful means Claude utility > 0; poor means utility < 0 (worse than silence). Neutral suggestions and silence have utility 0. Utility ranges from −2 to +2 and is averaged over **all checkpoints**, including silence. This is model-rated usefulness, not a human acceptance rate.','',
       '| Model | Useful / 320 | Poor / 320 | Mean utility | Warm mean / p95 | Model file |',
       '|---|---:|---:|---:|---:|---:|']
for a in s.IDS:
 d=screen['arms'][a];q=d['overall'];t=d['latency'];lines.append(f'| {names[a]} | {q["useful"]} | {q["bad"]} | {q["meanUtility"]:.3f} | {t["meanMs"]:.1f} / {t["p95Ms"]:.1f} ms | {timing[a]["modelGB"]:.2f} GB |')
lines+=['','Each model ran three serial, reordered timing rounds (960 timed requests). Outputs were identical across repeats. Quality has 320 independent checkpoints grouped into 64 phrases, not 960 independent judgments. Ten warmup calls per process were excluded.','',
        '| Candidate vs installed hybrid | Utility delta, 95% phrase-bootstrap interval | Wins / ties / losses | Latency delta |',
        '|---|---:|---:|---:|']
for a in s.IDS[1:]:
 d=screen['comparison'][a];u=d['utilityDelta'];t=d['latencyDeltaMs'];lines.append(f'| {names[a]} | {u["mean"]:+.3f} [{u["low95"]:+.3f}, {u["high95"]:+.3f}] | {d["wins"]} / {d["ties"]} / {d["losses"]} | {t["mean"]:+.1f} ms |')
lines+=['','Screening intervals are exploratory, unadjusted for selecting among five candidates. The confirmation split below is the independent check.','',
        '## Independent confirmation: 160 checkpoints, 32 new phrases','',
        '| Model / decoder | Useful / 160 | Poor / 160 | Mean utility | Warm mean / p95 | First-word reference matches |',
        '|---|---:|---:|---:|---:|---:|']
for a in ['baseline-current','baseline',best]:
 d=confirmation['arms'][a];q=d['overall'];t=d['latency'];ref=d['reference']['overall'];lines.append(f'| {names[a]} | {q["useful"]} | {q["bad"]} | {q["meanUtility"]:.3f} | {t["meanMs"]:.1f} / {t["p95Ms"]:.1f} ms | {ref["correctFirstWord"]} |')
d=confirmation['comparison'][best];u=d['utilityDelta'];t=d['latencyDeltaMs']
lines+=['',f'Finalist versus installed hybrid: **{d["wins"]} wins, {d["ties"]} ties, {d["losses"]} losses**. Utility delta {u["mean"]:+.3f}, 95% interval [{u["low95"]:+.3f}, {u["high95"]:+.3f}]. Warm latency delta {t["mean"]:+.1f} ms, interval [{t["low95"]:+.1f}, {t["high95"]:+.1f}]. These intervals resample whole phrases (5,000 samples).','',
        '## Language matters','',
        '| Model | English useful / poor (240) | Serbian useful / poor (80) | English / Serbian mean utility |',
        '|---|---:|---:|---:|']
for a in s.IDS:
 d=screen['arms'][a]['language'];e=d['en'];r=d['sr'];lines.append(f'| {names[a]} | {e["useful"]} / {e["bad"]} | {r["useful"]} / {r["bad"]} | {e["meanUtility"]:.3f} / {r["meanUtility"]:.3f} |')
lines+=['','Serbian is evenly split between Latin and Cyrillic scripts. Detailed script, category and partial-word breakdowns are in the analysis JSON.','',
        '## Longer documents change the latency ranking','',
        'The same 32 synthetic checkpoints were also run with roughly 1,930–2,317 characters of preceding text. This is a separate latency stress test, not quality-selection data. Two repeat rounds were added after the first pass showed a ranking reversal.','',
        '| Model | Long-context mean / p95 | Short-prefix mean | Peak process RSS |',
        '|---|---:|---:|---:|']
long_results={}
for a in s.IDS:
 runs=[s.rows(p/f'long-context-{i}-{a}/observations.jsonl') for i in [1,2,3]];ts=[r['latencyMs'] for run in runs for r in run]
 long_results[a]={'meanMs':statistics.mean(ts),'p95Ms':s.percentile(ts,.95),'roundMeansMs':[statistics.mean(r['latencyMs'] for r in run) for run in runs],'n':len(ts),'uniqueCases':32}
 lines.append(f'| {names[a]} | {statistics.mean(ts):.1f} / {s.percentile(ts,.95):.1f} ms | {screen["arms"][a]["latency"]["meanMs"]:.1f} ms | {timing[a]["maxRSSGiB"]:.2f} GiB |')
s.write(p/'long-context-analysis.json',long_results)
lines+=['','LokalBot preserves shared prompt KV for attention models, but fully reprocesses prefixes for recurrent/hybrid models. The measured reversal is consistent with that implementation; this study did not isolate every source of latency. RSS is peak process resident memory from `/usr/bin/time -l`, not total system or incremental GPU memory.','',
        '## Examples you can rate yourself','',
        'These are held-out examples selected by fixed hash within English/Serbian wins, losses and ties. The displayed continuation is appended directly at the caret; a short suffix can finish a partially typed word. Scores are Claude’s judgments, not reference-match scores.','',
        f'| Typed text before caret | Installed Gemma + hybrid | {names[best]} | Claude utility: installed → candidate |',
        '|---|---|---|---:|']
for c in chosen:
 a=c['options'][names[best]];b=c['options'][names['baseline']];lines.append(f'| {text_cell(c["prefix"]+"▏")} | {text_cell(b["text"])} | {text_cell(a["text"])} | {b["utility"]} → {a["utility"]} |')
lines+=['','Every result, including failures and neutral suggestions, is in [all-comparisons.csv](all-comparisons.csv) and [all-comparisons.json](all-comparisons.json).','',
        '## Judge reliability and limits','']
for title,a in [('Screen',screen),('Confirmation',confirmation)]:
 r=a['reliability'];lines.append(f'- {title}: exact score agreement on {r["exactAgreement"]}/{r["options"]} repeated anonymous options; positive/neutral/negative agreement on {r["signAgreement"]}/{r["options"]}. The numeric ratings disagreed with the supplied preference list in {a["preferenceDisagreements"]} cases; analysis uses the validated numeric ratings consistently.')
lines+=['',
        '- Actual judge model IDs are recorded in every batch receipt; the study requested Claude Opus 5.5. The judge saw only synthetic typed prefixes and anonymous actual continuations. Identical suggestions were deduplicated within a case. No reference futures, model labels, latency, source code or personal writing entered the judge packets.',
        '- All phrases were written by the implementing assistant, so this is a small synthetic evaluation with one model judge. Repeated ratings measure only some judge variability. It does not establish human acceptance, daily typing savings, battery life or generalization to every app.',
        '- The inherited confidence gates (.1 primary, .31 fallback) and six-token budget are fixed across tokenizers. This is a deployable replacement test, not each model’s maximum possible quality. Reference mismatch can still be a useful suggestion. A token budget is not an equal word budget across models.',
        '- Warm latency includes token healing, native generation, confidence filtering and normalization. It excludes model load, keyboard capture, debounce and overlay rendering. The original decoder can publish earlier streamed text; these measurements compare final normalized requests, not first-visible UI latency. Normal desktop background activity was present.',
        '- Q6_K files use different quantizers/calibration data; the weights and exact hashes, rather than an abstract model family, are what were tested. Luchador differs from E4B base in instruction tuning, writing adaptations and quantization. A gain cannot be attributed solely to a particular LoRA technique.',
        '- The short-suggestion sensitivity analysis zeros positive benefit for suggestions of three or fewer visible characters. It is deliberately conservative for partial-word completions; see the analysis JSON.',
        '',
        '## Reproducibility and validation','',
        f'- Runtime executable SHA-256: `{plan["appSHA256"]}`. This is a copy of the installed Release binary from application source commit `{plan["runtimeAmendment"]["installedSourceCommit"]}`; the later PR commit changed UI test code only.',
        '- Hardware: Apple M4 Max, 48 GiB memory, macOS 27.0.1; AC power. Exact environment and fixed settings are in [plan.json](plan.json). Model revisions, byte sizes and SHA-256 hashes are in [models.json](models.json).',
        '- Every production replay validates request IDs, complete output, errors, native hybrid flags, unchanged prompt bytes across models, and exact repeated outputs. All model downloads matched the published whole-file hashes. Frozen case and script hashes were checked again.',
        '- The prototype compatibility/pilot runs are preserved under `provenance/` and excluded from all reported timings and model selection. Main results were restarted with the exact installed binary. The two complete pilot outputs matched the corresponding installed-runtime outputs.',
        '- Five existing judge-validator tests passed. Independent harness checks covered partial-word character credit, alternative continuations, silence, phrase clustering and absence of future-reference fields in native/judge inputs. Python compilation and whitespace checks passed. No local UI tests were run.',
        '- Primary raw data: `screen-<round>-<model>/`; independent confirmation: `confirmation-<round>-<model>/`; longer-context checks: `long-context-<round>-<model>/`. Each contains inputs, JSONL observations, diagnostic logs and receipts. Judge packets, raw responses, validated ratings and blind repeats are preserved in `judge-screen/` and `judge-confirmation/`.',
        '- Evaluation code: [model_study.py](../../model_study.py); frozen corpus: [model-study-corpus.json](model-study-corpus.json). The harness intentionally pins a local archived executable and exact model hashes. To reproduce on another machine, supply those pinned artifacts and record any runtime substitution as a different experiment.',
        '',
        'Research sources, candidate rationale and excluded fine-tunes: [RESEARCH.md](RESEARCH.md).',
        '']
(p/'REPORT.md').write_text('\n'.join(lines))
print('Report and complete comparison exports written.')
