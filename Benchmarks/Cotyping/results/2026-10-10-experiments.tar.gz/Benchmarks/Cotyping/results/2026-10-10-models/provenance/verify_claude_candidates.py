"""Archive public model metadata; never download or execute model weights."""

import concurrent.futures
import datetime
import hashlib
import json
import pathlib
import sys
import urllib.parse
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = ROOT / "claude-model-selection" / "sources"
OUT.mkdir(exist_ok=True)
BASES = [
    "google/gemma-4-E4B-it", "Qwen/Qwen3-4B-Base",
    "BSC-LT/salamandra-2b", "gordicaleksa/YugoGPT",
]


def fetch(url, path):
    with urllib.request.urlopen(url, timeout=45) as response:
        data = response.read()
    path.write_bytes(data)
    receipt = {
        "url": url, "file": path.name, "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "atUTC": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    }
    return data, receipt


def base(repo):
    stem = repo.replace("/", "--")
    raw, receipt = fetch(f"https://huggingface.co/api/models/{repo}?blobs=true", OUT / f"{stem}.json")
    metadata = json.loads(raw)
    receipts = [receipt]
    for filename in ["README.md", "config.json"]:
        _, receipt = fetch(
            f"https://huggingface.co/{repo}/raw/{metadata['sha']}/{filename}",
            OUT / f"{stem}--{filename}",
        )
        receipts.append(receipt)
    card = metadata.get("cardData", {})
    return {
        "repo": repo, "revision": metadata["sha"], "gated": metadata.get("gated"),
        "license": card.get("license"), "languages": card.get("language"),
        "receipts": receipts,
    }


def search(query):
    url = "https://huggingface.co/api/models?" + urllib.parse.urlencode({"search": query, "limit": 100})
    raw, receipt = fetch(url, OUT / ("search--" + query + ".json"))
    entries = json.loads(raw)
    return {"query": query, "repos": [entry["id"] for entry in entries], "receipts": [receipt]}


def quant(repo):
    stem = repo.replace("/", "--")
    raw, receipt = fetch(f"https://huggingface.co/api/models/{repo}?blobs=true", OUT / f"{stem}.json")
    metadata = json.loads(raw)
    _, card_receipt = fetch(
        f"https://huggingface.co/{repo}/raw/{metadata['sha']}/README.md",
        OUT / f"{stem}--README.md",
    )
    return {
        "repo": repo, "revision": metadata["sha"], "gated": metadata.get("gated"),
        "declaredBase": metadata.get("cardData", {}).get("base_model"),
        "q6Files": [item for item in metadata["siblings"] if "q6_k" in item["rfilename"].lower()],
        "receipts": [receipt, card_receipt],
    }


if __name__ == "__main__":
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        if "--quants" in sys.argv:
            futures = [pool.submit(quant, repo) for repo in [
                "bartowski/google_gemma-4-E4B-it-GGUF",
                "mradermacher/Qwen3-4B-Base-i1-GGUF",
                "RichardErkhov/BSC-LT_-_salamandra-2b-gguf",
                "mradermacher/YugoGPT-i1-GGUF",
            ]]
            name = "quant-summary.json"
        else:
            futures = [pool.submit(base, repo) for repo in BASES]
            futures += [pool.submit(search, query) for query in ["Qwen3-4B-Base", "YugoGPT", "salamandra-2b", "gemma-4-E4B-it-GGUF"]]
            name = "metadata-summary.json"
        results = [future.result() for future in futures]
    (OUT / name).write_text(json.dumps(results, indent=2) + "\n")
    for result in results:
        summary = {key: value for key, value in result.items() if key != "receipts"}
        if "repos" in summary:
            summary["repos"] = [repo for repo in summary["repos"] if "gguf" in repo.lower()]
        print(json.dumps(summary))
