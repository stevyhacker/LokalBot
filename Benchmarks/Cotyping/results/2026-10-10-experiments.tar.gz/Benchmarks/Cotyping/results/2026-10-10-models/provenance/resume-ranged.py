import concurrent.futures,hashlib,json,os,pathlib,signal,subprocess,time
root=pathlib.Path('/private/tmp/lokalbot-model-study-20261010'); manifest=json.loads((root/'model-manifest.json').read_text()); ids=['lfm26','luchador']
pattern='^curl --fail --location --silent --show-error --retry 3 --continue-at - --output /private/tmp/lokalbot-model-study-20261010/models/'
p=subprocess.run(['pgrep','-f',pattern],capture_output=True,text=True)
for pid in p.stdout.split(): os.kill(int(pid),signal.SIGTERM)
time.sleep(1)
def run(m):
 start=time.monotonic(); dest=pathlib.Path(m['path']); part=dest.with_suffix('.part')
 if dest.exists(): return
 offset=part.stat().st_size if part.exists() else 0
 chunk_size=128*1024*1024
 chunks=[(i,a,min(a+chunk_size,m['bytes'])-1) for i,a in enumerate(range(offset,m['bytes'],chunk_size))]
 pieces=root/('chunks-'+m['id']);pieces.mkdir(exist_ok=True)
 print(json.dumps({'resume':m['id'],'prefixBytes':offset,'chunks':len(chunks)}),flush=True)
 def fetch(spec):
  i,a,b=spec; out=pieces/f'{i:04}.bin'
  if out.exists() and out.stat().st_size == b-a+1: return i
  p=subprocess.run(['curl','--http1.1','--fail','--location','--silent','--show-error','--retry','5','--retry-all-errors','--max-time','240','--range',f'{a}-{b}','--output',str(out),m['url']],capture_output=True,text=True)
  if p.returncode or out.stat().st_size!=b-a+1: raise RuntimeError((m['id'],i,p.returncode,out.stat().st_size,p.stderr))
  return i
 with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
  for i in pool.map(fetch,chunks):print(json.dumps({'chunk':m['id'],'index':i}),flush=True)
 with part.open('ab') as target:
  for i,a,b in chunks:
   src=pieces/f'{i:04}.bin'
   with src.open('rb') as f:
    while block:=f.read(16*1024*1024):target.write(block)
   src.unlink()
 assert part.stat().st_size==m['bytes']
 with part.open('rb') as f: sha=hashlib.file_digest(f,'sha256').hexdigest()
 assert sha==m['sha256'],(m['id'],sha)
 part.rename(dest)
 receipt={'id':m['id'],'sha256':sha,'verified':True,'downloadMethod':'resumed prefix plus HTTP byte ranges; final complete file hash verified','resumeSeconds':time.monotonic()-start}
 (dest.parent/(m['id']+'-receipt.json')).write_text(json.dumps(receipt,indent=2))
 print(json.dumps(receipt),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,[m for m in manifest if m['id'] in ids]))
