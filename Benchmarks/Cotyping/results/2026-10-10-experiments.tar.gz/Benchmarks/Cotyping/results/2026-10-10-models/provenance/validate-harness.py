import sys
sys.path.insert(0,'Benchmarks/Cotyping')
import model_study as s
refs={'p:0':{'phraseID':'p','category':'technical','language':'en','kind':'midword','typed':'comm','words':['commit','the','fix'],'matchingCharacterCredits':[2,6,10]}}
rows=[{'id':'p:0','text':'it the fix','latencyMs':10}]
r=s.metrics(rows,refs)['overall'];assert (r['correctFirstWord'],r['matchingCharacters'],r['shown'])==(1,10,1)
rows[0]['text']='ent on this';r=s.metrics(rows,refs)['overall'];assert (r['correctFirstWord'],r['matchingCharacters'],r['shown'])==(0,0,1)
rows[0]['text']='';r=s.metrics(rows,refs)['overall'];assert (r['correctFirstWord'],r['matchingCharacters'],r['shown'])==(0,0,0)
b=s.bootstrap([1]*5+[-1]*5,['a']*5+['b']*5,1000);assert b['phrases']==2 and b['mean']==0 and b['low95']==-1 and b['high95']==1
print('PASS: partial-word reference scoring, alternative continuation, silence, and phrase clustering')
