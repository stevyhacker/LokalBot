import concurrent.futures,hashlib,json,pathlib,subprocess,time
root=pathlib.Path('/private/tmp/lokalbot-model-study-20261010'); models=root/'models'; models.mkdir(exist_ok=True)
picks=[('lfm12','LiquidAI/LFM2.5-1.2B-Base-GGUF','LFM2.5-1.2B-Base-Q6_K.gguf'),('qwen2','mradermacher/Qwen3.5-2B-Base-i1-GGUF','Qwen3.5-2B-Base.i1-Q6_K.gguf'),('lfm26','mradermacher/LFM2.5-2.6B-Base-i1-GGUF','LFM2.5-2.6B-Base.i1-Q6_K.gguf'),('gemma4','mradermacher/gemma-4-E4B-i1-GGUF','gemma-4-E4B.i1-Q6_K.gguf'),('luchador','bartowski/rpDungeon_Gemma-4-E4B-Luchador-GGUF','rpDungeon_Gemma-4-E4B-Luchador-Q6_K.gguf')]
manifest=[]
for name,repo,filename in picks:
 meta=json.loads((root/'research'/(repo.replace('/','__')+'.json')).read_text()); f=next(f for f in meta['siblings'] if f['rfilename']==filename)
 manifest.append({'id':name,'repo':repo,'revision':meta['sha'],'file':filename,'path':str(models/filename),'sha256':f['lfs']['sha256'],'bytes':f['size'],'license':meta['cardData'].get('license'),'url':f'https://huggingface.co/{repo}/resolve/{meta["sha"]}/{filename}'})
(root/'model-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
def download(m):
 start=time.monotonic(); p=pathlib.Path(m['path']); part=p.with_suffix('.part')
 if not p.exists():
  subprocess.run(['curl','--fail','--location','--silent','--show-error','--retry','3','--continue-at','-','--output',str(part),m['url']],check=True)
  part.rename(p)
 with p.open('rb') as f: sha=hashlib.file_digest(f,'sha256').hexdigest()
 assert sha==m['sha256'] and p.stat().st_size==m['bytes'],m['id']
 receipt={'id':m['id'],'sha256':sha,'seconds':time.monotonic()-start,'verified':True}
 (models/(m['id']+'-receipt.json')).write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(download,manifest))
