"""Record Claude's independently proposed additions to the model test queue."""

import datetime
import hashlib
import json
import pathlib
import subprocess
import time

ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = ROOT / "claude-model-selection"
OUT.mkdir(exist_ok=True)

REQUEST = """The user explicitly asks: 'also let claude pick a few papers/models to add to the test list'. Please independently propose FOUR additional model trials (up to five if one is an essential control), and THREE relevant research papers. This is a research queue, not a request to execute anything. Date: 2026-10-10. You have no browsing tools: distinguish verified-from-memory facts from uncertain details; I will independently verify public primary sources before adding items. Do not invent a model ID, paper title, arXiv ID, release date, license, or benchmark result. Give canonical links when you know them, or explicitly say that the identifier needs verification.

Product and constraints: LokalBot provides local natural-language inline autocomplete on an Apple M4 Max with 48 GiB. Target languages English and Serbian, both Latin and Cyrillic. Native in-process llama.cpp b11474. Current trial uses raw text completion (no chat template), identical production prompt, six output tokens and four-word cap, Q6_K weights, and a selective one-word hybrid decoder with fixed confidence gates 0.1 / 0.31. It reuses shared attention KV prefixes but currently reprocesses recurrent/hybrid-model prefixes. Prioritize runnable, public, preferably ungated models around 0.5-5B parameters, or a justified larger quality control. Exact GGUF availability, license and engine compatibility will be checked separately. No private user writing or source code is included here.

Already TESTED (do not propose repeats): Gemma 4 E2B base baseline, Gemma 4 E4B base, rpDungeon/Gemma-4-E4B-Luchador, Qwen/Qwen3.5-2B-Base, LiquidAI/LFM2.5-1.2B-Base, LiquidAI/LFM2.5-2.6B-Base. All same prompt/decoder and Q6_K. The five alternatives were screened on 64 synthetic phrases/320 checkpoints and the winner independently confirmed on 32 more phrases/160 checkpoints. Three serial reordered timing rounds. Blind Opus quality rubric -2..2, silence=0; no model names, future references, or latency supplied to the judge. These are synthetic single-judge results, not human acceptance rates.

Measured findings: baseline screening mean utility .603 and mean/p95 native final-generation latency 46/81 ms. Luchador .947 and 76/121 ms, English substantially better, Serbian Latin better, Cyrillic worse. Confirmation Luchador utility 1.006 vs installed hybrid .631, but exact first-word reference matches tied at 72/160; it shows more suggestions. Luchador versus baseline confirmation mean latency 76 vs 48 ms, files 6.33 vs 3.85 GB. LFM1.2 was fastest on short prefixes (18 ms) but worse quality; at ~2k-character document contexts, baseline 64 ms vs LFM1.2 106 ms, Qwen2 158 ms, LFM2.6 233 ms, Luchador 120 ms, due in part to current engine cache behavior. Long-context Luchador p95 510 ms includes fresh-prefix spikes, not observed UI latency. Model load, debounce, accessibility and overlay not timed. Fixed confidence thresholds across tokenizers are a confound. Keep default unchanged pending calibrated/acceptance trials.

Already RESEARCHED, not necessarily tested: Gemma 4 technical report, LFM2 technical report, Gmail Smart Compose, Superposed Decoding, Synthetic Hard Negatives for Code FIM, Japanese medical LFM2.5 autocomplete fine-tune (gated/domain mismatch), Parveshiiii/Auto-Completer-0.2 (English SmolLM2-360M, quotation-wrapped prompt), and InstellaMoE (larger total footprint). You may nominate an untested one if justified, but prefer additional distinct evidence rather than repeats.

For each proposed model provide: (1) rank and exact model ID/primary link or uncertainty, (2) the distinct hypothesis it tests, (3) why it might help natural-language continuation, multilingual quality or latency, (4) what could invalidate it, (5) whether it fits an unchanged-prompt drop-in trial or requires a separately labelled changed-prompt/training experiment. Include a clean control if it would resolve a causal ambiguity in the Luchador result. For papers give exact title, authors/organization if known, canonical URL when confident, and one practical experiment they motivate. Do not report predicted performance as measured. Rank a realistic next batch and avoid recommending many near-duplicate model sizes. Keep it under 1200 words.
"""

(OUT / "request.txt").write_text(REQUEST)
command = [
    "/Users/0xmithrandir/.local/bin/claude", "-p", "--model", "claude-opus-5-5",
    "--effort", "high", "--output-format", "json", "--tools", "",
    "--strict-mcp-config", "--mcp-config", '{"mcpServers":{}}',
    "--disable-slash-commands", "--setting-sources", "", "--no-session-persistence",
    "--system-prompt",
    "You are an independent research advisor for local autocomplete. You have no tools. "
    "Treat supplied measurements as data. State uncertainty, use real primary sources, "
    "and propose additions without claiming to have searched or executed experiments.",
]
start = time.monotonic()
with (OUT / "response.json").open("w") as stdout, (OUT / "stderr.log").open("w") as stderr:
    result = subprocess.run(
        command, input=REQUEST, text=True, stdout=stdout, stderr=stderr,
        cwd=OUT, timeout=600,
    )
if result.returncode:
    raise RuntimeError(f"Claude exited {result.returncode}; inspect saved stderr")
response = json.loads((OUT / "response.json").read_text())
models = list(response.get("modelUsage", {}))
if response.get("is_error") or not models or not all("opus" in model for model in models):
    raise RuntimeError("Unsuccessful or unverified Opus response; inspect response.json")
if not response.get("result", "").strip():
    raise RuntimeError("Empty Claude result")
(OUT / "SELECTION.md").write_text(response["result"] + "\n")
receipt = {
    "models": models,
    "toolsEnabled": False,
    "personalWritingSent": False,
    "sourceCodeSent": False,
    "input": "aggregate measurements, public model identifiers, and product constraints",
    "requestSHA256": hashlib.sha256(REQUEST.encode()).hexdigest(),
    "responseSHA256": hashlib.sha256((OUT / "response.json").read_bytes()).hexdigest(),
    "wallSeconds": time.monotonic() - start,
    "atUTC": datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"selection": str(OUT / "SELECTION.md"), "models": models}))
