import sys,pathlib,statistics,collections
sys.path.insert(0,'Benchmarks/Cotyping');import model_study as s
p=s.DEFAULT_OUTPUT;case_groups={}
for split in ['screen','confirmation']:
 cases=s.read(p/f'judge-{split}/cases.json');scores=s.read(p/f'judge-{split}/scores.json');refs=s.read(p/f'{split}-references.json')
 policies={'baseline':['baseline']*len(cases),'luchador':['luchador']*len(cases),'language_choice':['baseline' if c['language']=='sr' else 'luchador' for c in cases]}
 result={'n':len(cases),'policy':'Known-language model choice: English Luchador, Serbian installed Gemma hybrid. Not an implemented router.','arms':{}}
 for name,choices in policies.items():
  chosen=[scores[c['id']][a] for c,a in zip(cases,choices)];values=[r['utility'] for r in chosen]
  deltas=[v-scores[c['id']]['baseline']['utility'] for v,c in zip(values,cases)]
  d={'meanUtility':statistics.mean(values),'useful':sum(v>0 for v in values),'poor':sum(v<0 for v in values),'deltaVsInstalled':s.bootstrap(deltas,[c['phraseID'] for c in cases]),'wins':sum(v>0 for v in deltas),'ties':sum(v==0 for v in deltas),'losses':sum(v<0 for v in deltas),'flags':dict(collections.Counter(flag for r in chosen for flag in r['flags']))}
  d['languages']={}
  for lang in ['en','sr']:
   selected=[(c,r) for c,r in zip(cases,chosen) if c['language']==lang]
   d['languages'][lang]={'n':len(selected),'useful':sum(r['utility']>0 for c,r in selected),'poor':sum(r['utility']<0 for c,r in selected),'meanUtility':statistics.mean(r['utility'] for c,r in selected),'deltaVsInstalled':s.bootstrap([r['utility']-scores[c['id']]['baseline']['utility'] for c,r in selected],[c['phraseID'] for c,r in selected])}
  result['arms'][name]=d
 # Pairwise comparison also includes the original decoder, not only installed hybrid.
 result['finalistVsOriginal']=s.bootstrap([scores[c['id']]['luchador']['utility']-scores[c['id']]['baseline-current']['utility'] for c in cases],[c['phraseID'] for c in cases])
 case_groups[split]=result
s.write(p/'language-policy-analysis.json',case_groups)
print(case_groups['confirmation'])
