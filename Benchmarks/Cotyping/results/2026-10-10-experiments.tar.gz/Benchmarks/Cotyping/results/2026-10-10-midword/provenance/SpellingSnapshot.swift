import AppKit
import Foundation
@main struct SpellingSnapshot {
    @MainActor static func main() throws {
        let input = URL(fileURLWithPath: CommandLine.arguments[1])
        var fixture = try JSONSerialization.jsonObject(with: Data(contentsOf: input)) as! [String: Any]
        var cases = fixture["cases"] as! [[String: Any]]
        let checker = CotypingSpellChecker()
        for index in cases.indices {
            let prefix = cases[index]["prefix"] as! String
            cases[index]["wordPrefixIsValidWord"] = checker.wordPrefixIsValidWord(context: prefix)
            cases[index]["nativeSpellVerdictsApply"] = checker.verdictsApply(context: prefix)
        }
        fixture["cases"] = cases
        fixture["availableSpellingLanguages"] = NSSpellChecker.shared.availableLanguages.sorted()
        try JSONSerialization.data(withJSONObject: fixture, options: [.prettyPrinted, .sortedKeys]).write(
            to: URL(fileURLWithPath: CommandLine.arguments[2]))
    }
}
