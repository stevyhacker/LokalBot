# Diagnostic examples did not generalize

The old Serbian examples in `probe-*-input.json` improved under atomic healing, but the independent fresh evaluation rejected that approach. See [the full result](REPORT.md). Raw fresh paired outputs and all Claude ratings are retained in [the judge case mapping](judge-fresh/cases.json) and [scores](judge-fresh/scores.json). Do not select examples as evidence of an overall gain.
