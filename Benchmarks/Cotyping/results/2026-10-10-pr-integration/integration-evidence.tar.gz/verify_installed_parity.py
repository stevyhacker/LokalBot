from pathlib import Path
import hashlib,json,os,statistics,subprocess,tempfile,time
from datetime import datetime,timezone
root=Path('/Users/0xmithrandir/.codex/worktrees/4d628f81-0a81-4922-926a-c8c47dc4dbec/LokalBot')
source=root/'Benchmarks/Cotyping/results/2026-10-10-prefix-search'
output=Path('/private/tmp/lokalbot-pr230-update/parity');output.mkdir(exist_ok=False)
installed=Path('/Applications/LokalBot.app/Contents/MacOS/LokalBot')
previous=Path('/private/tmp/lokalbot-pr230-update/before-LokalBot.app/Contents/MacOS/LokalBot')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def rows(p):return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
models={m['id']:m for m in read(source/'models.json')}
summary=dict(createdAtUTC=datetime.now(timezone.utc).isoformat(),installedBinarySHA256=sha(installed),
 previousInstalledBinarySHA256=sha(previous),sourceStudyBinarySHA256=read(source/'binary.json')['sha256'],
 purpose='Integration parity, not a new quality sample or latency benchmark.',arms={})
write(output/'plan.json',summary)
def run(name,binary,fixture,model):
 directory=output/name;directory.mkdir();write(directory/'input.json',fixture)
 start=time.monotonic()
 with tempfile.TemporaryDirectory(prefix='lokalbot-pr230-parity-') as temp:
  d=Path(temp);(d/'home').mkdir()
  env=dict(os.environ,CFFIXED_USER_HOME=str(d/'home'),LOKALBOT_STORAGE_ROOT=str(d/'library'),LOKALBOT_DEFAULTS_SUITE='me.dotenv.LokalBot.'+d.name)
  with (directory/'raw.jsonl').open('w') as stdout,(directory/'stderr.log').open('w') as stderr:
   subprocess.run([str(binary),'--cotyping-replay',str(directory/'input.json'),'--model-path',model['path']],env=env,stdout=stdout,stderr=stderr,check=True,timeout=600)
 observed=rows(directory/'raw.jsonl');assert len(observed)==len(fixture['cases'])
 assert not any(row.get('error') for row in observed)
 write(directory/'receipt.json',dict(complete=True,binarySHA256=sha(binary),modelSHA256=model['sha256'],inputSHA256=sha(directory/'input.json'),rawSHA256=sha(directory/'raw.jsonl'),wallSeconds=time.monotonic()-start))
 return observed
for arm in ['baseline-control','baseline-fixed','luchador-control','luchador-fixed']:
 reference=source/f'fresh-matched-1-{arm}'
 fixture=read(reference/'input.json');observed=run(arm,installed,fixture,models[arm.split('-')[0]])
 expected=rows(reference/'raw.jsonl')
 differences=[dict(id=a['id'],expected=b,actual=a) for a,b in zip(observed,expected) if any(a.get(k)!=b.get(k) for k in ['id','prompt','text','suppression','error'])]
 write(output/arm/'differences.json',differences)
 assert not differences,(arm,len(differences))
 summary['arms'][arm]=dict(requests=len(observed)-8,warmups=8,differences=0,shown=sum(bool(r['text']) for r in observed[8:]))
 print(json.dumps(dict(completed=arm,**summary['arms'][arm])),flush=True)
fixture=read(source/'fresh-matched-1-baseline-control/input.json')
fixture={k:v for k,v in fixture.items() if k in ['cases','maxWords','maxTokens','temperature','repeatPenalty','appContext']}
fixture['selectiveOneWordHybrid']=False
for case in fixture['cases']:
 case.pop('firstWordThreshold',None);case.pop('hybridFallbackThreshold',None)
before=run('rollback-before',previous,fixture,models['baseline'])
after=run('rollback-after',installed,fixture,models['baseline'])
differences=[dict(id=a['id'],expected=b,actual=a) for a,b in zip(after,before) if any(a.get(k)!=b.get(k) for k in ['id','prompt','text','suppression','error'])]
write(output/'rollback-differences.json',differences);assert not differences,len(differences)
summary['rollback']=dict(requests=len(after)-8,warmups=8,differences=0,shown=sum(bool(r['text']) for r in after[8:]),
 setting='selectiveOneWordHybrid=false; no explicit healing override; ordinary confidence defaults')
summary['completedAtUTC']=datetime.now(timezone.utc).isoformat();write(output/'summary.json',summary)
print(json.dumps(summary,indent=2),flush=True)
