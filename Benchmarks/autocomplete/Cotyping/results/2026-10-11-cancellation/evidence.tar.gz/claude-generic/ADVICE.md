# Two-Stage Prefill for Cooperative Cancellation

## Established principles

- **Cancellation only happens at boundaries.** Once a prefill kernel sequence is enqueued, the host can't stop it. Cancellation latency is bounded by the longest uninterrupted GPU work unit plus any queued work.
- **Small chunks cost efficiency.** Per-chunk overhead (kernel launches, host round-trips, KV-cache bookkeeping) is roughly fixed. Large matmuls use the GPU better than small ones. Very small chunks therefore tend to lower prefill throughput.
- **Logits are needed only at the last position.** Intermediate chunks just populate the KV cache. Computing full-vocabulary logits for every token wastes compute and memory.

## The two-stage idea (hypothesis)

A small first chunk gives an early cancellation checkpoint and early progress reporting. The large remainder then runs at near-full efficiency. Whether this helps depends on where cancellations actually arrive:

- If users cancel mostly within the first few hundred milliseconds, it may help.
- If cancellations arrive uniformly, the large remainder dominates worst-case latency, and the benefit is small.

**Fixed small chunks** give bounded, predictable cancellation latency at a throughput cost proportional to the per-chunk overhead.

**Final-boundary-only logits** are orthogonal and should apply under any chunking scheme.

## Correctness hazards

- **Position and offset errors:** wrong position IDs or RoPE offsets, or wrong KV-cache write offsets at the chunk seam.
- **Masking:** the causal mask must cover all prior cached tokens in the second chunk.
- **Logit indexing:** sampling from the wrong row, such as the last row of the first chunk.
- **Partial state after cancellation:** a half-written KV cache must be invalidated or truncated before reuse, especially with prefix caching.
- **Numerical drift:** different chunk shapes can change reduction order. Expect tiny numeric differences rather than bitwise equality with unchunked prefill.

## GPU synchronization pitfalls

- **Non-blocking cancellation checks:** checking a cancel flag between chunks must not force a device sync. A blocking read of logits or loss values serializes the pipeline and can erase any throughput gain.
- **Asynchronous queues:** if work is enqueued asynchronously, "cancelled" may still leave queued kernels running. The real latency is the remaining queue depth, not the chunk size.
- **Buffer reuse:** freeing or reusing buffers on cancellation while kernels still reference them is a hazard. Wait on a fence or event first.

## Measurements needed before adopting

1. Prefill throughput (tokens/s) and time-to-first-token across prompt lengths, for each strategy.
2. Cancellation latency distribution (p50 and p99), from request to GPU idle and resources freed.
3. Sensitivity to the first-chunk size.
4. Output equivalence against unchunked prefill, within tolerance, plus tests that cancel at each boundary.
5. Behavior under concurrent requests, where chunk interleaving interacts with scheduling.
6. Profiler traces to confirm there are no hidden syncs between chunks.

Adopt only if the measurements show acceptable throughput loss and a real latency gain for your workload.
