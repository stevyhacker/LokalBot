from pathlib import Path
from datetime import datetime, timezone
import cancellation_experiment as c

root=Path(__file__).resolve().parent
model=Path('/Users/0xmithrandir/Library/Application Support/me.dotenv.LokalBot/models/gemma-4-E2B.i1-Q6_K.gguf')
c.ARMS.update(batch4={'nativeBatchThreads':4},batch8={'nativeBatchThreads':8})
c.write(root/'thread-amendment.json',dict(frozenAtUTC=datetime.now(timezone.utc).isoformat(),
    reason='Close the gap between two and fourteen prefill CPU threads before touching holdout outputs.',
    arms={k:c.ARMS[k] for k in ['default','batch4','batch8']},order=['default','batch4','batch8','default'],
    unchanged='Same adaptive-phase binary, frozen screen inputs including 60-ms cancellations; production unchanged.'))
for arm,round_number in [('default',3),('batch4',1),('batch8',1),('default',4)]:
    for dataset in ['fresh','long','cancellation']:
        c.run(root,model,'screen',arm,round_number,dataset)
