from pathlib import Path
import hashlib,json,shutil
from datetime import datetime,timezone

repo=Path('/Users/0xmithrandir/.codex/worktrees/experimental-autocomplete-hybrid/LokalBot')
root=Path('/private/tmp/lokalbot-cancellation-20261011');out=root/'adaptive';out.mkdir()
runner=(root/'cancellation_experiment.py').read_text()
anchor="    'default': {},\n"
new="""    'early128': {'nativePrefillChunkSize': 2048, 'nativePrefillFirstChunkSize': 128,
                 'nativeFinalPrefillLogitsOnly': True},
    'early128sync': {'nativePrefillChunkSize': 2048, 'nativePrefillFirstChunkSize': 128,
                     'nativeFinalPrefillLogitsOnly': True, 'nativeSynchronizePrefillChunks': True},
    'early192sync': {'nativePrefillChunkSize': 2048, 'nativePrefillFirstChunkSize': 192,
                     'nativeFinalPrefillLogitsOnly': True, 'nativeSynchronizePrefillChunks': True},
    'early64sync': {'nativePrefillChunkSize': 2048, 'nativePrefillFirstChunkSize': 64,
                    'nativeFinalPrefillLogitsOnly': True, 'nativeSynchronizePrefillChunks': True},
"""
assert runner.count(anchor)==1
runner=runner.replace(anchor,anchor+new)
runner=runner.replace('def screen(root, model):','def screen(root, model, selected=None):')
runner=runner.replace('    order = list(ARMS)[1:]','    order = selected if selected is not None else list(ARMS)[1:]')
runner=runner.replace("    sub.add_parser('screen')", "    p=sub.add_parser('screen');p.add_argument('--arms')")
runner=runner.replace("elif args.command=='screen':screen(args.root,args.model)","elif args.command=='screen':screen(args.root,args.model,args.arms.split(',') if args.arms else None)")
(out/'cancellation_experiment.py').write_text(runner)
(repo/'Benchmarks/Cotyping/cancellation_experiment.py').write_text(runner)
shutil.copytree(root/'inputs',out/'inputs')
shutil.copyfile(root/'corpus.json',out/'corpus.json')
shutil.copyfile(root/'baseline.json',out/'baseline.json')
(out/'baseline.app').symlink_to(root/'baseline.app',target_is_directory=True)
meta=json.loads((root/'case-meta.json').read_text())
for phase in ['screen','confirmation']:
    p=out/'inputs'/f'{phase}-cancellation.json';fixture=json.loads(p.read_text())
    extra=[]
    for item in fixture['cases']:
        if item['id'].startswith('warmup-'):continue
        info=meta[item['id']]
        if info['delay']!=5:continue
        changed=dict(item);changed['id']=item['id'].replace('-5-','-60-')
        if 'cancelAfterMs' in changed:changed['cancelAfterMs']=60
        extra.append(changed)
        meta[changed['id']]=dict(info,delay=60,event=info['event'].removesuffix('-5')+'-60')
    fixture['cases']+=extra;p.write_text(json.dumps(fixture,ensure_ascii=False,indent=2)+'\n')
(out/'case-meta.json').write_text(json.dumps(meta,indent=2)+'\n')
plan=json.loads((root/'plan.json').read_text())
plan['frozenAtUTC']=datetime.now(timezone.utc).isoformat()
plan['amendment']='Separate binary/cohort after fixed-chunk screening; short prompts keep the 256-token path. Added 60-ms interruption requests before any confirmation outputs were observed. All original no-regression gates remain; require cancellation p95 not to worsen as well.'
plan['screenArms']=['early128','early128sync','early192sync','early64sync']
plan['inputSHA256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (out/'inputs').iterdir()}
plan['runnerSHA256']=hashlib.sha256(runner.encode()).hexdigest()
(out/'plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
print('Frozen adaptive phase before confirmation; 5/20/60 ms interruptions, same normal holdout.')
