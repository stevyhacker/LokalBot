"""Confirm the strongest cancellation tradeoff; stop early only to reject it."""
from pathlib import Path
from datetime import datetime,timezone
import shutil
import cancellation_experiment as c

root=Path(__file__).resolve().parent
model=Path('/Users/0xmithrandir/Library/Application Support/me.dotenv.LokalBot/models/gemma-4-E2B.i1-Q6_K.gguf')
arm='early192sync'
selection=dict(selectedAtUTC=datetime.now(timezone.utc).isoformat(),arm=arm,
    reason='Among screened candidates with a meaningful reduction through the replacement, this avoids the larger normal-speed penalties of the 64/128 first chunks. It is a tradeoff finalist, not yet eligible for adoption.',
    order=[['default',arm],[arm,'default'],[arm,'default'],['default',arm]],
    maximumRounds=4,
    rejectionOnlyFutility='After two balanced rounds, stop and reject if any normal-workload mean delta has its entire paired 95% CI above zero, or if output parity fails. Acceptance still requires all four rounds and every original gate. This cannot promote a noisy early win.',
    fixed='Untouched 24-pair confirmation set; E2B model/prompt/sampler/budgets/gates unchanged.')
c.write(root/'confirmation-selection.json',selection)
completed=[]
for round_number,order in enumerate(selection['order'],1):
    for selected in order:
        for dataset in ['fresh','long','dynamic','cancellation']:
            c.run(root,model,'confirmation',selected,round_number,dataset)
    completed.append(round_number)
    if round_number in [2,4]:
        c.analyze(root,'confirmation',arm,completed)
        result=c.read(root/f'confirmation-{arm}-analysis.json')
        shutil.copyfile(root/f'confirmation-{arm}-analysis.json',root/f'confirmation-after-{round_number}.json')
        regressions=[name for name,stats in result['normal'].items() if stats['delta95CI'][0]>0]
        if round_number==2 and (regressions or not result['passesQuality']):
            c.write(root/'decision.json',dict(adopt=False,rounds=completed,earlyStoppedForRejection=True,
                clearNormalRegressions=regressions,qualityPassed=result['passesQuality'],
                reason='Predeclared rejection-only futility: speed regression or changed outputs on fresh confirmation data. Current installed/default policy retained.'))
            break
else:
    c.write(root/'decision.json',dict(adopt=result['passesAdoptionGate'],rounds=completed,
        earlyStoppedForRejection=False,reason='All four planned rounds completed; apply the unchanged adoption gates.'))
print(c.read(root/'decision.json'),flush=True)
